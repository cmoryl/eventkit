
import * as React from 'react';
import { useState } from 'react';
import QRCodeStyling from 'qr-code-styling';
import { 
    extractColorPalette, generateTextContent, generateBrandedImage, generateSeamlessPattern,
    generateLocationIntel, getVenueLayoutDescription, generateFloorPlan, generateMonochromeLogo,
    generateSmartTextAsset, generateEventVideo, generatePresentationContent
} from '../services/geminiService';
import { base64ToFile, fileToBase64 } from '../utils';
import { AssetType } from '../types';
import type { EventDetails, GeneratedAsset, ColorInfo, LogoAsset } from '../types';

interface UseAIOrchestratorProps {
    eventDetails: EventDetails;
    logos: LogoAsset[];
    styleImage: { file: File } | null;
    masterPatternImage: File | null;
    colorPalette: ColorInfo[];
    setColorPalette: (c: ColorInfo[]) => void;
    generatedAssets: GeneratedAsset[];
    setGeneratedAssets: React.Dispatch<React.SetStateAction<GeneratedAsset[]>>;
    ensureProtocol: (url: string) => string;
}

export const useAIOrchestrator = ({
    eventDetails, logos, styleImage, masterPatternImage, colorPalette, setColorPalette, generatedAssets, setGeneratedAssets, ensureProtocol
}: UseAIOrchestratorProps) => {
    const [isLoading, setIsLoading] = useState(false);
    const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 0 });

    const getPromptForAsset = (type: AssetType, details: EventDetails, styleDesc: string, colors?: string[]): string => {
        const base = `Design a ${type.replace(/_/g, ' ').toLowerCase()} for an event named "${details.name}".\nEvent Description: ${details.description}.`;
        let style = styleDesc ? `\nVisual Style: ${styleDesc}` : '';
        if (colors && colors.length > 0) style += `\n\n**Color Strategy:** Use: ${colors.join(', ')}.`;
        
        if (type === AssetType.Banner) style += `\nFormat: Wide Horizontal Banner. High visibility.`;
        if (type === AssetType.NameTag) style += `\nFormat: Vertical Badge (3x4).`;
        if (type === AssetType.MainStageBackdrop) style += `\nFormat: Cinematic ultra-wide stage backdrop. Layered depth.`;
        
        return `${base} ${style}`;
    };

    const generateAssets = async (assetsToGenerate: GeneratedAsset[], currentStyleDesc: string, paletteOverride?: ColorInfo[]) => {
        setIsLoading(true);
        const primaryLogo = logos.length > 0 ? logos[0].file : null;
        const currentStyleImage = styleImage ? styleImage.file : null;
        
        const paletteAsset = assetsToGenerate.find(a => a.type === AssetType.Palette);
        const patternAsset = assetsToGenerate.find(a => a.type === AssetType.SeamlessPattern);
        const otherAssets = assetsToGenerate.filter(a => a.type !== AssetType.Palette && a.type !== AssetType.SeamlessPattern);

        let resolvedPalette: ColorInfo[] = paletteOverride || colorPalette;
        let resolvedPatternFile: File | null = null;

        // --- Phase 1: Palette ---
        if (paletteAsset && !paletteOverride) {
             try {
                 // Use primary logo or style image for palette extraction. 
                 // If neither, we skip palette extraction logic or use a fallback if desired, 
                 // but typically palette extraction requires a source.
                 if (currentStyleImage || primaryLogo) {
                    const content = await extractColorPalette(currentStyleImage || primaryLogo!);
                    resolvedPalette = content;
                    setColorPalette(content);
                    setGeneratedAssets(prev => prev.map(a => a.id === paletteAsset.id ? { ...a, content, isLoading: false } : a));
                 } else {
                    setGeneratedAssets(prev => prev.map(a => a.id === paletteAsset.id ? { ...a, isLoading: false, content: [] } : a)); // Empty palette
                 }
                 setGenerationProgress(prev => ({ ...prev, current: prev.current + 1 }));
             } catch (error) {
                 console.warn("Palette failed", error);
                 setGeneratedAssets(prev => prev.map(a => a.id === paletteAsset.id ? { ...a, isLoading: false } : a));
             }
        }
        const currentPaletteStrings = resolvedPalette.map(c => `${c.name} (${c.hex})`);

        // --- Phase 2: Pattern ---
        const existingPattern = generatedAssets.find(a => a.type === AssetType.SeamlessPattern && typeof a.content === 'string' && a.content.startsWith('data:'));
        if (existingPattern) resolvedPatternFile = base64ToFile({ data: (existingPattern.content as string).split(',')[1], type: 'image/png', name: 'pattern.png' });

        if (patternAsset) {
             try {
                 const source = masterPatternImage || currentStyleImage;
                 // Generate pattern. If no source, it generates from text prompt.
                 const base64Pattern = await generateSeamlessPattern(source, eventDetails, currentPaletteStrings);
                 resolvedPatternFile = base64ToFile({ data: base64Pattern.split(',')[1], type: 'image/png', name: 'gen-pattern.png' });
                 setGeneratedAssets(prev => prev.map(a => a.id === patternAsset.id ? { ...a, content: base64Pattern, isLoading: false } : a));
                 setGenerationProgress(prev => ({ ...prev, current: prev.current + 1 }));
             } catch (error) {
                 console.warn("Pattern failed", error);
                 setGeneratedAssets(prev => prev.map(a => a.id === patternAsset.id ? { ...a, isLoading: false } : a));
             }
        }

        // --- Phase 3: Batch ---
        // Logic fix: Do NOT abort if no logo. Allow text assets to proceed.
        
        const BATCH_SIZE = 3;
        for (let i = 0; i < otherAssets.length; i += BATCH_SIZE) {
            const batch = otherAssets.slice(i, i + BATCH_SIZE);
            await Promise.all(batch.map(async (asset) => {
                try {
                    let content: any;
                    let extraProps: Partial<GeneratedAsset> = {};

                    switch (asset.type) {
                        case AssetType.Slogans:
                             content = await generateTextContent(`Generate 5 slogans for ${eventDetails.name}.`);
                             break;
                        case AssetType.LocationIntel:
                             content = eventDetails.venueName ? await generateLocationIntel(eventDetails.venuePlaceId || '', eventDetails.venueName) : "Venue required.";
                             break;
                        case AssetType.LogoMonochrome:
                             if (!primaryLogo) throw new Error("Logo required");
                             content = await generateMonochromeLogo(await fileToBase64(primaryLogo).then(r => `data:${r.type};base64,${r.data}`), 'black');
                             break;
                        case AssetType.LogoReversed:
                             if (!primaryLogo) throw new Error("Logo required");
                             content = await generateMonochromeLogo(await fileToBase64(primaryLogo).then(r => `data:${r.type};base64,${r.data}`), 'white');
                             break;
                        case AssetType.VideoTeaser:
                            // Safe logo passing (undefined if not present)
                            content = await generateEventVideo(eventDetails, currentStyleDesc, '16:9', undefined, primaryLogo || undefined);
                            break;
                        case AssetType.Presentation:
                            content = await generatePresentationContent(eventDetails, currentPaletteStrings.map(s => s.match(/#\w+/)?.[0] || '#000'), currentStyleDesc);
                            break;
                        case AssetType.RunOfShow:
                        case AssetType.MarketingCopy:
                        case AssetType.Soundtrack:
                        case AssetType.StyleGuide:
                            content = await generateSmartTextAsset(asset.type, eventDetails, resolvedPalette);
                            break;
                        case AssetType.QRCode:
                             const finalQrUrl = ensureProtocol(eventDetails.qrCodeUrl || eventDetails.website || 'https://google.com');
                             const qrCode = new QRCodeStyling({ width: 1200, height: 1200, data: finalQrUrl });
                             const blob = await qrCode.getRawData('png');
                             content = await new Promise<string>(r => { const rd = new FileReader(); rd.onload = () => r(rd.result as string); rd.readAsDataURL(blob as Blob); });
                             break;
                        case AssetType.NameTag:
                             // BrandedImage uses logoFile optionally.
                             content = await generateBrandedImage(getPromptForAsset(AssetType.NameTag, eventDetails, currentStyleDesc, currentPaletteStrings), primaryLogo, resolvedPatternFile, '3:4');
                             const backImg = await generateBrandedImage(getPromptForAsset(AssetType.NameTagBack, eventDetails, currentStyleDesc, currentPaletteStrings), primaryLogo, resolvedPatternFile, '3:4');
                             extraProps.backContent = backImg;
                             break;
                        default:
                            content = await generateBrandedImage(getPromptForAsset(asset.type, eventDetails, currentStyleDesc, currentPaletteStrings), primaryLogo, resolvedPatternFile, '16:9');
                            break;
                    }
                    setGeneratedAssets(prev => prev.map(a => a.id === asset.id ? { ...a, content, isLoading: false, ...extraProps } : a));
                } catch (e) {
                    console.error(`Asset ${asset.type} failed`, e);
                    setGeneratedAssets(prev => prev.map(a => a.id === asset.id ? { ...a, isLoading: false } : a));
                }
                setGenerationProgress(prev => ({ ...prev, current: prev.current + 1 }));
            }));
        }
        setIsLoading(false);
    };

    return { generateAssets, isLoading, setIsLoading, generationProgress, setGenerationProgress };
};
