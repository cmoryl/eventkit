
import { useState } from 'react';
import JSZip from 'jszip';
import type { EventDetails, GeneratedAsset, AssetFolder, ColorInfo, LogoAsset } from '../types';

interface UseProjectPersistenceProps {
    eventDetails: EventDetails;
    generatedAssets: GeneratedAsset[];
    logos: LogoAsset[];
    styleDescription: string;
    colorPalette: ColorInfo[];
    folders: AssetFolder[];
    onLoad: (data: any) => Promise<void>;
    showToast: (msg: string, type: 'success' | 'error') => void;
}

export const useProjectPersistence = ({
    eventDetails,
    generatedAssets,
    logos,
    styleDescription,
    colorPalette,
    folders,
    onLoad,
    showToast
}: UseProjectPersistenceProps) => {
    const [isExporting, setIsExporting] = useState(false);
    const [isLoadingProject, setIsLoadingProject] = useState(false);

    const handleSaveProject = async () => {
        setIsExporting(true);
        try {
            const zip = new JSZip();
            const assetsFolder = zip.folder("assets");
            
            // Process Generated Assets
            const processedAssets = await Promise.all(generatedAssets.map(async (asset) => {
                const newAsset = { ...asset };
                
                // Handle Main Content
                if (typeof asset.content === 'string' && asset.content.startsWith('data:')) {
                    const ext = asset.content.split(';')[0].split('/')[1];
                    const filename = `${asset.id}.${ext}`;
                    if (assetsFolder) {
                        assetsFolder.file(filename, asset.content.split(',')[1], { base64: true });
                        newAsset.content = `assets/${filename}`;
                    }
                } else if (typeof asset.content === 'string' && asset.content.startsWith('blob:')) {
                    const res = await fetch(asset.content);
                    const blob = await res.blob();
                    const ext = blob.type.split('/')[1];
                    const filename = `${asset.id}.${ext}`;
                    if (assetsFolder) {
                        assetsFolder.file(filename, blob);
                        newAsset.content = `assets/${filename}`;
                    }
                }
                
                // Handle Back Content
                if (asset.backContent && asset.backContent.startsWith('data:')) {
                     const ext = asset.backContent.split(';')[0].split('/')[1];
                     const filename = `${asset.id}_back.${ext}`;
                     if (assetsFolder) {
                         assetsFolder.file(filename, asset.backContent.split(',')[1], { base64: true });
                         newAsset.backContent = `assets/${filename}`;
                     }
                }
                
                return newAsset;
            }));

            // Process Logos
            const processedLogos = await Promise.all(logos.map(async (logo) => {
                const newLogo = { ...logo, file: undefined }; // Remove File object
                if (logo.url.startsWith('data:')) {
                     const ext = logo.url.split(';')[0].split('/')[1];
                     const filename = `logo_${logo.id}.${ext}`;
                     if (assetsFolder) {
                         assetsFolder.file(filename, logo.url.split(',')[1], { base64: true });
                         newLogo.url = `assets/${filename}`;
                     }
                } else if (logo.url.startsWith('blob:')) {
                    const res = await fetch(logo.url);
                    const blob = await res.blob();
                    const ext = blob.type.split('/')[1];
                    const filename = `logo_${logo.id}.${ext}`;
                    if (assetsFolder) {
                        assetsFolder.file(filename, blob);
                        newLogo.url = `assets/${filename}`;
                    }
                }
                return newLogo;
            }));

            const projectMetadata = {
                eventDetails,
                styleDescription,
                colorPalette,
                folders,
                generatedAssets: processedAssets,
                logos: processedLogos,
                version: "2.0"
            };

            zip.file("project.json", JSON.stringify(projectMetadata, null, 2));

            const content = await zip.generateAsync({ type: "blob" });
            const url = URL.createObjectURL(content);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${eventDetails.name.replace(/\s+/g, '_') || 'Project'}_kit.zip`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            showToast("Project saved successfully!", "success");
        } catch (e) {
            console.error("Save failed", e);
            showToast("Failed to save project.", "error");
        } finally {
            setIsExporting(false);
        }
    };

    const handleLoadProject = async (file: File) => {
        try {
            setIsLoadingProject(true);
            const zip = new JSZip();
            const unzipped = await zip.loadAsync(file);
            
            const projectFile = unzipped.file("project.json");
            if (!projectFile) throw new Error("Invalid project file");
            
            const projectText = await projectFile.async("text");
            const data = JSON.parse(projectText);
            
            // Rehydrate Assets
            const rehydratedAssets = await Promise.all(data.generatedAssets.map(async (asset: any) => {
                if (typeof asset.content === 'string' && asset.content.startsWith('assets/')) {
                    const fileData = await unzipped.file(asset.content)?.async("base64");
                    if (fileData) {
                        const ext = asset.content.split('.').pop();
                        const mime = ext === 'svg' ? 'image/svg+xml' : (ext === 'mp4' ? 'video/mp4' : `image/${ext}`);
                        // Optimize: Use Blob URL instead of Base64 to save memory
                        const byteCharacters = atob(fileData);
                        const byteNumbers = new Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) {
                            byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        const byteArray = new Uint8Array(byteNumbers);
                        const blob = new Blob([byteArray], { type: mime });
                        asset.content = URL.createObjectURL(blob);
                    }
                }
                if (asset.backContent && asset.backContent.startsWith('assets/')) {
                    const fileData = await unzipped.file(asset.backContent)?.async("base64");
                    if (fileData) {
                         const ext = asset.backContent.split('.').pop();
                         const mime = ext === 'svg' ? 'image/svg+xml' : `image/${ext}`;
                         const byteCharacters = atob(fileData);
                         const byteNumbers = new Array(byteCharacters.length);
                         for (let i = 0; i < byteCharacters.length; i++) {
                             byteNumbers[i] = byteCharacters.charCodeAt(i);
                         }
                         const byteArray = new Uint8Array(byteNumbers);
                         const blob = new Blob([byteArray], { type: mime });
                         asset.backContent = URL.createObjectURL(blob);
                    }
                }
                return asset;
            }));

            // Rehydrate Logos
            const rehydratedLogos = await Promise.all(data.logos.map(async (logo: any) => {
                if (logo.url && logo.url.startsWith('assets/')) {
                    const fileData = await unzipped.file(logo.url)?.async("base64");
                    if (fileData) {
                        const ext = logo.url.split('.').pop();
                        const mime = ext === 'svg' ? 'image/svg+xml' : `image/${ext}`;
                        // Convert to Blob URL
                        const byteCharacters = atob(fileData);
                        const byteNumbers = new Array(byteCharacters.length);
                        for (let i = 0; i < byteCharacters.length; i++) {
                            byteNumbers[i] = byteCharacters.charCodeAt(i);
                        }
                        const byteArray = new Uint8Array(byteNumbers);
                        const blob = new Blob([byteArray], { type: mime });
                        
                        logo.url = URL.createObjectURL(blob);
                        logo.file = new File([blob], logo.name, { type: mime });
                    }
                } else if (logo.url && logo.url.startsWith('data:')) {
                     // If it was saved as Base64, convert to Blob URL for consistency
                     const res = await fetch(logo.url);
                     const blob = await res.blob();
                     logo.url = URL.createObjectURL(blob);
                     logo.file = new File([blob], logo.name, { type: blob.type });
                }
                return logo;
            }));

            await onLoad({
                ...data,
                generatedAssets: rehydratedAssets,
                logos: rehydratedLogos
            });
            
            showToast("Project loaded successfully!", "success");
        } catch (e) {
            console.error("Load failed", e);
            showToast("Failed to load project file.", "error");
        } finally {
            setIsLoadingProject(false);
        }
    };

    return {
        handleSaveProject,
        handleLoadProject,
        isExporting,
        isLoadingProject
    };
};
