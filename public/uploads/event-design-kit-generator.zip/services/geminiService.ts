// ... existing imports
import { GoogleGenAI, Type, Modality, GenerateContentResponse, HarmCategory, HarmBlockThreshold } from '@google/genai';
import { AssetType } from '../types';
import type { ColorInfo, GeneratedAsset, EventDetails, VenueSearchResult, LogoGenerationOptions, PresentationData, SlideElement } from '../types';
import { v4 as uuidv4 } from 'uuid';

const fileToGenerativePart = async (file: File) => {
  const base64EncodedData = await new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: {
      data: base64EncodedData,
      mimeType: file.type,
    },
  };
};

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const advancedImageModel = 'gemini-3-pro-image-preview';
const thinkingModel = 'gemini-3-pro-preview';
const standardTextModel = 'gemini-2.5-flash';
const videoModel = 'veo-3.1-fast-generate-preview';

const SYSTEM_INSTRUCTION = `
### EVENT KIT ENGINE PROTOCOL ###
You are the Event Kit Engine. Your role is to generate precise, creative, and format-compliant content for event branding assets.

1.  **Format Adherence:** When JSON is requested, output *only* valid JSON. When plain text is requested, output *only* the content, without introductory text or markdown code blocks (unless specifically asking for markdown formatted content like a blog post).
2.  **Brand Voice:** Professional, creative, and tailored to the user's event description.
3.  **Visuals:** When describing visuals, be photorealistic and detailed.
`;

const LOGO_PROTECTION_PROMPT = `
**CRITICAL DESIGN RULES (LOGO SAFETY):**
1.  **Zero Interference:** The logo must be the absolute focal point. NEVER overlap text, complex graphics, or busy patterns directly on top of the logo.
2.  **Safe Zone:** Maintain a mandatory "breathing room" (whitespace/clear space) around the logo. It must be distinctly separated from the background.
3.  **Rule of Thirds:** Place the logo strategically based on the asset type (e.g., centered for banners, top-left/right for documents, or at optical power points). Do not place it arbitrarily.
4.  **Background Separation:** If a seamless pattern or texture is used, it must remain in the background layer with low opacity or high contrast relative to the logo. The logo must "pop" and be instantly legible.
`;

const DESIGN_CONTAINMENT_PROMPT = `
**STRICT PLACEMENT & CONTAINMENT RULES:**
1.  **Object Isolation:** The branded design (logo/pattern) MUST be confined strictly to the physical surface of the target object (e.g., ONLY on the T-shirt fabric, ONLY on the Banner vinyl).
2.  **No Environmental Bleed:** Do NOT project, reflect, or extend the design onto the surrounding environment, background walls, floor, or other props. The background must remain a realistic, unbranded scene.
3.  **Physical Mapping:** Map the design to the object's specific geometry (following folds, curves, perspective) and material properties. It must look like it is printed ON the object, not floating over the image.
`;

const NAME_TAG_FRONT_TEMPLATE = `
**STRICT PHYSICAL TEMPLATE (NAME TAG - FRONT):**
- **Purpose:** IDENTITY.
- **Dimensions:** 3:4 Vertical Aspect Ratio.
- **Top 15%:** RESERVED for Lanyard Slots (Do not place text here).
- **Layout:** High-impact, branding heavy.
- **Required Elements:** Large First Name placeholder (Center), Full Name/Title/Company (Below). Logo (Bottom or Top-Right).
- **Style:** Brand colors, bold typography.
`;

const NAME_TAG_BACK_TEMPLATE = `
**STRICT PHYSICAL TEMPLATE (NAME TAG - BACK):**
- **Purpose:** INFORMATION.
- **Dimensions:** 3:4 Vertical Aspect Ratio.
- **Top 15%:** RESERVED for Lanyard Slots.
- **Layout:** Functional, high contrast, white/light background preferred for readability.
- **Content Blocks:**
  1. **Agenda:** List of 3-4 time slots.
  2. **Wi-Fi:** Network/Password box.
  3. **Map:** Mini venue map placeholder.
  4. **QR:** Small QR code in corner.
- **Style:** Minimalist, utility-focused.
`;

const safetySettings = [
    { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
    { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
    { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
    { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH },
];

// Helper to strip markdown code blocks from string responses
export const cleanAIResponse = (text: string): string => {
    if (!text) return "";
    // Remove ```json, ```markdown, ```html, or just ``` start tags and ``` end tags
    // Also remove leading/trailing whitespace
    return text.replace(/```[\w-]*\n?/g, '').replace(/```/g, '').trim();
};

// Helper for robust JSON parsing
const safeJSONParse = <T>(text: string, fallback: T): T => {
    if (!text) return fallback;
    try {
        const cleanText = cleanAIResponse(text);
        return JSON.parse(cleanText) as T;
    } catch (e) {
        console.warn("JSON Parse Warning: Could not parse AI response. Returning fallback.", e);
        return fallback;
    }
};

const withRetry = async <T>(fn: () => Promise<T>, retries = 4, initialDelay = 2000): Promise<T> => {
    let lastError: Error | undefined;
    for (let i = 0; i < retries; i++) {
        try {
            return await fn();
        } catch (e: any) {
            lastError = e as Error;
            const msg = (lastError.message || JSON.stringify(lastError)).toLowerCase();
            
            const isRetryable = 
                msg.includes('503') || 
                msg.includes('500') ||
                msg.includes('429') ||
                msg.includes('resource_exhausted') ||
                msg.includes('quota') ||
                msg.includes('overloaded') || 
                msg.includes('unavailable') || 
                msg.includes('fetch failed') ||
                msg.includes('no image data') ||
                msg.includes('failed to parse') ||
                msg.includes('malformed') ||
                msg.includes('candidate') ||
                msg.includes('object type');

            if (isRetryable) {
                const delay = initialDelay * Math.pow(2, i);
                console.warn(`API request failed, retrying in ${delay}ms... (Attempt ${i + 1}/${retries}) Error: ${lastError.message}`);
                await new Promise(res => setTimeout(res, delay));
            } else {
                throw e;
            }
        }
    }
    throw new Error(`API request failed after ${retries} retries: ${lastError?.message}`);
};

const getVenueVisualDetails = async (venueName: string, location: string): Promise<string> => {
    if (!venueName) return "";
    return withRetry(async () => {
        const response = await ai.models.generateContent({
            model: standardTextModel,
            contents: `Describe the interior architecture and visual style of ${venueName} in ${location}. Focus on lighting, materials (wood, glass, carpet), and color tone. Be concise.`,
            config: { tools: [{ googleSearch: {} }] }
        });
        return cleanAIResponse(response.text || "");
    });
};

const getPhotorealisticPrompt = (asset: GeneratedAsset, eventDetails: EventDetails, venueVisuals: string): string => {
    const base = `Photorealistic professional product shot of ${asset.title}.`;
    const venueContext = venueVisuals ? `Location context: Inside ${eventDetails.venueName}, matching this style: ${venueVisuals}.` : `Location: A modern, high-end event space.`;
    
    // Master Scene Engine: Randomized high-end photography setups
    // Meticulously curated prompts for every AssetType to ensure variety and quality
    const scenarios: Record<string, string[]> = {
        // --- MERCHANDISE ---
        [AssetType.Hat]: [
            "Ghost mannequin style, floating against a clean grey studio background, focusing on embroidery texture.",
            "Sitting on a rustic wooden table in a sunlit room, shallow depth of field.",
            "Worn by a model in a casual street style setting, natural lighting, blurred background.",
            "Flat lay on a concrete surface, surrounded by other event swag items."
        ],
        [AssetType.Tshirt]: [
            "Flat lay on a concrete surface with dramatic side lighting.",
            "Hanging on a minimalist metal rack in a studio.",
            "Worn by a model in a blurred event crowd setting.",
            "Folded neatly on a wooden table."
        ],
        [AssetType.TshirtBack]: [
            "Rear view of a model wearing the shirt, standing in a studio setting.",
            "Flat lay of the back of the shirt, highlighting the large graphic print.",
            "Hanging on a rack, showing the back design clearly."
        ],
        [AssetType.TshirtSleeve]: [
            "Close-up macro shot of the sleeve hem and logo detail.",
            "Side profile of a model wearing the shirt, arm down, focusing on the sleeve branding.",
            "Folded shirt detail shot focusing on the sleeve edge."
        ],
        [AssetType.Lanyard]: [
            "Hanging from a blurred neck of a professional in a suit.",
            "Coiled artistically on a white marble table.",
            "Close-up of the metal clip and fabric texture."
        ],
        [AssetType.WaterBottle]: [
            "Sitting on a gym bench with a towel, condensation on the bottle.",
            "On a modern office desk next to a laptop and plant.",
            "Held in hand against a blurred outdoor park background."
        ],
        [AssetType.StickerSheet]: [
            "Peeling off a sticker from the sheet, macro detail.",
            "Applied to the back of a laptop lid, shallow depth of field.",
            "Flat lay on a cutting mat with an X-Acto knife nearby."
        ],
        [AssetType.SwagBag]: [
            "Held by a handle, walking through a convention center.",
            "Sitting full on a chair, showcasing the fabric tote texture.",
            "Flat lay of the empty bag with event items spilling out."
        ],

        // --- PRINT & SIGNAGE ---
        [AssetType.Banner]: [
            "Hanging in a busy convention center hallway, depth of field blurring the crowd.",
            "Displayed on a stand in a modern glass atrium lobby.",
            "Outdoor festival setting, sunny day, blue sky background."
        ],
        [AssetType.EventSignage]: [
            "Mounted on a sleek metal stand in a hotel lobby.",
            "Directional signage arrow on a wall in a corridor.",
            "Foam board print leaning against a textured wall."
        ],
        [AssetType.HangingSignage]: [
            "Suspended from a high industrial ceiling in an expo hall.",
            "Hanging above a registration desk, wide angle shot.",
            "Circular hanging banner layout, lit from above."
        ],
        [AssetType.OutdoorSignage]: [
            "A-frame sign on a sidewalk outside the venue.",
            "Yard sign stuck in grass near the entrance."
        ],
        [AssetType.DoorSignage]: [
            "Attached to a modern wooden conference room door.",
            "Vinyl decal applied to a glass meeting room door.",
            "Paper sign in a holder outside a breakout room."
        ],
        [AssetType.EaselSignage]: [
            "Placed on a wooden easel at the entrance of a ballroom.",
            "Metal easel in a gallery-style setting.",
            "Welcoming guests in a foyer, warm lighting."
        ],
        [AssetType.LocationSignage]: [
            "Wayfinding pillar in a large atrium.",
            "Wall-mounted directional sign with arrows.",
            "Freestanding totem sign in a lobby."
        ],
        [AssetType.RoomSignage]: [
            "Small plaque next to a door frame.",
            "Digital room display screen showing the graphic.",
            "Printed card in a slot on the door."
        ],
        [AssetType.WifiSign]: [
            "Framed on a reception desk.",
            "Small table tent card on a cocktail table.",
            "Printed graphic on a wall near a lounge area."
        ],
        [AssetType.NameTag]: [
            "Lying on a marble registration desk next to a pen.",
            "Worn on a lanyard by a professional in a suit, close up on chest.",
            "Stacked neatly in a tray at the welcome desk."
        ],
        [AssetType.NameTagBack]: [
            "Flipped over on a table showing the agenda.",
            "Held in hand, reading the back info.",
            "Close up detail of the QR code and schedule text."
        ],
        [AssetType.Menu]: [
            "Placed on a set dinner table with wine glasses and cutlery.",
            "Held by a waiter in a black vest.",
            "Standing menu card in the center of a round table."
        ],
        [AssetType.Folder]: [
            "Open on a boardroom table with papers inside.",
            "Closed, resting on a desk with a business card.",
            "Held under arm by a business professional."
        ],
        [AssetType.ThankYouNote]: [
            "Leaning against a vase of flowers on a table.",
            "Lying open on a desk with a pen nearby.",
            "Placed on a hotel bed pillow as a welcome note."
        ],
        [AssetType.AgendaHighlights]: [
            "Printed on a large foam board on an easel.",
            "Handheld flyer card held up against a blurred venue background.",
            "Digital screen displaying the agenda."
        ],
        [AssetType.StandUpPillarBanner]: [
            "Retractable roll-up banner stand standing next to a trade show booth table.",
            "Tall vertical banner placed in a hotel lobby near the entrance doors.",
            "Standing display banner next to a registration desk in a convention center.",
            "Three pillar banners arranged in a row along a corridor wall."
        ],
        [AssetType.FeatherFlag]: [
            "Planted in grass at an outdoor festival, fluttering in the breeze.",
            "Lining the entrance driveway to a corporate campus.",
            "Next to a tent at a trade show, indoor base stand."
        ],
        [AssetType.TeardropFlag]: [
            "On a beach sand spike, taut fabric showing the design clearly.",
            "At a car dealership entrance or parking lot edge.",
            "Indoor event registration marker with cross-base stand."
        ],

        // --- DIGITAL ---
        [AssetType.SocialPost]: [
            "Displayed on an iPhone screen held in a hand.",
            "Mockup on a floating smartphone in a studio setting.",
            "Social media feed view interface."
        ],
        [AssetType.SocialStory]: [
            "Full screen vertical view on a modern smartphone.",
            "Phone leaning against a coffee cup showing the story.",
            "Held in hand, outdoor background."
        ],
        [AssetType.EmailHeader]: [
            "Displayed in an email client on a MacBook screen.",
            "Laptop open on a coffee shop table showing the email.",
            "Tablet view of the email newsletter."
        ],
        [AssetType.PresentationSlide]: [
            "Projected on a large screen in a dark conference room.",
            "Displayed on a laptop screen on a podium.",
            "View from the back of the audience looking at the screen."
        ],
        [AssetType.AppIcon]: [
            "App icon notification on a smartphone lock screen.",
            "Grid of icons on a phone home screen.",
            "App Store listing mockup."
        ],
        [AssetType.VideoTeaser]: [
            "Playing on a large LED wall at an event entrance.",
            "Displayed on a tablet held by a user.",
            "Cinema screen projection style."
        ],

        // --- EXPERIENCE & VENUE ---
        [AssetType.MainStageBackdrop]: [
            "Wide shot of a main stage with a sleek podium in front, dramatic stage lighting (spotlights) hitting the backdrop.",
            "Panel discussion setup: Four armchairs on stage, warm ambient lighting, the backdrop visible behind.",
            "TED-style setup: Circular red rug, single speaker, immersive curved projection on the backdrop.",
            "Awards ceremony style: 3D foam letters on stage, festive lighting, backdrop providing depth."
        ],
        [AssetType.Stairs]: [
            "Grand staircase in a hotel lobby, graphics applied to the risers (vertical face), viewed from the bottom looking up.",
            "Escalator steps branded with the design, modern convention center setting.",
            "Outdoor concrete steps leading to the venue entrance, graphics clearly visible on the vertical parts."
        ],
        [AssetType.RegistrationCounter]: [
            "Front view of a long, curved registration desk with branding on the front panel.",
            "Side angle showing staff behind the branded counter.",
            "Busy lobby scene with attendees checking in at the desk."
        ],
        [AssetType.WelcomeCounter]: [
            "Two separate podium-style counters side-by-side with branding on the front.",
            "Small welcome kiosk in a hotel entrance.",
            "Staff standing behind a branded welcome station."
        ],
        [AssetType.RegistrationBackWall]: [
            "Large media wall behind the registration desk.",
            "Step-and-repeat style wall with logos behind the check-in area.",
            "Textured wall with 3D logo mounting behind staff."
        ],
        [AssetType.TechnologyCounter]: [
            "Sleek white counter with iPads mounted on top, branding on the base.",
            "Charging station table with branded wrap.",
            "Tech support desk with monitors and branding."
        ],
        [AssetType.Kiosk]: [
            "Freestanding interactive touch kiosk in a hallway.",
            "Digital information tower with branding.",
            "Self-check-in kiosk station."
        ],
        [AssetType.BackWall]: [
            "Photo booth backdrop with props nearby.",
            "Exhibition booth back wall with lighting.",
            "Press interview backdrop with microphones in foreground."
        ],
        [AssetType.FloorPlan]: [
            "Printed large format on a table, people pointing at it.",
            "Digital map displayed on a wayfinding screen.",
            "Top-down view of a blueprint on a desk."
        ],
        [AssetType.GlassDoor]: [
            "Vinyl decal applied to double glass doors, view from outside looking in.",
            "Frosted glass effect branding on a meeting room door.",
            "Clear sticker logo on a glass entrance."
        ],
        [AssetType.GlassDoubleDoor]: [
            "Large branding spanning across two glass doors.",
            "View of entrance with branded glass doors opening.",
            "Privacy film design on double office doors."
        ],
        [AssetType.GlassRotatingDoor]: [
            "Curved vinyl branding on the glass of a revolving door.",
            "Motion blur shot of a revolving door with logo.",
            "Entrance view showing the branding on the moving glass panels."
        ],

        // --- FALLBACK ---
        default: [
            "Studio lighting, 8k resolution, highly detailed texture, product photography style.",
            "In situ at a luxury corporate event, ambient lighting, depth of field.",
            "Macro photography style, shallow depth of field, high contrast.",
            "Clean, minimalist composition on a textured background."
        ]
    };

    // --- PLACEMENT INSTRUCTIONS ---
    const placementInstructions: Record<string, string> = {
        [AssetType.Stairs]: "PLACEMENT: Map the design exclusively to the vertical risers of the stairs. Keep the horizontal treads clean/unbranded.",
        [AssetType.GlassDoor]: "PLACEMENT: Apply the design as a semi-transparent decal on the glass surface. Maintain transparency in negative space.",
        [AssetType.GlassDoubleDoor]: "PLACEMENT: Apply design spanning across both doors.",
        [AssetType.GlassRotatingDoor]: "PLACEMENT: Apply curved graphics to the rotating glass panels.",
        [AssetType.Tshirt]: "PLACEMENT: Centered on the chest area.",
        [AssetType.TshirtBack]: "PLACEMENT: Centered on the upper back.",
        [AssetType.TshirtSleeve]: "PLACEMENT: Small logo on the center of the visible sleeve.",
        [AssetType.Hat]: "PLACEMENT: Centered on the front panel above the brim.",
        [AssetType.Banner]: "PLACEMENT: Full bleed coverage of the banner surface.",
        [AssetType.StandUpPillarBanner]: "PLACEMENT: Full bleed vertical coverage of the banner stand surface.",
        [AssetType.FeatherFlag]: "PLACEMENT: Fit design to the curved feather shape. Ensure logo is in the main reading area.",
        [AssetType.TeardropFlag]: "PLACEMENT: Fit design to the teardrop shape. Logo should be near the top wide section.",
        [AssetType.NameTag]: "PLACEMENT: Full face of the card.",
    };

    const specificScenarios = scenarios[asset.type] || scenarios.default;
    const selectedScenario = specificScenarios[Math.floor(Math.random() * specificScenarios.length)];
    const placementRule = placementInstructions[asset.type] || "PLACEMENT: Confine design to the object's primary surface.";

    return `${base} ${selectedScenario} ${venueContext} ${placementRule} Render in 8k, Octane Render style, volumetric lighting, photorealistic textures.`;
};

export const extractColorPalette = async (imageFile: File): Promise<ColorInfo[]> => {
    return withRetry(async () => {
        const imagePart = await fileToGenerativePart(imageFile);
        const prompt = "Extract the dominant color palette from this image. Return 5 colors with hex, name, rgb, cmyk, hsv, pantone values.";
        const response = await ai.models.generateContent({
            model: standardTextModel,
            contents: { role: 'user', parts: [imagePart, { text: prompt }] },
            config: { responseMimeType: 'application/json', systemInstruction: SYSTEM_INSTRUCTION }
        });
        return safeJSONParse(response.text || '', []);
    });
};

export const getColorDetails = async (hex: string): Promise<ColorInfo> => {
    const fallback: ColorInfo = { 
        hex, 
        name: 'Unknown', 
        rgb: 'rgb(0,0,0)', 
        cmyk: '0,0,0,100', 
        hsv: '0,0,0', 
        pantone: 'Black' 
    };

    return withRetry(async () => {
        const prompt = `Provide color details for hex code ${hex}. Return hex, name, rgb, cmyk, hsv, pantone.`;
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { responseMimeType: 'application/json', systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return safeJSONParse(response.text || '', fallback);
    });
};

export const generateTextContent = async (prompt: string): Promise<string[]> => {
    return withRetry(async () => {
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt + " Return as a JSON array of strings.", 
            config: { responseMimeType: 'application/json', systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return safeJSONParse(response.text || '', []);
    });
};

export const generateBrandedImage = async (prompt: string, logoFile?: File | null, patternFile?: File | null, aspectRatio: string = "1:1"): Promise<string> => {
    return withRetry(async () => {
        const parts: any[] = [{ text: prompt + "\n" + LOGO_PROTECTION_PROMPT }];
        if (logoFile) parts.push(await fileToGenerativePart(logoFile));
        if (patternFile) parts.push(await fileToGenerativePart(patternFile));
        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { aspectRatio: aspectRatio as any, imageSize: "1K" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No image generated");
    });
};

export const generateIcon = async (prompt: string, color: string): Promise<string> => {
    return withRetry(async () => {
        const fullPrompt = `Create a flat, vector-style icon of: ${prompt}. Color: ${color}. Transparent background. Minimalist UI icon style.`;
        const response = await ai.models.generateContent({ 
            model: advancedImageModel, 
            contents: { parts: [{ text: fullPrompt }] }, 
            config: { imageConfig: { aspectRatio: "1:1" }, safetySettings } 
        });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No icon generated");
    });
};

export const describeImageStyle = async (imageFile: File): Promise<string> => {
    return withRetry(async () => {
        const imagePart = await fileToGenerativePart(imageFile);
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: { parts: [imagePart, { text: "Describe the visual style of this image in detail." }] },
            config: { systemInstruction: SYSTEM_INSTRUCTION }
        });
        return cleanAIResponse(response.text || "");
    });
};

export const generateSeamlessPattern = async (source: File | { file: File } | null, eventDetails: EventDetails, colors?: string[]): Promise<string> => {
    return withRetry(async () => {
        let parts: any[] = [];
        let prompt = `Create a seamless pattern for event: ${eventDetails.name}. ${eventDetails.description}`;
        if (colors) prompt += ` Colors: ${colors.join(', ')}.`;
        if (source) {
            prompt = `Transform this image into a perfectly seamless, tileable pattern. Maintain style but ensure edges match.`;
            const file = 'file' in source ? source.file : source;
            parts.push(await fileToGenerativePart(file));
        }
        parts.push({ text: prompt });
        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { aspectRatio: "1:1" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No pattern generated");
    });
};

export const generatePhotorealisticShot = async (asset: GeneratedAsset, eventDetails: EventDetails): Promise<string> => {
    return withRetry(async () => {
        // 1. Research Venue Visuals (if applicable)
        let venueVisuals = "";
        if (eventDetails.venueName && eventDetails.location) {
            try {
                venueVisuals = await getVenueVisualDetails(eventDetails.venueName, eventDetails.location);
            } catch (e) {
                console.warn("Venue research failed, proceeding with generic.", e);
            }
        }

        // 2. Generate Prompt using Master Scene Engine
        const prompt = getPhotorealisticPrompt(asset, eventDetails, venueVisuals);

        let parts: any[] = [{ text: prompt + "\n" + LOGO_PROTECTION_PROMPT + "\n" + DESIGN_CONTAINMENT_PROMPT }];
        if (typeof asset.content === 'string' && asset.content.startsWith('data:')) {
            parts.push({ inlineData: { mimeType: 'image/png', data: asset.content.split(',')[1] } });
        }
        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { imageSize: "1K" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No photo generated");
    });
};

export const regeneratePhotorealisticShot = async (sourceAsset: GeneratedAsset, prompt: string, envFile: File | null, mergeImage?: File | null): Promise<string> => {
    return withRetry(async () => {
        let fullPrompt = prompt;
        const parts: any[] = [];

        // If user uploaded a stage photo to merge into
        if (mergeImage) {
            fullPrompt += ` COMPOSITING TASK: Integrate the design into this specific stage photo. Match the perspective, lighting, and shadows of the provided scene exactly. Replace screens or banners in the photo with the provided design.`;
            parts.push(await fileToGenerativePart(mergeImage));
        }

        parts.push({ text: fullPrompt + "\n" + LOGO_PROTECTION_PROMPT + "\n" + DESIGN_CONTAINMENT_PROMPT });

        // Add the design source
        if (typeof sourceAsset.content === 'string' && sourceAsset.content.startsWith('data:')) {
            parts.push({ inlineData: { mimeType: 'image/png', data: sourceAsset.content.split(',')[1] } });
        }
        
        // Add environment ref if separate (legacy support)
        if (envFile && !mergeImage) parts.push(await fileToGenerativePart(envFile));

        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { imageSize: "1K" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No photo generated");
    });
};

export const editImageContent = async (type: AssetType, sourceImage: string, colors: string[], prompt: string, customContent: any, overlayImage?: string, maskImage?: string): Promise<string> => {
    return withRetry(async () => {
        let finalPrompt = `Edit this image. ${prompt}`;
        
        // Inject Name Tag Physical Template Rules if applicable
        if (type === AssetType.NameTag) {
            finalPrompt += `\n${NAME_TAG_FRONT_TEMPLATE}`;
        } else if (type === AssetType.NameTagBack) {
            finalPrompt += `\n${NAME_TAG_BACK_TEMPLATE}`;
        }

        // Handle specific "No Text" mode
        if (customContent?.noText === 'true') {
            finalPrompt += ` REMOVE ALL TEXT placeholders (Name, Title, Company). Keep the background design, logo, and graphical elements intact. Clean, graphic-only version.`;
        }

        // Handle Masked In-Painting
        if (maskImage) {
            finalPrompt += ` IN-PAINTING INSTRUCTION: Only modify the area defined by the white pixels in the provided mask. Keep the rest of the image exactly as is.`;
        }

        let parts: any[] = [{ text: finalPrompt + "\n" + LOGO_PROTECTION_PROMPT }];
        
        if (sourceImage.startsWith('data:')) parts.push({ inlineData: { mimeType: 'image/png', data: sourceImage.split(',')[1] } });
        
        if (overlayImage && overlayImage.startsWith('data:')) {
            parts.push({ inlineData: { mimeType: 'image/png', data: overlayImage.split(',')[1] } });
            parts.push({ text: "Composite this overlay image onto the design." });
        }

        if (maskImage && maskImage.startsWith('data:')) {
             parts.push({ inlineData: { mimeType: 'image/png', data: maskImage.split(',')[1] } });
        }

        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { imageSize: "1K" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("No image generated");
    });
};

export const findVenueDetails = async (query: string, location: string): Promise<VenueSearchResult[]> => {
    return withRetry(async () => {
        const prompt = `Find venues matching "${query}" in "${location}". Return JSON list with name, address, placeId.`;
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { tools: [{ googleSearch: {} }], systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return safeJSONParse(response.text || '', []);
    });
};

export const getVenueLayoutDescription = async (name: string, placeId: string): Promise<string> => {
    return "Layout details not available via API currently.";
};

export const generateFloorPlan = async (eventDetails: EventDetails, logo: File, pattern: File | null, layoutDesc: string): Promise<string> => {
    const prompt = `Generate a floor plan for ${eventDetails.venueName}. ${layoutDesc}`;
    return generateBrandedImage(prompt, logo, pattern, "16:9");
};

export const generateLocationIntel = async (placeId: string, venueName: string): Promise<string> => {
    return withRetry(async () => {
        const prompt = `Provide location intelligence for ${venueName}. Include Local Attractions, Restaurants, Hotels, and Transport. Format as Markdown. Include direct links to websites where possible in format [Name](URL).`;
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { tools: [{ googleSearch: {} }], systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return cleanAIResponse(response.text || "");
    });
};

export const getLogoSuggestions = async (location: string): Promise<string> => {
    return withRetry(async () => {
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: `Suggest cultural logo elements for ${location}.`,
            config: { systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return cleanAIResponse(response.text || "");
    });
};

export const generateLogoVariations = async (options: LogoGenerationOptions, count: number = 4): Promise<string[]> => {
    const prompt = `Design a logo. Title: ${options.eventTitle}. Style: ${options.styleBundles.join(', ')}.`;
    const promises = Array.from({ length: count }).map(async () => {
         return withRetry(async () => {
             const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts: [{ text: prompt }] }, config: { imageConfig: { aspectRatio: "1:1" }, safetySettings } });
            for (const part of response.candidates?.[0]?.content?.parts || []) {
                if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
            return "";
         });
    });
    return (await Promise.all(promises)).filter(s => s !== "");
};

export const refineLogo = async (currentImage: string, instruction: string): Promise<string> => {
    return withRetry(async () => {
        const parts: any[] = [{ text: instruction }];
        if (currentImage.startsWith('data:')) parts.push({ inlineData: { mimeType: 'image/png', data: currentImage.split(',')[1] } });
        const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts }, config: { imageConfig: { aspectRatio: "1:1" }, safetySettings } });
        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
        throw new Error("Failed to refine");
    });
};

export const generateMonochromeLogo = async (image: string, color: 'black' | 'white'): Promise<string> => {
    return refineLogo(image, `Convert this logo to flat ${color} monochrome. Ensure the background is completely transparent (alpha channel 0). The logo should be solid ${color}.`);
};

export const generateImageVariations = async (image: File): Promise<string[]> => {
    const imagePart = await fileToGenerativePart(image);
    const promises = Array.from({ length: 4 }).map(async () => {
         return withRetry(async () => {
             const response = await ai.models.generateContent({ model: advancedImageModel, contents: { parts: [imagePart, { text: "Generate a variation of this logo." }] }, config: { imageConfig: { aspectRatio: "1:1" }, safetySettings } });
            for (const part of response.candidates?.[0]?.content?.parts || []) {
                if (part.inlineData) return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
            return "";
         });
    });
    return (await Promise.all(promises)).filter(s => s !== "");
};

export const generateSmartTextAsset = async (type: AssetType, eventDetails: EventDetails, colors?: ColorInfo[]): Promise<string> => {
    let prompt = `Generate content for ${type} for event ${eventDetails.name}.`;
    
    switch (type) {
        case AssetType.RunOfShow:
            prompt = `Act as an Event Director. Create a detailed Minute-by-Minute Run of Show for "${eventDetails.name}" (${eventDetails.description}). 
            Include: Setup, Doors Open, Keynote, Panels, Breaks, Closing. 
            Format as a professional timeline list. Do NOT use markdown code blocks.`;
            break;
        case AssetType.MarketingCopy:
            prompt = `Act as a Copywriter. Write 3 Social Media Captions (LinkedIn, Twitter, Instagram) and 1 Email Subject Line + Body for "${eventDetails.name}". 
            Tone: Professional yet Exciting. Highlights: ${eventDetails.description}. Do NOT use markdown code blocks.`;
            break;
        case AssetType.Soundtrack:
            prompt = `Act as a Music Supervisor. Curate a Sonic Identity for "${eventDetails.name}". 
            1. Describe the "Vibe" (e.g., Lo-fi Beats, Orchestral, Upbeat Pop).
            2. Suggest a Playlist of 10 specific songs that match this vibe. Do NOT use markdown code blocks.`;
            break;
        case AssetType.StyleGuide:
            const colorList = colors?.map(c => `${c.name}: ${c.hex}`).join(', ') || 'Standard Palette';
            prompt = `Act as a Brand Director. Create a "Brand Style Guide One-Sheet" for "${eventDetails.name}".
            Sections:
            1. Brand Voice (3 adjectives).
            2. Typography Usage (Header vs Body).
            3. Color Palette Usage (using these: ${colorList}).
            4. Imagery Guidelines (Do's and Don'ts).
            Format in Markdown (bold, lists) but Do NOT use code blocks.`;
            break;
    }

    return withRetry(async () => {
        const response = await ai.models.generateContent({ 
            model: thinkingModel, 
            contents: prompt,
            config: { systemInstruction: SYSTEM_INSTRUCTION }
        });
        return cleanAIResponse(response.text || "");
    });
};

export const generateEventVideo = async (
    eventDetails: EventDetails,
    style: string,
    aspectRatio: '16:9' | '9:16' = '16:9',
    customPrompt?: string,
    logoFile?: File
): Promise<string> => {
    return withRetry(async () => {
        const promptText = customPrompt 
            ? `${customPrompt}. Cinematic motion graphics. High resolution.`
            : `Cinematic teaser for ${eventDetails.name}. ${style}. High resolution, 30fps, motion graphics style. Start with a dynamic reveal of the event logo integrated into the scene.`;

        let imageInput;
        if (logoFile) {
             const part = await fileToGenerativePart(logoFile);
             imageInput = {
                 imageBytes: part.inlineData.data,
                 mimeType: part.inlineData.mimeType
             };
        }

        let operation = await ai.models.generateVideos({
            model: videoModel,
            prompt: promptText,
            image: imageInput, 
            config: { 
                numberOfVideos: 1, 
                resolution: '1080p', 
                aspectRatio: aspectRatio 
            }
        });
        
        let attempts = 0;
        const maxAttempts = 60; 
        while (operation.name && !operation.done && attempts < maxAttempts) {
             await new Promise(resolve => setTimeout(resolve, 5000));
             operation = await ai.operations.getVideosOperation({ operation: operation });
             attempts++;
        }
        
        if (!operation.done) throw new Error("Video generation timed out.");

        const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (videoUri) {
            const res = await fetch(`${videoUri}&key=${process.env.API_KEY}`);
            const blob = await res.blob();
            return URL.createObjectURL(blob);
        }
        return "";
    });
};

export const generatePresentationContent = async (eventDetails: EventDetails, themeColors: string[], styleDescription?: string): Promise<PresentationData> => {
    const prompt = `Act as a Creative Director. Create a 5-slide presentation deck for "${eventDetails.name}".
    Context: ${eventDetails.description}. 
    Visual Style: ${styleDescription || 'Modern Professional'}.
    Theme Colors: ${themeColors.join(', ')}.

    STRUCTURE REQUIREMENTS:
    1.  **Slide 1 (Hero/Title):** Big bold title, impactful background image (describe the image).
    2.  **Slide 2 (Overview/Split):** Left text, right image. Summary of event.
    3.  **Slide 3 (Highlights/Grid):** A grid layout showing 3 key pillars/speakers.
    4.  **Slide 4 (Impact/Data):** A chart slide showing projected impact or growth.
    5.  **Slide 5 (Closing):** Minimalist, strong quote or "Thank You".

    OUTPUT FORMAT:
    Return strictly structured JSON.
    - For 'elements', calculate 'x, y, w, h' as percentages (0-100).
    - For 'image' elements, set 'src' to "placeholder".
    - For 'text' elements, use the specified theme colors.
    
    JSON SCHEMA:
    {
      "title": "String",
      "theme": { "backgroundColor": "hex", "titleColor": "hex", "textColor": "hex", "accentColor": "hex", "titleFont": "FontName", "bodyFont": "FontName" },
      "slides": [
        {
          "id": "uuid",
          "type": "title|image-split|grid|chart|content",
          "background": "hex", 
          "elements": [
             { "type": "text", "id": "uuid", "x": number, "y": number, "w": number, "h": number, "content": "String", "fontSize": number, "fontWeight": "bold|normal", "color": "hex", "align": "left|center|right", "fontFamily": "FontName" },
             { "type": "image", "id": "uuid", "x": number, "y": number, "w": number, "h": number, "src": "placeholder", "objectFit": "cover|contain", "alt": "Description of image to generate" }
          ]
        }
      ]
    }
    `;

    return withRetry(async () => {
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { responseMimeType: 'application/json', systemInstruction: SYSTEM_INSTRUCTION } 
        });
        
        const fallback: PresentationData = {
            title: eventDetails.name || "Presentation",
            theme: { backgroundColor: "#111827", titleColor: "#ffffff", textColor: "#e5e7eb", accentColor: "#d946ef", titleFont: "Inter", bodyFont: "Inter" },
            slides: [{ id: uuidv4(), type: 'title', elements: [{ type: 'text', id: uuidv4(), x: 10, y: 40, w: 80, h: 20, content: eventDetails.name, fontSize: 40, fontWeight: 'bold', fontStyle: 'normal', textDecoration: 'none', color: '#ffffff', align: 'center', fontFamily: 'Inter' }] }]
        };

        return safeJSONParse(response.text || '', fallback);
    });
};

export const generateChartData = async (query: string): Promise<any> => {
    // Add strict schema for Chart.js
    const schema = {
        type: Type.OBJECT,
        properties: {
            labels: { type: Type.ARRAY, items: { type: Type.STRING } },
            datasets: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        label: { type: Type.STRING },
                        data: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                        backgroundColor: { type: Type.ARRAY, items: { type: Type.STRING } }
                    }
                }
            }
        }
    };

    const prompt = `Generate Chart.js data for: "${query}". Return JSON with labels and datasets.`;
    return withRetry(async () => {
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { responseMimeType: 'application/json', responseSchema: schema, systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return safeJSONParse(response.text || '', {});
    });
};

export const refineText = async (currentText: string, instruction: string): Promise<string> => {
    return withRetry(async () => {
        const prompt = `Refine the following text based on this instruction: "${instruction}".
        
        Original Text:
        "${currentText}"
        
        Return ONLY the refined text. No explanations or markdown code blocks.`;
        
        const response = await ai.models.generateContent({ 
            model: standardTextModel, 
            contents: prompt, 
            config: { systemInstruction: SYSTEM_INSTRUCTION } 
        });
        return cleanAIResponse(response.text || currentText);
    });
};
