
import * as React from 'react';
import { useState, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { AssetType } from './types';
import type { EventDetails, GeneratedAsset, ColorInfo, LogoAsset, PresentationData } from './types';
import LogoUploader from './components/LogoUploader';
import AppHeader from './components/AppHeader';
import GenerationLoader from './components/GenerationLoader';
import AssetCard from './components/AssetCard';
import AssetViewerModal from './components/AssetViewerModal';
import ImageEditorModal from './components/ImageEditorModal';
import TextListEditorModal from './components/TextListEditorModal';
import TextEditorModal from './components/TextEditorModal';
import PaletteEditorModal from './components/PaletteEditorModal';
import PhotoRealismEditorModal from './components/PhotoRealismEditorModal';
import StyleApprovalModal from './components/StyleApprovalModal';
import LogoGenerationModal from './components/LogoGenerationModal';
import QRCodeGeneratorModal from './components/QRCodeGeneratorModal';
import QRCodeEditorModal from './components/QRCodeEditorModal';
import AddAssetsModal from './components/AddAssetsModal';
import FolderTabs from './components/FolderTabs';
import MoveToFolderModal from './components/MoveToFolderModal';
import PresentationEditorModal from './components/PresentationEditorModal';
import VideoEditorModal from './components/VideoEditorModal';
import Toast from './components/Toast';
import { useProjectHistory } from './hooks/useProjectHistory';
import { useProjectPersistence } from './hooks/useProjectPersistence';
import { useAIOrchestrator } from './hooks/useAIOrchestrator';
import { fileToBase64, generatePrintReadyPdf, base64ToFile } from './utils';
import { describeImageStyle, generateSeamlessPattern } from './services/geminiService';

const assetGenerators = [
    { type: AssetType.Palette, title: 'Color Palette' },
    { type: AssetType.Slogans, title: 'Event Slogans' },
    { type: AssetType.SocialPost, title: 'Social Media Post' },
    { type: AssetType.NameTag, title: 'Name Tag' },
    { type: AssetType.Banner, title: 'Event Banner' },
    { type: AssetType.EventSignage, title: 'Event Signage' },
    { type: AssetType.HangingSignage, title: 'Hanging Signage' },
    { type: AssetType.OutdoorSignage, title: 'Outdoor Signage' },
    { type: AssetType.DoorSignage, title: 'Door Signage' },
    { type: AssetType.EaselSignage, title: 'Easel Signage' },
    { type: AssetType.LocationSignage, title: 'Location Signage' },
    { type: AssetType.RoomSignage, title: 'Room Signage' },
    { type: AssetType.StandUpPillarBanner, title: 'Stand-up Pillar Banner' },
    { type: AssetType.FeatherFlag, title: 'Feather Flag' },
    { type: AssetType.TeardropFlag, title: 'Teardrop Flag' },
    { type: AssetType.QRCode, title: 'QR Code' },
    { type: AssetType.SeamlessPattern, title: 'Seamless Pattern' },
    { type: AssetType.Tshirt, title: 'T-shirt' },
    { type: AssetType.TshirtBack, title: 'T-shirt Back' },
    { type: AssetType.TshirtSleeve, title: 'T-shirt Sleeve' },
    { type: AssetType.Lanyard, title: 'Lanyard' },
    { type: AssetType.SwagBag, title: 'Swag Bag' },
    { type: AssetType.StickerSheet, title: 'Sticker Sheet' },
    { type: AssetType.EmailHeader, title: 'Email Header' },
    { type: AssetType.SocialStory, title: 'Social Story' },
    { type: AssetType.PresentationSlide, title: 'Slide (Static)' },
    { type: AssetType.Presentation, title: 'Full Deck' },
    { type: AssetType.VideoTeaser, title: 'Motion Teaser' },
    { type: AssetType.WifiSign, title: 'Wi-Fi Sign' },
    { type: AssetType.ThankYouNote, title: 'Thank You Note' },
    { type: AssetType.AgendaHighlights, title: 'Agenda' },
    { type: AssetType.Hat, title: 'Hat' },
    { type: AssetType.Folder, title: 'Folder' },
    { type: AssetType.WaterBottle, title: 'Water Bottle' },
    { type: AssetType.Menu, title: 'Menu' },
    { type: AssetType.BackWall, title: 'Back Wall' },
    { type: AssetType.Stairs, title: 'Stairs' },
    { type: AssetType.RegistrationCounter, title: 'Registration Counter' },
    { type: AssetType.WelcomeCounter, title: 'Welcome Desk' },
    { type: AssetType.RegistrationBackWall, title: 'Registration Wall' },
    { type: AssetType.TechnologyCounter, title: 'Tech Counter' },
    { type: AssetType.Kiosk, title: 'Kiosk' },
    { type: AssetType.FloorPlan, title: 'Floor Plan' },
    { type: AssetType.LocationIntel, title: 'Location Intel' },
    { type: AssetType.AppIcon, title: 'App Icon' },
    { type: AssetType.Favicon, title: 'Favicon' },
    { type: AssetType.SocialProfile, title: 'Social Profile' },
    { type: AssetType.LogoMonochrome, title: 'Mono Logo' },
    { type: AssetType.LogoReversed, title: 'Reversed Logo' },
    { type: AssetType.MarketingCopy, title: 'Marketing Copy' },
    { type: AssetType.StyleGuide, title: 'Brand Guide' },
    { type: AssetType.RunOfShow, title: 'Run of Show' },
    { type: AssetType.Soundtrack, title: 'Sonic Identity' },
    { type: AssetType.GlassDoor, title: 'Glass Door' },
    { type: AssetType.GlassRotatingDoor, title: 'Rotating Door' },
    { type: AssetType.GlassDoubleDoor, title: 'Double Door' },
    { type: AssetType.MainStageBackdrop, title: 'Main Stage' },
];

const ensureProtocol = (url: string) => url && !url.match(/^[a-zA-Z]+:\/\//) ? `https://${url}` : url;

const App: React.FC = () => {
    const [view, setView] = useState<'setup' | 'dashboard'>('setup');
    const [step, setStep] = useState(1);
    const [eventDetails, setEventDetails] = useState<EventDetails>({ name: '', description: '', date: '', location: '', website: '', email: '', incorporateLocationStyle: false, venueQuery: '' });
    const [logos, setLogos] = useState<LogoAsset[]>([]);
    const [styleImage, setStyleImage] = useState<{ file: File, url: string } | null>(null);
    const [masterPatternImage, setMasterPatternImage] = useState<File | null>(null);
    const [selectedAssets, setSelectedAssets] = useState<Set<AssetType>>(new Set());
    const [generatedAssets, setGeneratedAssets] = useState<GeneratedAsset[]>([]);
    const [folders, setFolders] = useState<{id: string, name: string}[]>([]);
    const [activeView, setActiveView] = useState('all'); 
    const [viewingAsset, setViewingAsset] = useState<GeneratedAsset | null>(null);
    const [editingAsset, setEditingAsset] = useState<GeneratedAsset | null>(null);
    const [isStyleApprovalOpen, setIsStyleApprovalOpen] = useState(false);
    const [isLogoGeneratorOpen, setIsLogoGeneratorOpen] = useState(false);
    const [isQRCodeGeneratorOpen, setIsQRCodeGeneratorOpen] = useState(false);
    const [isAddAssetsOpen, setIsAddAssetsOpen] = useState(false);
    const [assetToMove, setAssetToMove] = useState<GeneratedAsset | null>(null);
    const [styleDescription, setStyleDescription] = useState('');
    const [colorPalette, setColorPalette] = useState<ColorInfo[]>([]);
    const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' } | null>(null);

    const showToast = (message: string, type: 'success' | 'error') => setToast({ message, type });

    const { pushSnapshot, undo, redo, canUndo, canRedo } = useProjectHistory({
        eventDetails, generatedAssets, logos, styleDescription, colorPalette, folders
    }, (restored) => {
        setEventDetails(restored.eventDetails);
        setGeneratedAssets(restored.generatedAssets);
        setLogos(restored.logos);
        setStyleDescription(restored.styleDescription);
        setColorPalette(restored.colorPalette);
        setFolders(restored.folders);
    });

    const { handleSaveProject, handleLoadProject, isExporting, isLoadingProject } = useProjectPersistence({
        eventDetails, generatedAssets, logos, styleDescription, colorPalette, folders, showToast,
        onLoad: async (data) => {
            setEventDetails(data.eventDetails);
            setStyleDescription(data.styleDescription);
            setColorPalette(data.colorPalette);
            setFolders(data.folders);
            setGeneratedAssets(data.generatedAssets);
            setLogos(data.logos);
            setView('dashboard');
        }
    });

    const { generateAssets, isLoading, setIsLoading, generationProgress, setGenerationProgress } = useAIOrchestrator({
        eventDetails, logos, styleImage, masterPatternImage, colorPalette, setColorPalette, generatedAssets, setGeneratedAssets, ensureProtocol
    });

    const handleGenerate = async () => {
        setIsLoading(true);
        try {
            if (styleImage) {
                const desc = await describeImageStyle(styleImage.file);
                setStyleDescription(desc); 
                setIsLoading(false); 
                setIsStyleApprovalOpen(true);
            } else {
                pushSnapshot();
                await startGeneration('');
            }
        } catch (e) {
            console.error(e);
            showToast("Error analysing style.", "error");
            setIsLoading(false);
        }
    };

    const startGeneration = async (approvedDescription: string) => {
        try {
            setView('dashboard');
            
            // Core assets logic: Only generate Palette/Monochrome/Reversed if not present
            const existingTypes = new Set(generatedAssets.map(a => a.type));
            const coreAssets = [AssetType.Palette, AssetType.LogoMonochrome, AssetType.LogoReversed].filter(t => !existingTypes.has(t));
            const assetsToGenerateSet = new Set<AssetType>([...Array.from(selectedAssets) as AssetType[], ...coreAssets]);
            
            const newAssets: GeneratedAsset[] = [];
            assetsToGenerateSet.forEach(type => {
                const gen = assetGenerators.find(g => g.type === type);
                newAssets.push({ id: uuidv4(), type, title: gen?.title || 'Asset', content: '', isLoading: true });
            });

            // Inject Uploaded Visuals if not present
            if (logos.length > 0 && !generatedAssets.some(a => a.type === AssetType.Logo)) {
                const logoAssets = await Promise.all(logos.map(async l => {
                    const b64 = await fileToBase64(l.file);
                    return { id: uuidv4(), type: AssetType.Logo, title: l.name, content: `data:${b64.type};base64,${b64.data}`, isLoading: false } as GeneratedAsset;
                }));
                newAssets.unshift(...logoAssets);
            }
            if (styleImage && !generatedAssets.some(a => a.title === 'Style Reference')) {
                const b64 = await fileToBase64(styleImage.file);
                newAssets.push({ id: uuidv4(), type: AssetType.SocialPost, title: 'Style Reference', content: `data:${b64.type};base64,${b64.data}`, isLoading: false });
            }
            if (masterPatternImage && !generatedAssets.some(a => a.title === 'Master Pattern Source')) {
                const b64 = await fileToBase64(masterPatternImage);
                newAssets.push({ id: uuidv4(), type: AssetType.SeamlessPattern, title: 'Master Pattern Source', content: `data:${b64.type};base64,${b64.data}`, isLoading: false });
            }

            if (newAssets.filter(a => a.isLoading).length === 0) {
                if (newAssets.length > 0) setGeneratedAssets(prev => [...prev, ...newAssets]);
                setIsLoading(false);
                return;
            }

            setGeneratedAssets(prev => [...prev, ...newAssets]);
            setGenerationProgress({ current: 0, total: newAssets.filter(a => a.isLoading).length });
            await generateAssets(newAssets.filter(a => a.isLoading), approvedDescription);
            
        } catch (error) {
            console.error("Startup failed:", error);
            showToast("Failed to start.", "error");
            setIsLoading(false);
        }
    };

    const handleLogoKitCreated = (kit: { primary: { content: string; name: string }; monochrome: { content: string; name: string }; reversed: { content: string; name: string }; }) => {
        pushSnapshot();
        const primaryFile = base64ToFile({ data: kit.primary.content.split(',')[1], type: 'image/png', name: 'primary-logo.png' });
        
        // Update Logos state
        const newLogoAsset = { id: uuidv4(), file: primaryFile, url: kit.primary.content, name: kit.primary.name, isGenerated: true };
        setLogos(prev => [newLogoAsset, ...prev]);

        // Add to generated assets immediately
        const newAssets: GeneratedAsset[] = [
            { id: uuidv4(), type: AssetType.Logo, title: kit.primary.name, content: kit.primary.content, isLoading: false },
            { id: uuidv4(), type: AssetType.LogoMonochrome, title: kit.monochrome.name, content: kit.monochrome.content, isLoading: false },
            { id: uuidv4(), type: AssetType.LogoReversed, title: kit.reversed.name, content: kit.reversed.content, isLoading: false }
        ];
        
        setGeneratedAssets(prev => [...newAssets, ...prev]);
        setIsLogoGeneratorOpen(false);
        showToast("Logo Kit added to project!", "success");
    };

    const handleDeleteAsset = (id: string) => {
        pushSnapshot();
        setGeneratedAssets(prev => prev.filter(a => a.id !== id));
        if (viewingAsset?.id === id) setViewingAsset(null);
        showToast("Deleted (Undo available)", "success");
    };

    const handleOverwriteAsset = (id: string, content: any, params?: any) => {
        pushSnapshot();
        setGeneratedAssets(prev => prev.map(a => a.id === id ? { ...a, content, generationParams: params || a.generationParams } : a));
        setEditingAsset(null);
    };

    const handleUploadAsset = async (file: File, type: AssetType, makeSeamless: boolean) => {
        pushSnapshot();
        try {
            if (makeSeamless && type === AssetType.SeamlessPattern) {
                const id = uuidv4();
                const newAsset: GeneratedAsset = { 
                    id, 
                    type, 
                    title: `Generated Pattern (${file.name})`, 
                    content: '', 
                    isLoading: true 
                };
                setGeneratedAssets(prev => [...prev, newAsset]);
                
                // Call generation logic
                const paletteStrings = colorPalette.map(c => `${c.name} (${c.hex})`);
                const result = await generateSeamlessPattern(file, eventDetails, paletteStrings);
                
                setGeneratedAssets(prev => prev.map(a => a.id === id ? { ...a, content: result, isLoading: false } : a));
                showToast("Pattern generated successfully!", "success");
            } else {
                const b64 = await fileToBase64(file);
                const newAsset: GeneratedAsset = { 
                    id: uuidv4(), 
                    type, 
                    title: file.name, 
                    content: `data:${b64.type};base64,${b64.data}`, 
                    isLoading: false 
                };
                setGeneratedAssets(prev => [...prev, newAsset]);
                showToast("Asset uploaded successfully", "success");
            }
        } catch (error) {
            console.error("Upload failed:", error);
            showToast("Failed to upload/process asset.", "error");
        }
    };

    const renderEditor = () => {
        if (!editingAsset) return null;
        if (editingAsset.type === AssetType.Presentation) return <PresentationEditorModal isOpen={true} onClose={() => setEditingAsset(null)} presentation={editingAsset.content as PresentationData} onSave={d => handleOverwriteAsset(editingAsset.id, d)} eventDetails={eventDetails} colorPalette={colorPalette.map(c => c.hex)} primaryLogoUrl={logos[0]?.url} generatedAssets={generatedAssets} />;
        if (editingAsset.type === AssetType.VideoTeaser) return <VideoEditorModal isOpen={true} onClose={() => setEditingAsset(null)} asset={editingAsset} onSave={d => handleOverwriteAsset(editingAsset.id, d)} primaryLogoUrl={logos[0]?.url} />;
        if ([AssetType.RunOfShow, AssetType.MarketingCopy, AssetType.StyleGuide, AssetType.Soundtrack].includes(editingAsset.type)) return <TextEditorModal asset={editingAsset} onClose={() => setEditingAsset(null)} onOverwrite={handleOverwriteAsset} onSaveAsNew={() => {}} />;
        if (editingAsset.type === AssetType.Palette) return <PaletteEditorModal asset={editingAsset} onClose={() => setEditingAsset(null)} onOverwrite={handleOverwriteAsset} onSaveAsNew={() => {}} />;
        if (editingAsset.type === AssetType.PhotorealisticShot && editingAsset.sourceAssetId) {
             const src = generatedAssets.find(a => a.id === editingAsset.sourceAssetId);
             if (src) return <PhotoRealismEditorModal asset={editingAsset} sourceAsset={src} onClose={() => setEditingAsset(null)} onOverwrite={handleOverwriteAsset} onSavePhotoShotAsNew={() => {}} />;
        }
        if (editingAsset.type === AssetType.QRCode) return <QRCodeEditorModal isOpen={true} onClose={() => setEditingAsset(null)} onSave={(id, d) => handleOverwriteAsset(id, d.content, d.params)} asset={editingAsset} primaryLogoUrl={logos[0]?.url} />;
        
        return <ImageEditorModal asset={editingAsset} onClose={() => setEditingAsset(null)} onOverwrite={handleOverwriteAsset} onSaveAsNew={() => {}} eventDetails={eventDetails} colorPalette={colorPalette.map(c => c.hex)} />;
    };

    const filteredAssets = useMemo(() => {
        if (activeView === 'favorites') return generatedAssets.filter(a => a.isFavorite);
        if (activeView !== 'all') return generatedAssets.filter(a => a.folderId === activeView);
        return generatedAssets;
    }, [generatedAssets, activeView]);

    return (
        <div className="bg-transparent min-h-screen text-white font-sans relative">
            <div className="animated-background"></div>
            <div className="relative z-10">
                <AppHeader onNewProject={() => { if(confirm("New?")) { pushSnapshot(); setView('setup'); setStep(1); setGeneratedAssets([]); setLogos([]); } }} onLoadProject={handleLoadProject} onSaveProject={handleSaveProject} isSaveDisabled={view === 'setup'} isExporting={isExporting} showDashboardControls={view === 'dashboard'} onUndo={undo} onRedo={redo} canUndo={canUndo} canRedo={canRedo} />
                <main className="pt-24 pb-12">
                    {(isLoading || isLoadingProject) && <GenerationLoader current={generationProgress.current} total={generationProgress.total} assets={generatedAssets} />}
                    {view === 'setup' && <LogoUploader eventDetails={eventDetails} setEventDetails={setEventDetails} logos={logos} setLogos={setLogos} styleImage={styleImage} setStyleImage={setStyleImage} selectedAssets={selectedAssets} setSelectedAssets={setSelectedAssets} onGenerate={handleGenerate} isLoading={isLoading} assetGenerators={assetGenerators} step={step} setStep={setStep} onOpenLogoGenerator={() => setIsLogoGeneratorOpen(true)} onOpenQRCodeGenerator={() => setIsQRCodeGeneratorOpen(true)} onGenerateVariations={() => {}} setMasterPatternImage={setMasterPatternImage} />}
                    {view === 'dashboard' && !isLoading && (
                        <div className="container mx-auto px-4 animate-fade-in">
                             <FolderTabs folders={folders} activeView={activeView} onSelectView={setActiveView} onCreateFolder={() => { const n = prompt("Name"); if(n) setFolders(p => [...p, {id: uuidv4(), name: n}]); }} />
                             {filteredAssets.length === 0 ? <div className="text-center py-20 bg-white/5 rounded-lg"><button onClick={() => setIsAddAssetsOpen(true)} className="btn-primary">Add Asset</button></div> : 
                                 <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                                    {filteredAssets.map(a => <AssetCard key={a.id} asset={a} onView={setViewingAsset} onEdit={setEditingAsset} onDelete={handleDeleteAsset} onGeneratePhotorealisticShot={async (src) => { const n = {id: uuidv4(), type: AssetType.PhotorealisticShot, title: `Photo: ${src.title}`, content: '', isLoading: true, sourceAssetId: src.id}; setGeneratedAssets(p => [...p, n]); await generateAssets([n], styleDescription); }} onToggleFavorite={a => { pushSnapshot(); setGeneratedAssets(p => p.map(x => x.id === a.id ? {...x, isFavorite: !x.isFavorite} : x)); }} onMoveToFolder={a => setAssetToMove(a)} />)}
                                    <button onClick={() => setIsAddAssetsOpen(true)} className="border-2 border-dashed border-white/20 rounded-lg hover:bg-white/5 flex flex-col items-center justify-center text-gray-400 min-h-[200px]"><span>+ Add</span></button>
                                 </div>
                             }
                        </div>
                    )}
                </main>
                <AssetViewerModal asset={viewingAsset} onClose={() => setViewingAsset(null)} onEdit={a => { setViewingAsset(null); setEditingAsset(a); }} eventDetails={eventDetails} onExportPdf={(a, o) => generatePrintReadyPdf(a.content as string, a.type, a.title, eventDetails.name, o)} onDelete={handleDeleteAsset} colorPalette={colorPalette} logos={logos} />
                {renderEditor()}
                <StyleApprovalModal isOpen={isStyleApprovalOpen} onClose={() => setIsStyleApprovalOpen(false)} onApprove={d => { setIsStyleApprovalOpen(false); startGeneration(d); }} styleImagePreviewUrl={styleImage?.url || ''} initialDescription={styleDescription} />
                <LogoGenerationModal isOpen={isLogoGeneratorOpen} onClose={() => setIsLogoGeneratorOpen(false)} onLogoKitCreated={handleLogoKitCreated} eventDetails={eventDetails} />
                <AddAssetsModal isOpen={isAddAssetsOpen} onClose={() => setIsAddAssetsOpen(false)} onAddAssets={types => { setIsAddAssetsOpen(false); const newAssets: GeneratedAsset[] = Array.from(types).map((t: AssetType) => ({ id: uuidv4(), type: t, title: assetGenerators.find(g => g.type === t)?.title || 'Asset', content: '', isLoading: true })); setGeneratedAssets(p => [...p, ...newAssets]); generateAssets(newAssets, styleDescription); }} onUploadAsset={handleUploadAsset} existingAssets={new Set(generatedAssets.map(a => a.type))} assetGenerators={assetGenerators} />
                <MoveToFolderModal isOpen={!!assetToMove} onClose={() => setAssetToMove(null)} folders={folders} onMove={fid => { if(assetToMove) { pushSnapshot(); setGeneratedAssets(p => p.map(a => a.id === assetToMove.id ? {...a, folderId: fid} : a)); setAssetToMove(null); } }} onCreateFolder={n => setFolders(p => [...p, {id: uuidv4(), name: n}])} />
                {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
            </div>
        </div>
    );
};

export default App;