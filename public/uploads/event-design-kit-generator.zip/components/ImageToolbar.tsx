import React from 'react';

interface ImageToolbarProps {
    isCropping: boolean;
    hasEdits: boolean;
    onZoom: (direction: number) => void;
    onRotate: () => void;
    onCropToggle: () => void;
    onReset: () => void;
    onApplyCrop: () => void;
}

const ToolButton: React.FC<{
    onClick: () => void;
    title: string;
    children: React.ReactNode;
    className?: string;
    disabled?: boolean;
}> = ({ onClick, title, children, className = '', disabled = false }) => (
    <button
        onClick={onClick}
        title={title}
        disabled={disabled}
        className={`p-2 rounded-lg bg-white/5 border border-white/10 hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors backdrop-blur-md ${className}`}
    >
        {children}
    </button>
);

const ImageToolbar: React.FC<ImageToolbarProps> = ({
    isCropping,
    hasEdits,
    onZoom,
    onRotate,
    onCropToggle,
    onReset,
    onApplyCrop,
}) => {
    return (
        <div className="flex items-center justify-center gap-3 p-2 rounded-full bg-black/30 border border-white/10 backdrop-blur-lg">
            {!isCropping ? (
                <>
                    <ToolButton onClick={() => onZoom(0.1)} title="Zoom In" disabled={isCropping}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" /></svg>
                    </ToolButton>
                    <ToolButton onClick={() => onZoom(-0.1)} title="Zoom Out" disabled={isCropping}>
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM13 10H7" /></svg>
                    </ToolButton>
                    <ToolButton onClick={onRotate} title="Rotate" disabled={isCropping}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 9a9 9 0 0114.65-5.32L20 5M20 15a9 9 0 01-14.65 5.32L4 19" /></svg>
                    </ToolButton>
                    <ToolButton onClick={onCropToggle} title="Crop">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.121 14.121L19 19M4.879 4.879L9.757 9.757" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M1 1h5v5M1 19h5v-5M19 1h-5v5M19 19h-5v-5" /></svg>
                    </ToolButton>
                    <ToolButton onClick={onReset} title="Reset" disabled={!hasEdits || isCropping}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 9a9 9 0 0114.65-5.32L20 5M20 15a9 9 0 01-14.65 5.32L4 19" /></svg>
                    </ToolButton>
                </>
            ) : (
                <>
                    <ToolButton onClick={onCropToggle} title="Cancel Crop" className="bg-red-500/20 !border-red-500/30">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </ToolButton>
                    <ToolButton onClick={onApplyCrop} title="Apply Crop" className="bg-green-500/20 !border-green-500/30">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                    </ToolButton>
                </>
            )}
        </div>
    );
};

export default ImageToolbar;
