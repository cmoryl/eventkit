import React, { useEffect } from 'react';
import type { VenueSearchResult } from '../types';
import Spinner from './Spinner';

interface VenueSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVenue: (venue: VenueSearchResult) => void;
  searchResults: VenueSearchResult[];
  isLoading: boolean;
  error: string | null;
}

const VenueSearchModal: React.FC<VenueSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectVenue,
  searchResults,
  isLoading,
  error,
}) => {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-lg flex flex-col animate-scale-in max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-xl font-bold text-white">Select Venue</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </header>
        
        <div className="p-6 overflow-y-auto">
          {isLoading && (
            <div className="flex flex-col items-center justify-center text-center text-gray-300 h-48">
              <Spinner className="w-8 h-8 mb-4" />
              <p>Searching for venues...</p>
              <p className="text-sm text-gray-500">Please allow location access if prompted.</p>
            </div>
          )}
          {error && (
            <div className="text-center text-red-400 bg-red-900/50 p-4 rounded-lg h-48 flex flex-col items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mb-3" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                <p className="font-semibold">Search Failed</p>
                <p className="text-sm mt-1">{error}</p>
            </div>
          )}
          {!isLoading && !error && (
            <div className="space-y-3">
              {searchResults.map((venue) => (
                <button
                  key={venue.placeId}
                  onClick={() => onSelectVenue(venue)}
                  className="w-full text-left p-4 bg-white/5 rounded-lg border border-transparent hover:border-fuchsia-500/50 hover:bg-white/10 transition-all"
                >
                  <p className="font-semibold text-white">{venue.name}</p>
                  <p className="text-sm text-gray-400 mt-1">{venue.address}</p>
                </button>
              ))}
            </div>
          )}
        </div>
        
        <footer className="p-4 border-t border-white/10 flex justify-end">
          <button onClick={onClose} className="btn-secondary">
            Cancel
          </button>
        </footer>
      </div>
    </div>
  );
};

export default VenueSearchModal;