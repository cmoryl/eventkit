import React, { useState, useEffect } from 'react';
import type { VenueSearchResult } from '../types';
import { findVenueDetails } from '../services/geminiService';
import Spinner from './Spinner';

interface FloorPlanSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (venue: VenueSearchResult) => void;
  eventLocation: string; // Used to help narrow down search
}

const FloorPlanSetupModal: React.FC<FloorPlanSetupModalProps> = ({ isOpen, onClose, onGenerate, eventLocation }) => {
    const [venueQuery, setVenueQuery] = useState('');
    const [searchResults, setSearchResults] = useState<VenueSearchResult[]>([]);
    const [selectedVenue, setSelectedVenue] = useState<VenueSearchResult | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') onClose();
        };
        if (isOpen) {
            // Reset state when modal opens
            setVenueQuery('');
            setSearchResults([]);
            setSelectedVenue(null);
            setIsLoading(false);
            setError(null);
            window.addEventListener('keydown', handleKeyDown);
        }
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, onClose]);

    const handleSearch = async () => {
        if (!venueQuery.trim()) return;
        setIsLoading(true);
        setError(null);
        setSearchResults([]);
        setSelectedVenue(null);
        try {
            const results = await findVenueDetails(venueQuery, eventLocation);
            if (results.length === 0) {
                setError("No venues found. Try a more specific name or address.");
            } else {
                setSearchResults(results);
            }
        } catch (e) {
            console.error("Venue search failed:", e);
            setError(e instanceof Error ? e.message : "An unknown error occurred.");
        } finally {
            setIsLoading(false);
        }
    };
    
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-lg flex flex-col animate-scale-in max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">Setup Floor Plan</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="p-6 flex-grow overflow-y-auto">
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="venue-query-modal" className="block text-sm font-medium text-gray-300 mb-2">Venue Name or Address</label>
                            <div className="flex gap-2">
                                <input 
                                    id="venue-query-modal" 
                                    type="text" 
                                    value={venueQuery}
                                    onChange={(e) => setVenueQuery(e.target.value)}
                                    placeholder="e.g., 'Moscone Center, San Francisco'"
                                    className="flex-grow bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all"
                                />
                                <button onClick={handleSearch} disabled={isLoading || !venueQuery.trim()} className="btn-secondary px-4 py-2 flex-shrink-0">
                                    {isLoading ? <Spinner /> : 'Search'}
                                </button>
                            </div>
                        </div>

                        <div className="min-h-[200px]">
                            {isLoading && (
                                <div className="flex items-center justify-center h-full text-gray-400">
                                    <Spinner className="w-6 h-6 mr-2" /> Searching...
                                </div>
                            )}
                            {error && (
                                <div className="flex items-center justify-center h-full text-red-400 bg-red-900/50 p-4 rounded-lg">
                                    {error}
                                </div>
                            )}
                            {!isLoading && !error && searchResults.length > 0 && (
                                <div className="space-y-2">
                                     <p className="text-sm text-gray-400">Select a venue from the search results:</p>
                                     {searchResults.map(venue => (
                                         <button 
                                            key={venue.placeId}
                                            onClick={() => setSelectedVenue(venue)}
                                            className={`w-full text-left p-3 rounded-lg border transition-all ${selectedVenue?.placeId === venue.placeId ? 'bg-fuchsia-900/50 border-fuchsia-500 ring-2 ring-fuchsia-500/50' : 'bg-white/5 border-transparent hover:border-white/20'}`}
                                         >
                                             <p className="font-semibold text-white">{venue.name}</p>
                                             <p className="text-xs text-gray-400 mt-1">{venue.address}</p>
                                         </button>
                                     ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end space-x-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    <button onClick={() => onGenerate(selectedVenue!)} disabled={!selectedVenue} className="btn-primary">
                        Generate Floor Plan
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default FloorPlanSetupModal;