
// Fix: Created the AssetViewerModal component to display a detailed view of a selected asset.
import React, { useState } from 'react';
import { AssetType } from '../types';
import type { GeneratedAsset, ColorInfo, EventDetails, PdfExportOptions } from '../types';
import LocationIntelCard from './LocationIntelCard';
import PdfExportModal from './PdfExportModal';
import BrandStyleGuide from './BrandStyleGuide';
import { isPrintable } from '../utils';

interface AssetViewerModalProps {
  asset: GeneratedAsset | null;
  onClose: () => void;
  onEdit: (asset: GeneratedAsset) => void;
  eventDetails: EventDetails;
  onExportPdf: (asset: GeneratedAsset, options: PdfExportOptions) => void;
  onDelete: (assetId: string) => void;
  colorPalette?: ColorInfo[];
  logos?: { url: string; name: string }[];
}

const AssetViewerModal: React.FC<AssetViewerModalProps> = ({ asset, onClose, onEdit, eventDetails, onExportPdf, onDelete, colorPalette, logos }) => {
    const [isPdfExportOpen, setIsPdfExportOpen] = useState(false);
    const [isViewingLarge, setIsViewingLarge] = useState(false);
    const [showBackSide, setShowBackSide] = useState(false);

    if (!asset) return null;
    
    const handleEdit = () => {
        onEdit(asset);
        onClose();
    };

    const handleDelete = () => {
        // Optimistic delete handled by parent, here we just trigger
        onDelete(asset.id);
        // Modal closes automatically via parent state update usually, but explicit close is safe
        onClose();
    };
    
    const handleDownload = () => {
        const contentToDownload = showBackSide && asset.backContent ? asset.backContent : asset.content;
        
        if (typeof contentToDownload === 'string' && contentToDownload.startsWith('data:image')) {
            const link = document.createElement('a');
            link.href = contentToDownload;
            link.download = `${eventDetails.name.replace(/\s/g, '_')}_${asset.title.replace(/\s/g, '_')}${showBackSide ? '_back' : ''}.png`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
            // For text or data, create a blob and download
            const contentString = typeof contentToDownload === 'string' ? contentToDownload : JSON.stringify(contentToDownload, null, 2);
            const blob = new Blob([contentString], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${eventDetails.name.replace(/\s/g, '_')}_${asset.title.replace(/\s/g, '_')}.txt`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }
    };

    const handleCopyText = () => {
        const content = showBackSide && asset.backContent ? asset.backContent : asset.content;
        if (typeof content === 'string') {
             navigator.clipboard.writeText(content).then(() => {
                 alert("Text copied to clipboard!");
             });
        }
    }

    const renderAssetContent = () => {
        const contentToRender = showBackSide && asset.backContent ? asset.backContent : asset.content;

        switch (asset.type) {
            case AssetType.Palette:
                const colors = asset.content as ColorInfo[];
                return (
                    <div className="p-4 grid grid-cols-1 gap-3">
                        {colors.map(color => (
                            <div key={color.hex} className="flex items-center gap-4 bg-black/20 p-3 rounded-lg">
                                <div className="w-12 h-12 rounded-md border border-white/10 shadow-sm" style={{ backgroundColor: color.hex }} />
                                <div className="flex-grow">
                                    <p className="font-bold text-white">{color.name}</p>
                                    <p className="text-sm font-mono text-gray-300">{color.hex.toUpperCase()}</p>
                                </div>
                                <div className="text-xs text-gray-400 text-right font-mono space-y-0.5">
                                    <p>{color.rgb}</p>
                                    <p>{color.cmyk}</p>
                                    <p>{color.pantone}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                );
            case AssetType.Slogans:
                const slogans = contentToRender as string[];
                return (
                    <div className="p-4">
                        <ul className="list-disc list-inside space-y-2 text-gray-200 text-lg">
                            {Array.isArray(slogans) && slogans.map((slogan, i) => <li key={i}>{slogan}</li>)}
                        </ul>
                    </div>
                );
            case AssetType.StyleGuide:
                return (
                    <div className="w-full">
                        <BrandStyleGuide 
                            content={contentToRender as string} 
                            colorPalette={colorPalette} 
                            logos={logos}
                            eventDetails={eventDetails}
                        />
                    </div>
                );
            case AssetType.LocationIntel:
            case AssetType.RunOfShow:
            case AssetType.MarketingCopy:
            case AssetType.Soundtrack:
                return <LocationIntelCard content={contentToRender as string} isModalView />;
            default:
                 if (typeof contentToRender === 'string' && contentToRender.startsWith('data:image')) {
                    return (
                        <div className="relative group flex justify-center items-center w-full h-full">
                            <img 
                                src={contentToRender} 
                                alt={asset.title} 
                                className="max-w-full max-h-full object-contain cursor-zoom-in" 
                                onClick={() => setIsViewingLarge(true)}
                            />
                            <button
                                onClick={() => setIsViewingLarge(true)}
                                className="absolute top-2 right-2 p-2 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-sm transition-all duration-300 opacity-0 group-hover:opacity-100 text-white"
                                title="View Full Screen"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                                </svg>
                            </button>
                        </div>
                    );
                 }
                 return <div className="p-4 text-gray-400">Preview not available.</div>
        }
    };

    const isTextAsset = [AssetType.MarketingCopy, AssetType.RunOfShow, AssetType.Soundtrack, AssetType.Slogans, AssetType.LocationIntel].includes(asset.type);
    const hasBackSide = !!asset.backContent;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className={`bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full flex flex-col animate-scale-in ${asset.type === AssetType.StyleGuide ? 'max-w-6xl max-h-[95vh]' : 'max-w-4xl max-h-[90vh]'}`}
                onClick={(e) => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">{asset.title} {showBackSide ? '(Back)' : ''}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>
                
                <div className="flex-grow p-4 overflow-y-auto flex justify-center bg-black/20 relative custom-scrollbar">
                     <div className={`w-full ${asset.type === AssetType.StyleGuide ? 'max-w-full' : 'max-w-3xl'}`}>
                        {renderAssetContent()}
                     </div>
                     
                     {hasBackSide && (
                        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-black/40 p-1 rounded-lg flex gap-1 backdrop-blur-md border border-white/10">
                            <button 
                                onClick={() => setShowBackSide(false)}
                                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${!showBackSide ? 'bg-white text-black shadow-sm' : 'text-gray-400 hover:text-white'}`}
                            >
                                Front
                            </button>
                            <button 
                                onClick={() => setShowBackSide(true)}
                                className={`px-3 py-1 text-xs font-medium rounded transition-colors ${showBackSide ? 'bg-white text-black shadow-sm' : 'text-gray-400 hover:text-white'}`}
                            >
                                Back
                            </button>
                        </div>
                     )}
                </div>
                
                <footer className="p-4 border-t border-white/10 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <p className="text-sm text-gray-400">{asset.type.replace(/_/g, ' ')}</p>
                        <button onClick={handleDelete} className="text-red-400 hover:text-red-300 text-xs flex items-center gap-1 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            Delete
                        </button>
                    </div>
                    <div className="flex items-center gap-3">
                         {isTextAsset && <button onClick={handleCopyText} className="btn-secondary">Copy Text</button>}
                         <button onClick={handleDownload} className="btn-secondary">Download {showBackSide ? 'Back' : ''}</button>
                         {isPrintable(asset.type) && <button onClick={() => setIsPdfExportOpen(true)} className="btn-secondary">Export PDF</button>}
                         <button onClick={handleEdit} className="btn-primary">Edit</button>
                    </div>
                </footer>
            </div>

            {/* Full Screen Lightbox */}
            {isViewingLarge && (
                <div 
                    className="fixed inset-0 z-[70] bg-black/95 backdrop-blur-sm flex items-center justify-center animate-fade-in p-4"
                    onClick={() => setIsViewingLarge(false)}
                >
                     <img 
                        src={showBackSide && asset.backContent ? asset.backContent : asset.content as string} 
                        alt={asset.title} 
                        className="max-w-full max-h-full object-contain shadow-2xl"
                        onClick={(e) => e.stopPropagation()} 
                    />
                    <button 
                        onClick={() => setIsViewingLarge(false)}
                        className="absolute top-6 right-6 p-3 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
                        title="Close Full Screen"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                             <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            )}

            {isPrintable(asset.type) && (
                <PdfExportModal
                    isOpen={isPdfExportOpen}
                    onClose={() => setIsPdfExportOpen(false)}
                    asset={showBackSide && asset.backContent ? { ...asset, content: asset.backContent, title: `${asset.title} (Back)` } : asset}
                    onExport={(options) => {
                        onExportPdf(showBackSide && asset.backContent ? { ...asset, content: asset.backContent, title: `${asset.title} (Back)` } : asset, options);
                        setIsPdfExportOpen(false);
                    }}
                />
            )}
        </div>
    );
};

export default AssetViewerModal;