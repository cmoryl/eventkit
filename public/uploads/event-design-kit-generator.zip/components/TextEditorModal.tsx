
import React, { useState, useEffect } from 'react';
import type { GeneratedAsset } from '../types';
import { refineText } from '../services/geminiService';
import Spinner from './Spinner';
import * as LucideIcons from 'lucide-react';
import { Sparkles, Check, AlignLeft, Bold, Italic, List, Maximize2, Minimize2 } from 'lucide-react';

interface TextEditorModalProps {
  asset: GeneratedAsset;
  onClose: () => void;
  onOverwrite: (assetId: string, newContent: string) => void;
  onSaveAsNew: (assetId: string, newContent: string) => void;
}

const TextEditorModal: React.FC<TextEditorModalProps> = ({ asset, onClose, onOverwrite, onSaveAsNew }) => {
    const [textContent, setTextContent] = useState('');
    const [showSaveOptions, setShowSaveOptions] = useState(false);
    const [isRefining, setIsRefining] = useState(false);
    const [isPreviewMode, setIsPreviewMode] = useState(false);

    useEffect(() => {
        if (asset && typeof asset.content === 'string') {
            setTextContent(asset.content);
        }
    }, [asset]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose]);

    const handleOverwrite = () => {
        onOverwrite(asset.id, textContent);
    };

    const handleSaveAsNew = () => {
        onSaveAsNew(asset.id, textContent);
    };
    
    const handleSmartRefine = async (instruction: string) => {
        if (!textContent.trim()) return;
        setIsRefining(true);
        try {
            const result = await refineText(textContent, instruction);
            setTextContent(result);
        } catch (e) {
            console.error("Text refinement failed", e);
            alert("Could not refine text. Please try again.");
        } finally {
            setIsRefining(false);
        }
    };

    if (!asset) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col animate-scale-in"
                onClick={(e) => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white flex items-center gap-2">
                        <AlignLeft size={20} className="text-fuchsia-500"/>
                        Edit: {asset.title}
                    </h2>
                    <div className="flex gap-2">
                        <button onClick={() => setIsPreviewMode(!isPreviewMode)} className={`p-2 rounded hover:bg-white/10 transition-colors ${isPreviewMode ? 'text-fuchsia-400' : 'text-gray-400'}`} title={isPreviewMode ? "Edit Mode" : "Preview Mode"}>
                            {isPreviewMode ? <Minimize2 size={20}/> : <Maximize2 size={20}/>}
                        </button>
                        <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                            <LucideIcons.X size={24}/>
                        </button>
                    </div>
                </header>
                
                {/* Magic Toolbar */}
                {!isPreviewMode && (
                    <div className="flex items-center gap-2 p-2 bg-white/5 border-b border-white/10 overflow-x-auto custom-scrollbar">
                        <span className="text-xs font-bold text-fuchsia-400 uppercase mr-2 flex items-center gap-1"><Sparkles size={12}/> AI Tools:</span>
                        <button onClick={() => handleSmartRefine("Make it shorter and more concise")} disabled={isRefining} className="btn-tertiary text-xs py-1 whitespace-nowrap">Shorten</button>
                        <button onClick={() => handleSmartRefine("Expand on this with more detail")} disabled={isRefining} className="btn-tertiary text-xs py-1 whitespace-nowrap">Expand</button>
                        <button onClick={() => handleSmartRefine("Make the tone more professional and corporate")} disabled={isRefining} className="btn-tertiary text-xs py-1 whitespace-nowrap">Professional</button>
                        <button onClick={() => handleSmartRefine("Make the tone exciting and energetic")} disabled={isRefining} className="btn-tertiary text-xs py-1 whitespace-nowrap">Exciting</button>
                        <button onClick={() => handleSmartRefine("Fix grammar and spelling errors")} disabled={isRefining} className="btn-tertiary text-xs py-1 whitespace-nowrap">Fix Grammar</button>
                        {isRefining && <Spinner className="w-4 h-4 text-fuchsia-500 ml-auto"/>}
                    </div>
                )}

                <div className="flex-grow p-0 overflow-hidden flex flex-col relative">
                    {isPreviewMode ? (
                        <div className="w-full h-full p-6 overflow-y-auto bg-white/5 text-gray-200 prose prose-invert max-w-none custom-scrollbar">
                            {/* Simple Markdown Preview */}
                            {textContent.split('\n').map((line, i) => (
                                <p key={i} className="mb-2 min-h-[1em]">{line}</p>
                            ))}
                        </div>
                    ) : (
                        <textarea
                            value={textContent}
                            onChange={(e) => setTextContent(e.target.value)}
                            className="w-full h-full bg-transparent border-none text-white font-mono text-sm p-6 focus:ring-0 outline-none resize-none leading-relaxed custom-scrollbar"
                            placeholder="Enter text here..."
                            spellCheck={false}
                        />
                    )}
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end items-center gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    {showSaveOptions ? (
                        <>
                            <button onClick={() => setShowSaveOptions(false)} className="btn-secondary">Back</button>
                            <button onClick={handleOverwrite} className="btn-secondary bg-sky-600/50 border-sky-500/50 hover:bg-sky-600/80">Overwrite Original</button>
                            <button onClick={handleSaveAsNew} className="btn-primary">Save as New Copy</button>
                        </>
                    ) : (
                        <button onClick={() => setShowSaveOptions(true)} className="btn-primary flex items-center gap-2">
                            <Check size={16}/> Save Changes
                        </button>
                    )}
                </footer>
            </div>
        </div>
    );
};

export default TextEditorModal;
