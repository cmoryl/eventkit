import React, { useState, useEffect } from 'react';
import type { GeneratedAsset, PdfExportOptions } from '../types';
import { paperSizes, printDimensionsMap } from '../utils';

interface PdfExportModalProps {
    isOpen: boolean;
    onClose: () => void;
    onExport: (options: PdfExportOptions) => void;
    asset: GeneratedAsset;
}

const Label: React.FC<{ htmlFor: string, children: React.ReactNode, tooltip?: string }> = ({ htmlFor, children, tooltip }) => (
    <label htmlFor={htmlFor} className="block text-sm font-medium text-gray-300 mb-2 group relative">
        {children}
        {tooltip && (
            <span className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-max max-w-xs bg-gray-900 text-white text-xs rounded-lg py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none shadow-lg border border-white/10">
                {tooltip}
            </span>
        )}
    </label>
);

const PdfExportModal: React.FC<PdfExportModalProps> = ({ isOpen, onClose, onExport, asset }) => {
    const assetDims = printDimensionsMap[asset.type];
    const defaultPaperSize = assetDims && (assetDims.w > 11 || assetDims.h > 11) ? 'custom' : 'letter';

    const [paperSize, setPaperSize] = useState(defaultPaperSize);
    const [bleed, setBleed] = useState(0.125);
    const [showTrimMarks, setShowTrimMarks] = useState(true);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') onClose();
        };
        if (isOpen) {
            window.addEventListener('keydown', handleKeyDown);
        }
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [isOpen, onClose]);

    const handleExportClick = () => {
        onExport({ paperSize, bleed, showTrimMarks });
    };

    if (!isOpen) return null;

    const inputClass = "w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-md flex flex-col animate-scale-in" onClick={(e) => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">PDF Export Settings</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="p-6 space-y-6">
                    <div>
                        <Label htmlFor="paper-size" tooltip="Choose the paper size for the PDF document. 'Asset Dimensions' will create a PDF sized exactly to the design plus bleed.">
                            Paper Size
                        </Label>
                        <select id="paper-size" value={paperSize} onChange={(e) => setPaperSize(e.target.value)} className={inputClass}>
                            <option value="custom">Asset Dimensions ({assetDims?.w}" x {assetDims?.h}")</option>
                            <option value="letter">Letter (8.5" x 11")</option>
                            <option value="legal">Legal (8.5" x 14")</option>
                            <option value="tabloid">Tabloid (11" x 17")</option>
                            <option value="a4">A4 (8.27" x 11.69")</option>
                            <option value="a3">A3 (11.69" x 16.54")</option>
                        </select>
                    </div>
                    <div>
                        <Label htmlFor="bleed-size" tooltip="The bleed is an extra margin of your design that extends beyond the trim edge, ensuring no white borders after cutting.">
                            Bleed (inches)
                        </Label>
                        <input id="bleed-size" type="number" step="0.01" min="0" value={bleed} onChange={(e) => setBleed(parseFloat(e.target.value) || 0)} className={inputClass} />
                    </div>
                    <div>
                        <label className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition-colors group relative">
                            <input
                                type="checkbox"
                                checked={showTrimMarks}
                                onChange={(e) => setShowTrimMarks(e.target.checked)}
                                className="h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400"
                            />
                            <span className="text-gray-300 font-medium">Include Trim Marks</span>
                            <span className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-max max-w-xs bg-gray-900 text-white text-xs rounded-lg py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none shadow-lg border border-white/10">
                                Adds lines showing the printer where to trim the paper to the final size.
                            </span>
                        </label>
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end space-x-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    <button onClick={handleExportClick} className="btn-primary">Export PDF</button>
                </footer>
            </div>
        </div>
    );
};

export default PdfExportModal;