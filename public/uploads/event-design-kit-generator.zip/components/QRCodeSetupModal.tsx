// Fix: Created the missing QRCodeSetupModal component.
import React, { useState, useEffect } from 'react';
import Spinner from './Spinner';

interface QRCodeSetupModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (details: { url: string; color: string; bgColor: string; }) => void;
    initialUrl?: string;
    initialColor?: string;
    initialBgColor?: string;
}

const QRCodeSetupModal: React.FC<QRCodeSetupModalProps> = ({
    isOpen,
    onClose,
    onSave,
    initialUrl = '',
    initialColor = '#000000',
    initialBgColor = '#FFFFFF',
}) => {
    const [url, setUrl] = useState(initialUrl);
    const [color, setColor] = useState(initialColor);
    const [bgColor, setBgColor] = useState(initialBgColor);

    useEffect(() => {
        if (isOpen) {
            setUrl(initialUrl);
            setColor(initialColor);
            setBgColor(initialBgColor);
        }
    }, [isOpen, initialUrl, initialColor, initialBgColor]);

    const handleSave = () => {
        if (!url.trim()) {
            alert('Please enter a URL for the QR code.');
            return;
        }
        onSave({ url, color, bgColor });
    };
    
    if (!isOpen) return null;

    const inputClass = "w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[60] p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-lg flex flex-col animate-scale-in" onClick={(e) => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">QR Code Setup</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="p-6 space-y-6">
                    <div>
                        <label htmlFor="qr-url-setup" className="block text-sm font-medium text-gray-300 mb-2">
                           URL to encode
                        </label>
                        <input id="qr-url-setup" type="url" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://your-event-website.com" className={inputClass} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                           <label className="block text-sm font-medium text-gray-300 mb-2">Code Color</label>
                           <input type="color" value={color} onChange={e => setColor(e.target.value)} className="w-full h-12 p-1 bg-white/5 border border-white/20 rounded-lg cursor-pointer" />
                        </div>
                         <div>
                           <label className="block text-sm font-medium text-gray-300 mb-2">Background Color</label>
                           <input type="color" value={bgColor} onChange={e => setBgColor(e.target.value)} className="w-full h-12 p-1 bg-white/5 border border-white/20 rounded-lg cursor-pointer" />
                        </div>
                    </div>
                     <p className="text-xs text-gray-400 text-center">More advanced options (like adding a logo) will be available in the editor after generation.</p>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end space-x-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    <button onClick={handleSave} className="btn-primary">Save Details</button>
                </footer>
            </div>
        </div>
    );
};

export default QRCodeSetupModal;
