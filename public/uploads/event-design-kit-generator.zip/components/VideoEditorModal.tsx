
import React, { useState, useEffect } from 'react';
import type { GeneratedAsset } from '../types';
import { generateEventVideo } from '../services/geminiService';
import Spinner from './Spinner';

interface VideoEditorModalProps {
    isOpen: boolean;
    onClose: () => void;
    asset: GeneratedAsset;
    onSave: (content: string) => void;
    primaryLogoUrl?: string;
}

const VideoEditorModal: React.FC<VideoEditorModalProps> = ({ isOpen, onClose, asset, onSave, primaryLogoUrl }) => {
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    const [isGenerating, setIsGenerating] = useState(false);
    const [videoUrl, setVideoUrl] = useState<string>('');

    useEffect(() => {
        if (asset && typeof asset.content === 'string') {
            setVideoUrl(asset.content);
        }
    }, [asset]);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [onClose]);

    const handleRegenerate = async () => {
        setIsGenerating(true);
        try {
            // We pass a dummy eventDetails object because we are overriding the prompt anyway
            const dummyDetails = { name: asset.title, description: '', date: '', location: '', website: '', email: '', incorporateLocationStyle: false };
            const result = await generateEventVideo(dummyDetails, '', aspectRatio, prompt);
            setVideoUrl(result);
        } catch (e) {
            console.error(e);
            alert("Failed to regenerate video.");
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSave = () => {
        onSave(videoUrl);
        onClose();
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-gray-900 border border-white/10 rounded-lg shadow-2xl w-full max-w-4xl flex flex-col animate-scale-in max-h-[90vh]" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">Edit Video Teaser</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="flex-grow p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-black/50 rounded-lg flex items-center justify-center overflow-hidden relative">
                        {isGenerating ? (
                            <div className="flex flex-col items-center">
                                <Spinner className="w-10 h-10 mb-4 text-fuchsia-500"/>
                                <p className="text-gray-400 text-sm">Generating video (this may take a minute)...</p>
                            </div>
                        ) : (
                            <video 
                                src={videoUrl} 
                                controls 
                                autoPlay 
                                loop 
                                className="max-w-full max-h-[50vh] object-contain"
                                key={videoUrl} // Force re-render on url change
                            />
                        )}
                    </div>

                    <div className="space-y-6">
                        <div>
                            <label className="text-sm font-medium text-gray-300 mb-2 block">Aspect Ratio</label>
                            <div className="flex gap-2 bg-white/5 p-1 rounded-lg">
                                <button 
                                    onClick={() => setAspectRatio('16:9')}
                                    className={`flex-1 py-2 text-xs font-bold rounded transition-colors ${aspectRatio === '16:9' ? 'bg-fuchsia-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                >
                                    Landscape (16:9)
                                </button>
                                <button 
                                    onClick={() => setAspectRatio('9:16')}
                                    className={`flex-1 py-2 text-xs font-bold rounded transition-colors ${aspectRatio === '9:16' ? 'bg-fuchsia-600 text-white' : 'text-gray-400 hover:text-white'}`}
                                >
                                    Portrait (9:16)
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-medium text-gray-300 mb-2 block">Refine Prompt</label>
                            <textarea 
                                value={prompt}
                                onChange={(e) => setPrompt(e.target.value)}
                                placeholder="Describe the video style, motion, and mood... (e.g. 'Slow motion cinematic pan of a neon stage')"
                                rows={4}
                                className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all resize-none"
                            />
                        </div>

                        <button 
                            onClick={handleRegenerate}
                            disabled={isGenerating || !prompt}
                            className="btn-primary w-full py-3 flex items-center justify-center"
                        >
                            {isGenerating ? <Spinner className="w-4 h-4 mr-2"/> : 'Regenerate Video'}
                        </button>
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    <button onClick={handleSave} className="btn-primary" disabled={isGenerating}>Save Changes</button>
                </footer>
            </div>
        </div>
    );
};

export default VideoEditorModal;
