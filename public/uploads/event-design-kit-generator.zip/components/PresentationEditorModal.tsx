
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement, PointElement, LineElement } from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import * as LucideIcons from 'lucide-react';
import { 
    Type, Image, BarChart, Square, MousePointer2, Plus, Trash2, Copy, 
    Layers, Download, Save, X, Move, Bold, Italic, Underline, AlignLeft, 
    AlignCenter, AlignRight, Sparkles, Upload, Monitor, Palette, Layout,
    MoreHorizontal, Stamp, Smile, Search, RotateCcw, RotateCw
} from 'lucide-react';
import type { PresentationData, Slide, SlideElement, TextElement, ChartElement, ShapeElement, IconElement, EventDetails, BackgroundConfig, GeneratedAsset } from '../types';
import { generateChartData, generateBrandedImage, generateIcon } from '../services/geminiService';
import { generatePptx, fileToBase64 } from '../utils';
import Spinner from './Spinner';
import { v4 as uuidv4 } from 'uuid';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement, PointElement, LineElement);

interface PresentationEditorModalProps {
    isOpen: boolean;
    onClose: () => void;
    presentation: PresentationData;
    onSave: (newData: PresentationData) => void;
    eventDetails: EventDetails;
    colorPalette: string[];
    primaryLogoUrl?: string;
    generatedAssets?: GeneratedAsset[];
}

const GOOGLE_FONTS = [
    "Inter", "Roboto", "Open Sans", "Lato", "Montserrat", "Oswald", "Raleway", 
    "Merriweather", "Playfair Display", "Nunito", "Rubik", "Ubuntu", "Poppins", 
    "Fira Sans", "Work Sans", "Quicksand", "Barlow", "Syne", "Bebas Neue", "Anton"
];

const PRESET_ICONS = [
    "Star", "Heart", "Check", "X", "ArrowRight", "ArrowLeft", "Home", "User", "Users",
    "Settings", "Mail", "Phone", "MapPin", "Calendar", "Clock", "Search", "Menu",
    "Globe", "Briefcase", "Award", "Target", "Zap", "Activity", "BarChart2", "PieChart",
    "Camera", "Video", "Music", "Mic", "Speaker", "Lock", "Unlock"
];

// --- SUB-COMPONENTS ---

const ResizeHandles: React.FC<{ onMouseDown: (e: React.MouseEvent, dir: string) => void }> = ({ onMouseDown }) => {
    const handleStyle = "absolute w-3 h-3 bg-white border border-fuchsia-500 rounded-full z-50 pointer-events-auto shadow-sm hover:scale-125 transition-transform";
    return (
        <>
            <div onMouseDown={(e) => onMouseDown(e, 'nw')} className={`${handleStyle} -top-1.5 -left-1.5 cursor-nwse-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'n')} className={`${handleStyle} -top-1.5 left-[50%] -ml-1.5 cursor-ns-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'ne')} className={`${handleStyle} -top-1.5 -right-1.5 cursor-nesw-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'w')} className={`${handleStyle} top-[50%] -mt-1.5 -left-1.5 cursor-ew-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'e')} className={`${handleStyle} top-[50%] -mt-1.5 -right-1.5 cursor-ew-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'sw')} className={`${handleStyle} -bottom-1.5 -left-1.5 cursor-nesw-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 's')} className={`${handleStyle} -bottom-1.5 left-[50%] -ml-1.5 cursor-ns-resize`} />
            <div onMouseDown={(e) => onMouseDown(e, 'se')} className={`${handleStyle} -bottom-1.5 -right-1.5 cursor-nwse-resize`} />
        </>
    );
};

const SelectionOverlay: React.FC<{ element: SlideElement, onResizeStart: (e: React.MouseEvent, dir: string) => void }> = ({ element, onResizeStart }) => (
    <div 
        className="absolute pointer-events-none z-10 border-2 border-fuchsia-500 box-border"
        style={{
            left: `${element.x}%`,
            top: `${element.y}%`,
            width: `${element.w}%`,
            height: `${element.h}%`,
        }}
    >
        <ResizeHandles onMouseDown={onResizeStart} />
    </div>
);

const FloatingToolbar: React.FC<{ 
    element: TextElement, 
    onUpdate: (id: string, updates: Partial<TextElement>) => void 
}> = ({ element, onUpdate }) => {
    const toggleStyle = (prop: 'fontWeight' | 'fontStyle' | 'textDecoration', value: string, offValue: string) => {
        onUpdate(element.id, { [prop]: element[prop] === value ? offValue : value });
    };

    return (
        <div 
            className="absolute z-50 bg-gray-900 rounded-full shadow-xl border border-white/20 flex items-center gap-1 p-1.5 -translate-x-1/2 animate-fade-in-fast"
            style={{
                left: `${element.x + element.w / 2}%`,
                top: `calc(${element.y}% - 50px)`,
            }}
            onMouseDown={(e) => e.stopPropagation()}
        >
            <button onClick={() => toggleStyle('fontWeight', 'bold', 'normal')} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.fontWeight === 'bold' ? 'bg-fuchsia-600' : ''}`}><Bold size={14}/></button>
            <button onClick={() => toggleStyle('fontStyle', 'italic', 'normal')} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.fontStyle === 'italic' ? 'bg-fuchsia-600' : ''}`}><Italic size={14}/></button>
            <button onClick={() => toggleStyle('textDecoration', 'underline', 'none')} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.textDecoration === 'underline' ? 'bg-fuchsia-600' : ''}`}><Underline size={14}/></button>
            <div className="w-px h-4 bg-white/20 mx-1"></div>
            <button onClick={() => onUpdate(element.id, {align: 'left'})} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.align === 'left' ? 'bg-white/20' : ''}`}><AlignLeft size={14}/></button>
            <button onClick={() => onUpdate(element.id, {align: 'center'})} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.align === 'center' ? 'bg-white/20' : ''}`}><AlignCenter size={14}/></button>
            <button onClick={() => onUpdate(element.id, {align: 'right'})} className={`p-1.5 rounded-full hover:bg-white/20 text-white ${element.align === 'right' ? 'bg-white/20' : ''}`}><AlignRight size={14}/></button>
        </div>
    );
};

const InlineTextEditor: React.FC<{
    element: TextElement,
    onSave: (val: string) => void
}> = ({ element, onSave }) => {
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const [value, setValue] = useState(element.content);

    useEffect(() => {
        if (textareaRef.current) {
            textareaRef.current.focus();
            textareaRef.current.select();
        }
    }, []);

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            return;
        }
        if (e.key === 'Escape') {
            onSave(value);
        }
    };

    return (
        <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onBlur={() => onSave(value)}
            onKeyDown={handleKeyDown}
            className="absolute z-20 bg-transparent outline-none resize-none overflow-hidden p-0 m-0 border-none"
            style={{
                left: `${element.x}%`,
                top: `${element.y}%`,
                width: `${element.w}%`,
                height: `${element.h}%`,
                fontSize: `${element.fontSize}px`,
                fontWeight: element.fontWeight,
                fontStyle: element.fontStyle,
                textDecoration: element.textDecoration,
                color: element.color,
                textAlign: element.align,
                fontFamily: element.fontFamily,
                lineHeight: 1.2
            }}
        />
    );
};

const snap = (value: number, targets: number[], threshold: number = 1): number | null => {
    let closest = null;
    let minDist = threshold;
    for (const t of targets) {
        const dist = Math.abs(value - t);
        if (dist < minDist) {
            minDist = dist;
            closest = t;
        }
    }
    return closest;
};

// --- MAIN EDITOR ---

const PresentationEditorModal: React.FC<PresentationEditorModalProps> = ({ isOpen, onClose, presentation, onSave, eventDetails, colorPalette, primaryLogoUrl, generatedAssets = [] }) => {
    if (!isOpen || !presentation || !presentation.slides) return null;

    const [data, setData] = useState<PresentationData>(presentation);
    const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
    const [selectedElementId, setSelectedElementId] = useState<string | null>(null);
    
    // Internal History
    const [history, setHistory] = useState<PresentationData[]>([presentation]);
    const [historyIndex, setHistoryIndex] = useState(0);

    // Interaction State
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);
    const [resizeHandle, setResizeHandle] = useState<string | null>(null);
    const [isEditingText, setIsEditingText] = useState(false);
    const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
    const [initialElState, setInitialElState] = useState<any>(null);
    const [guides, setGuides] = useState<{ orientation: 'vertical' | 'horizontal'; position: number }[]>([]);
    
    const canvasRef = useRef<HTMLDivElement>(null);

    // Tool states
    const [activeTab, setActiveTab] = useState<'element' | 'slide' | 'theme'>('slide');
    const [bgPrompt, setBgPrompt] = useState('');
    const [isGeneratingBg, setIsGeneratingBg] = useState(false);
    const [isGeneratingChart, setIsGeneratingChart] = useState(false);
    
    // Chart creation state
    const [showChartInput, setShowChartInput] = useState(false);
    const [chartQuery, setChartQuery] = useState('');

    // Icon Modal State
    const [isIconModalOpen, setIsIconModalOpen] = useState(false);
    const [iconSearch, setIconSearch] = useState('');
    const [iconPrompt, setIconPrompt] = useState('');
    const [isGeneratingIcon, setIsGeneratingIcon] = useState(false);

    // Font Loading
    useEffect(() => {
        if (!document.getElementById('google-fonts-link')) {
            const link = document.createElement('link');
            link.id = 'google-fonts-link';
            link.href = `https://fonts.googleapis.com/css2?family=${GOOGLE_FONTS.map(f => f.replace(' ', '+')).join('&family=')}&display=swap`;
            link.rel = 'stylesheet';
            document.head.appendChild(link);
        }
    }, []);

    useEffect(() => { 
        if (presentation && presentation.slides) {
            setData(presentation); 
            setHistory([presentation]);
            setHistoryIndex(0);
        }
    }, [presentation]);

    // Keyboard Shortcuts
    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (isEditingText) return;

            // Delete Element
            if ((e.key === 'Delete' || e.key === 'Backspace') && selectedElementId) {
                const newSlides = [...data.slides];
                newSlides[currentSlideIndex].elements = newSlides[currentSlideIndex].elements.filter(el => el.id !== selectedElementId);
                updateDataWithHistory({ ...data, slides: newSlides });
                setSelectedElementId(null);
            }

            // Undo: Ctrl+Z
            if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) {
                e.preventDefault();
                handleUndo();
            }

            // Redo: Ctrl+Y or Ctrl+Shift+Z
            if (((e.metaKey || e.ctrlKey) && e.key === 'y') || ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === 'z')) {
                e.preventDefault();
                handleRedo();
            }

            // Duplicate: Ctrl+D
            if ((e.metaKey || e.ctrlKey) && e.key === 'd' && selectedElementId) {
                e.preventDefault();
                const slide = data.slides[currentSlideIndex];
                const element = slide.elements.find(el => el.id === selectedElementId);
                if (element) {
                    const clone = { ...element, id: uuidv4(), x: element.x + 2, y: element.y + 2 };
                    const newSlides = [...data.slides];
                    newSlides[currentSlideIndex].elements.push(clone);
                    updateDataWithHistory({ ...data, slides: newSlides });
                    setSelectedElementId(clone.id);
                }
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [data, currentSlideIndex, selectedElementId, isEditingText, history, historyIndex]);

    const currentSlide = data.slides[currentSlideIndex] || data.slides[0];
    const selectedElement = currentSlide?.elements.find(el => el.id === selectedElementId);

    // --- HELPERS ---

    const updateDataWithHistory = (newData: PresentationData) => {
        const newHistory = history.slice(0, historyIndex + 1);
        newHistory.push(newData);
        // Limit history size to 50
        if (newHistory.length > 50) newHistory.shift();
        
        setHistory(newHistory);
        setHistoryIndex(newHistory.length - 1);
        setData(newData);
    };

    const handleUndo = () => {
        if (historyIndex > 0) {
            setHistoryIndex(historyIndex - 1);
            setData(history[historyIndex - 1]);
        }
    };

    const handleRedo = () => {
        if (historyIndex < history.length - 1) {
            setHistoryIndex(historyIndex + 1);
            setData(history[historyIndex + 1]);
        }
    };

    const updateElement = (id: string, updates: Partial<SlideElement>) => {
        const newSlides = [...data.slides];
        const slide = newSlides[currentSlideIndex];
        slide.elements = slide.elements.map(el => el.id === id ? { ...el, ...updates } as SlideElement : el);
        // We only push to history on mouse up or explicit save, not every drag frame
        // But for direct property edits, we push
        // For dragging, we handle history in handleMouseUp
        setData({ ...data, slides: newSlides });
    };

    const commitElementUpdate = () => {
        updateDataWithHistory(data);
    };

    const updateSlideBackground = (config: Partial<BackgroundConfig>) => {
        const newSlides = [...data.slides];
        const slide = newSlides[currentSlideIndex];
        slide.backgroundConfig = { ...slide.backgroundConfig, ...config, type: config.type || slide.backgroundConfig?.type || 'solid', value: config.value || slide.backgroundConfig?.value || '#FFFFFF' };
        if (config.value && (config.type === 'solid' || config.type === 'gradient' || config.type === 'image')) {
            slide.background = config.value;
        }
        updateDataWithHistory({ ...data, slides: newSlides });
    };

    const applyBackgroundToAll = () => {
        const newSlides = data.slides.map(slide => ({
            ...slide,
            background: currentSlide.background,
            backgroundConfig: { ...currentSlide.backgroundConfig }
        }));
        updateDataWithHistory({ ...data, slides: newSlides as Slide[] });
        alert("Background applied to all slides!");
    };

    const applyElementToAll = () => {
        if (!selectedElement) return;
        const newSlides = data.slides.map((slide, idx) => {
            if (idx === currentSlideIndex) return slide;
            const clone = { ...selectedElement, id: uuidv4() };
            return {
                ...slide,
                elements: [...slide.elements, clone]
            };
        });
        updateDataWithHistory({ ...data, slides: newSlides });
        alert("Element cloned to all slides!");
    };

    const handleDeleteSlide = (idx: number) => {
        if(data.slides.length > 1) { 
            const newSlides = data.slides.filter((_, i) => i !== idx);
            // Clear selection to prevent ghost element crash
            setSelectedElementId(null);
            
            const newData = {...data, slides: newSlides};
            updateDataWithHistory(newData);
            
            if(currentSlideIndex >= idx) {
                setCurrentSlideIndex(Math.max(0, currentSlideIndex - 1));
            }
        }
    };

    const handleDuplicateSlide = (idx: number) => {
        const slide = data.slides[idx];
        const newSlide = JSON.parse(JSON.stringify(slide));
        newSlide.id = uuidv4();
        // Regenerate element IDs
        newSlide.elements = newSlide.elements.map((el: any) => ({ ...el, id: uuidv4() }));
        
        const newSlides = [...data.slides];
        newSlides.splice(idx + 1, 0, newSlide);
        updateDataWithHistory({...data, slides: newSlides});
    };

    // --- INTERACTION HANDLERS ---

    const handleElementClick = (e: React.MouseEvent, id: string) => {
        e.stopPropagation();
        if (selectedElementId !== id) {
            setSelectedElementId(id);
            setIsEditingText(false);
            setActiveTab('element');
        }
    };

    const handleCanvasClick = () => {
        setSelectedElementId(null);
        setIsEditingText(false);
        setActiveTab('slide');
    };

    const handleDoubleClick = (e: React.MouseEvent, id: string, type: string) => {
        e.stopPropagation();
        if (type === 'text') {
            setSelectedElementId(id);
            setIsEditingText(true);
        }
    };

    const handleDragStart = (e: React.MouseEvent, element: SlideElement) => {
        if (isEditingText) return;
        e.stopPropagation();
        setSelectedElementId(element.id);
        setIsDragging(true);
        setDragStart({ x: e.clientX, y: e.clientY });
        setInitialElState({ x: element.x, y: element.y, w: element.w, h: element.h });
        setActiveTab('element');
    };

    const handleResizeStart = (e: React.MouseEvent, dir: string) => {
        e.stopPropagation();
        e.preventDefault();
        setIsResizing(true);
        setResizeHandle(dir);
        setDragStart({ x: e.clientX, y: e.clientY });
        if (selectedElement) {
            setInitialElState({ x: selectedElement.x, y: selectedElement.y, w: selectedElement.w, h: selectedElement.h });
        }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!canvasRef.current || (!isDragging && !isResizing) || !selectedElementId) return;
        
        const canvasRect = canvasRef.current.getBoundingClientRect();
        const dx = (e.clientX - dragStart.x) / canvasRect.width * 100;
        const dy = (e.clientY - dragStart.y) / canvasRect.height * 100;

        const newGuides: { orientation: 'vertical' | 'horizontal'; position: number }[] = [];
        const SNAP_THRES = 1;

        // Collect snap targets
        const xTargets = [0, 50, 100];
        const yTargets = [0, 50, 100];
        currentSlide.elements.forEach(el => {
            if (el.id === selectedElementId) return;
            xTargets.push(el.x, el.x + el.w / 2, el.x + el.w);
            yTargets.push(el.y, el.y + el.h / 2, el.y + el.h);
        });

        if (isDragging) {
            let nextX = initialElState.x + dx;
            let nextY = initialElState.y + dy;
            
            // X Snapping
            let sx = snap(nextX, xTargets, SNAP_THRES);
            if (sx !== null) { nextX = sx; newGuides.push({ orientation: 'vertical', position: sx }); }
            else {
                sx = snap(nextX + initialElState.w / 2, xTargets, SNAP_THRES);
                if (sx !== null) { nextX = sx - initialElState.w / 2; newGuides.push({ orientation: 'vertical', position: sx }); }
                else {
                    sx = snap(nextX + initialElState.w, xTargets, SNAP_THRES);
                    if (sx !== null) { nextX = sx - initialElState.w; newGuides.push({ orientation: 'vertical', position: sx }); }
                }
            }

            // Y Snapping
            let sy = snap(nextY, yTargets, SNAP_THRES);
            if (sy !== null) { nextY = sy; newGuides.push({ orientation: 'horizontal', position: sy }); }
            else {
                sy = snap(nextY + initialElState.h / 2, yTargets, SNAP_THRES);
                if (sy !== null) { nextY = sy - initialElState.h / 2; newGuides.push({ orientation: 'horizontal', position: sy }); }
                else {
                    sy = snap(nextY + initialElState.h, yTargets, SNAP_THRES);
                    if (sy !== null) { nextY = sy - initialElState.h; newGuides.push({ orientation: 'horizontal', position: sy }); }
                }
            }

            updateElement(selectedElementId, {
                x: Math.max(0, Math.min(100, nextX)),
                y: Math.max(0, Math.min(100, nextY))
            });
        } else if (isResizing && resizeHandle) {
            let { x, y, w, h } = initialElState;
            
            // Horizontal Resizing
            if (resizeHandle.includes('e')) {
                const proposedRight = x + w + dx;
                const sx = snap(proposedRight, xTargets, SNAP_THRES);
                if (sx !== null) { w = sx - x; newGuides.push({ orientation: 'vertical', position: sx }); }
                else { w += dx; }
            } else if (resizeHandle.includes('w')) {
                const proposedLeft = x + dx;
                const sx = snap(proposedLeft, xTargets, SNAP_THRES);
                if (sx !== null) { const diff = sx - x; x = sx; w -= diff; newGuides.push({ orientation: 'vertical', position: sx }); }
                else { x += dx; w -= dx; }
            }

            // Vertical Resizing
            if (resizeHandle.includes('s')) {
                const proposedBottom = y + h + dy;
                const sy = snap(proposedBottom, yTargets, SNAP_THRES);
                if (sy !== null) { h = sy - y; newGuides.push({ orientation: 'horizontal', position: sy }); }
                else { h += dy; }
            } else if (resizeHandle.includes('n')) {
                const proposedTop = y + dy;
                const sy = snap(proposedTop, yTargets, SNAP_THRES);
                if (sy !== null) { const diff = sy - y; y = sy; h -= diff; newGuides.push({ orientation: 'horizontal', position: sy }); }
                else { y += dy; h -= dy; }
            }
            
            // Aspect Ratio Locking check
            const isRatioLocked = selectedElement && (selectedElement.type === 'image' || selectedElement.type === 'icon' || (selectedElement.type === 'shape' && e.shiftKey));
            
            if (isRatioLocked && resizeHandle.length === 2 && newGuides.length === 0) {
                 const aspect = initialElState.w / initialElState.h;
                 if (resizeHandle.includes('e') || resizeHandle.includes('w')) {
                    h = w / aspect;
                 } else {
                    w = h * aspect;
                 }
            }

            updateElement(selectedElementId, { x, y, w: Math.max(2, w), h: Math.max(2, h) });
        }
        setGuides(newGuides);
    };

    const handleMouseUp = () => {
        if (isDragging || isResizing) {
            commitElementUpdate();
        }
        setIsDragging(false);
        setIsResizing(false);
        setResizeHandle(null);
        setGuides([]);
    };

    // --- ASSET CREATION ---

    const addElement = (element: SlideElement) => {
        const newSlides = [...data.slides];
        newSlides[currentSlideIndex].elements.push(element);
        updateDataWithHistory({ ...data, slides: newSlides });
        setSelectedElementId(element.id);
        setActiveTab('element');
        setIsIconModalOpen(false);
    };

    const handleAddText = () => addElement({
        type: 'text', id: uuidv4(), x: 30, y: 40, w: 40, h: 10,
        content: 'New Text Layer', fontSize: 24, fontWeight: 'normal', color: data.theme.textColor, align: 'center'
    });

    const handleAddImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const result = await fileToBase64(e.target.files[0]);
            addElement({
                type: 'image', id: uuidv4(), x: 30, y: 30, w: 40, h: 40,
                src: `data:${result.type};base64,${result.data}`, objectFit: 'contain'
            });
        }
        e.target.value = '';
    };

    const handleAddLogo = async () => {
        if (!primaryLogoUrl) return;
        let src = primaryLogoUrl;
        
        if (src.startsWith('blob:')) {
            try {
                const response = await fetch(src);
                const blob = await response.blob();
                const reader = new FileReader();
                src = await new Promise((resolve) => {
                    reader.onloadend = () => resolve(reader.result as string);
                    reader.readAsDataURL(blob);
                });
            } catch (e) {
                console.error("Failed to convert logo blob to base64", e);
            }
        }

        addElement({
            type: 'image', id: uuidv4(), x: 85, y: 85, w: 10, h: 10,
            src: src, objectFit: 'contain'
        });
    };

    const handleAddChart = async () => {
        if (!chartQuery.trim()) return;
        setIsGeneratingChart(true);
        try {
            const chartData = await generateChartData(chartQuery);
            addElement({ type: 'chart', id: uuidv4(), x: 25, y: 25, w: 50, h: 50, chartType: 'bar', data: chartData });
            setShowChartInput(false);
            setChartQuery('');
        } finally { setIsGeneratingChart(false); }
    };

    const handleGenerateBackground = async () => {
        if (!bgPrompt) return;
        setIsGeneratingBg(true);
        try {
            const result = await generateBrandedImage(`Texture background: ${bgPrompt} for event ${eventDetails.name}. Colors: ${colorPalette.join(', ')}`, null, null, '16:9');
            updateSlideBackground({ type: 'image', value: result });
        } finally { setIsGeneratingBg(false); }
    };
    
    // --- ICON HANDLERS ---
    
    const handleAddLibraryIcon = (iconName: string) => {
        addElement({
            type: 'icon', id: uuidv4(), x: 40, y: 40, w: 10, h: 10,
            iconName: iconName, color: data.theme.accentColor
        });
    };
    
    const handleGenerateIcon = async () => {
        if (!iconPrompt) return;
        setIsGeneratingIcon(true);
        try {
            const result = await generateIcon(iconPrompt, data.theme.accentColor);
            addElement({
                type: 'icon', id: uuidv4(), x: 40, y: 40, w: 15, h: 15,
                svgContent: result, color: data.theme.accentColor
            });
        } catch (e) {
            alert("Icon generation failed. Please try again.");
        } finally {
            setIsGeneratingIcon(false);
        }
    }

    // --- RENDER ---

    const bgConfig = currentSlide.backgroundConfig || { type: 'solid', value: currentSlide.background || '#ffffff' };
    const bgStyle: React.CSSProperties = {
        backgroundColor: bgConfig.type === 'solid' ? bgConfig.value : undefined,
        backgroundImage: bgConfig.type !== 'solid' ? (bgConfig.type === 'gradient' ? bgConfig.value : `url(${bgConfig.value})`) : undefined,
        backgroundSize: bgConfig.imageFit || 'cover',
        backgroundPosition: 'center',
        filter: `brightness(${bgConfig.filterBrightness || 100}%) contrast(${bgConfig.filterContrast || 100}%)`
    };

    return (
        <div className="fixed inset-0 bg-black z-[100] flex flex-col animate-fade-in font-sans" onMouseUp={handleMouseUp} onMouseMove={handleMouseMove}>
            {/* Header */}
            <header className="h-14 bg-gray-900 border-b border-white/10 flex items-center justify-between px-4 flex-shrink-0">
                <div className="flex items-center gap-3">
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-gray-400 hover:text-white"><X size={20}/></button>
                    <h2 className="text-white font-bold text-sm truncate max-w-[200px]">{data.title}</h2>
                    <div className="flex items-center gap-1 ml-4 border-l border-white/10 pl-4">
                        <button onClick={handleUndo} disabled={historyIndex === 0} className="p-1.5 rounded hover:bg-white/10 text-gray-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed" title="Undo (Ctrl+Z)"><RotateCcw size={16}/></button>
                        <button onClick={handleRedo} disabled={historyIndex === history.length - 1} className="p-1.5 rounded hover:bg-white/10 text-gray-400 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed" title="Redo (Ctrl+Y)"><RotateCw size={16}/></button>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <button onClick={() => generatePptx(data)} className="btn-secondary text-xs py-1.5 flex items-center gap-2"><Download size={14}/> Export PPTX</button>
                    <button onClick={() => { onSave(data); onClose(); }} className="btn-primary text-xs py-1.5 flex items-center gap-2"><Save size={14}/> Save</button>
                </div>
            </header>

            {/* Creation Bar */}
            <div className="h-12 bg-gray-800 border-b border-white/10 flex items-center px-4 gap-2 overflow-x-auto relative">
                {!showChartInput ? (
                    <>
                        <button onClick={handleAddText} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium"><Type size={16}/> Text</button>
                        <label className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium cursor-pointer">
                            <Image size={16}/> Image <input type="file" hidden accept="image/*" onChange={handleAddImage}/>
                        </label>
                        <button onClick={handleAddLogo} disabled={!primaryLogoUrl} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium disabled:opacity-50"><Stamp size={16}/> Logo</button>
                        <button onClick={() => setIsIconModalOpen(true)} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium"><Smile size={16}/> Icon</button>
                        <button onClick={() => setShowChartInput(true)} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium"><BarChart size={16}/> Chart</button>
                        <button onClick={() => addElement({ type: 'shape', id: uuidv4(), x: 40, y: 40, w: 20, h: 20, shapeType: 'rectangle', backgroundColor: data.theme.accentColor })} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium"><Square size={16}/> Shape</button>
                        <div className="w-px h-6 bg-white/10 mx-2"/>
                        <button onClick={() => setActiveTab('slide')} className="p-2 rounded hover:bg-white/10 text-gray-300 hover:text-white flex items-center gap-2 text-xs font-medium"><Layout size={16}/> Background</button>
                    </>
                ) : (
                    <div className="flex items-center gap-2 w-full animate-fade-in-fast">
                        <BarChart size={16} className="text-fuchsia-500"/>
                        <input 
                            autoFocus
                            type="text" 
                            value={chartQuery} 
                            onChange={(e) => setChartQuery(e.target.value)}
                            placeholder="Describe data (e.g. 'Sales Q1-Q4')"
                            className="bg-black/20 border border-white/10 rounded text-xs text-white p-1.5 outline-none w-64 focus:border-fuchsia-500"
                            onKeyDown={(e) => e.key === 'Enter' && handleAddChart()}
                        />
                        <button onClick={handleAddChart} disabled={isGeneratingChart || !chartQuery.trim()} className="btn-primary text-xs px-3 py-1">
                            {isGeneratingChart ? <Spinner className="w-3 h-3"/> : 'Generate'}
                        </button>
                        <button onClick={() => setShowChartInput(false)} className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-white"><X size={16}/></button>
                    </div>
                )}
            </div>

            <div className="flex-grow flex overflow-hidden">
                {/* Sidebar */}
                <div className="w-48 bg-gray-900 border-r border-white/10 flex flex-col">
                    <div className="flex-grow overflow-y-auto p-3 space-y-3 custom-scrollbar">
                        {data.slides.map((slide, idx) => (
                            <div key={slide.id} className="relative group">
                                <div 
                                    onClick={() => { setCurrentSlideIndex(idx); setSelectedElementId(null); }}
                                    className={`aspect-video bg-white rounded border-2 cursor-pointer overflow-hidden relative transition-all ${currentSlideIndex === idx ? 'border-fuchsia-500 ring-2 ring-fuchsia-500/30' : 'border-transparent hover:border-white/20'}`}
                                >
                                    <div className="absolute inset-0" style={{
                                        backgroundColor: slide.backgroundConfig?.type === 'solid' ? slide.backgroundConfig.value : slide.background,
                                        backgroundImage: slide.backgroundConfig?.type !== 'solid' ? (slide.backgroundConfig?.type === 'gradient' ? slide.backgroundConfig.value : `url(${slide.backgroundConfig?.value || slide.background})`) : undefined,
                                        backgroundSize: 'cover'
                                    }}/>
                                    <div className="absolute bottom-1 left-1 text-[10px] font-bold text-black bg-white/80 px-1.5 rounded">{idx + 1}</div>
                                </div>
                                <div className="absolute top-1 right-1 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={(e) => { e.stopPropagation(); handleDuplicateSlide(idx); }} className="p-1 bg-black/50 hover:bg-black rounded text-white" title="Duplicate"><Copy size={10}/></button>
                                    <button onClick={(e) => { e.stopPropagation(); handleDeleteSlide(idx); }} className="p-1 bg-red-500/80 hover:bg-red-500 rounded text-white" title="Delete"><Trash2 size={10}/></button>
                                </div>
                            </div>
                        ))}
                        <button onClick={() => { const newSlide = { id: uuidv4(), type: 'content', elements: [], background: '#ffffff', backgroundConfig: { type: 'solid', value: '#ffffff' } } as Slide; updateDataWithHistory({...data, slides: [...data.slides, newSlide]}); setCurrentSlideIndex(data.slides.length); }} className="w-full py-3 border-2 border-dashed border-white/10 rounded text-gray-500 hover:text-white hover:border-white/30 transition-colors text-xs flex flex-col items-center gap-1">
                            <Plus size={16}/> Add Slide
                        </button>
                    </div>
                </div>

                {/* Canvas */}
                <div className="flex-grow bg-gray-800 flex items-center justify-center relative overflow-hidden p-8" onClick={handleCanvasClick}>
                    <div ref={canvasRef} className="aspect-video bg-white shadow-2xl relative select-none" style={{ width: '90%', maxWidth: '1200px', ...bgStyle }}>
                        {bgConfig.overlayOpacity ? <div className="absolute inset-0 pointer-events-none z-0" style={{ backgroundColor: `rgba(0,0,0,${bgConfig.overlayOpacity})` }}/> : null}
                        
                        {currentSlide.elements.map(el => {
                            const isSelected = selectedElementId === el.id;
                            const style: React.CSSProperties = { position: 'absolute', left: `${el.x}%`, top: `${el.y}%`, width: `${el.w}%`, height: `${el.h}%`, zIndex: isSelected ? 10 : 1, cursor: isDragging ? 'grabbing' : 'grab' };
                            
                            if (el.type === 'text') {
                                const txt = el as TextElement;
                                return (
                                    <div key={el.id} style={{...style, fontSize: `${txt.fontSize}px`, fontWeight: txt.fontWeight, fontStyle: txt.fontStyle, textDecoration: txt.textDecoration, color: txt.color, textAlign: txt.align, fontFamily: txt.fontFamily, display: 'flex', alignItems: 'center', opacity: (isEditingText && isSelected) ? 0 : 1, whiteSpace: 'pre-wrap'}}
                                        onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)} onDoubleClick={(e) => handleDoubleClick(e, el.id, 'text')}
                                    >
                                        {txt.content}
                                    </div>
                                );
                            }
                            if (el.type === 'image') return <img key={el.id} src={(el as any).src} style={{...style, objectFit: (el as any).objectFit || 'cover'}} onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)} />;
                            
                            if (el.type === 'icon') {
                                const iconEl = el as IconElement;
                                // Render SVG content if AI generated
                                if (iconEl.svgContent) return <img key={el.id} src={iconEl.svgContent} style={{...style, objectFit: 'contain'}} onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)} />;
                                // Render Library Icon using Lucide
                                const IconComponent = (LucideIcons as any)[iconEl.iconName || 'Star'];
                                return (
                                    <div key={el.id} style={{...style, display:'flex', alignItems:'center', justifyContent:'center', color: iconEl.color}} onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)}>
                                        {IconComponent ? React.createElement(IconComponent, { size: '100%', strokeWidth: 1.5 }) : null}
                                    </div>
                                );
                            }

                            if (el.type === 'shape') return <div key={el.id} style={{...style, backgroundColor: (el as any).backgroundColor, borderRadius: (el as any).shapeType === 'circle' ? '50%' : '0'}} onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)} />;
                            if (el.type === 'chart') return <div key={el.id} style={{...style, backgroundColor: 'rgba(255,255,255,0.9)', padding: '10px', borderRadius: '8px'}} onMouseDown={(e) => handleDragStart(e, el)} onClick={(e) => handleElementClick(e, el.id)}><Bar data={(el as any).data} options={{maintainAspectRatio: false}}/></div>;
                            return null;
                        })}

                        {selectedElement && !isEditingText && <SelectionOverlay element={selectedElement} onResizeStart={handleResizeStart} />}
                        {selectedElement?.type === 'text' && !isDragging && !isResizing && !isEditingText && <FloatingToolbar element={selectedElement as TextElement} onUpdate={(id, updates) => { updateElement(id, updates); commitElementUpdate(); }} />}
                        {isEditingText && selectedElement?.type === 'text' && <InlineTextEditor element={selectedElement as TextElement} onSave={(val) => { updateElement(selectedElement.id, { content: val } as any); setIsEditingText(false); commitElementUpdate(); }} />}
                        
                        {guides.map((g, i) => (
                            <div 
                                key={i}
                                className={`absolute bg-fuchsia-500 z-50 pointer-events-none ${g.orientation === 'vertical' ? 'w-px h-full top-0' : 'h-px w-full left-0'}`}
                                style={g.orientation === 'vertical' ? { left: `${g.position}%` } : { top: `${g.position}%` }}
                            />
                        ))}
                    </div>
                </div>

                {/* Inspector */}
                <div className="w-80 bg-gray-900 border-l border-white/10 flex flex-col flex-shrink-0">
                    <div className="flex border-b border-white/10">
                        {selectedElement && <button onClick={() => setActiveTab('element')} className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-wider ${activeTab === 'element' ? 'text-fuchsia-400 border-b-2 border-fuchsia-500 bg-white/5' : 'text-gray-500 hover:text-gray-300'}`}>Element</button>}
                        <button onClick={() => setActiveTab('slide')} className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-wider ${activeTab === 'slide' ? 'text-fuchsia-400 border-b-2 border-fuchsia-500 bg-white/5' : 'text-gray-500 hover:text-gray-300'}`}>Background</button>
                    </div>

                    <div className="flex-grow overflow-y-auto p-4 space-y-6">
                        {activeTab === 'element' && selectedElement && (
                            <div className="animate-fade-in space-y-4">
                                <div className="flex justify-between items-center"><h3 className="text-xs font-bold text-gray-400 uppercase">Properties</h3><button onClick={() => { const newSlides = [...data.slides]; newSlides[currentSlideIndex].elements = newSlides[currentSlideIndex].elements.filter(el => el.id !== selectedElementId); updateDataWithHistory({...data, slides: newSlides}); setSelectedElementId(null); }} className="text-red-400 hover:text-red-300"><Trash2 size={14}/></button></div>
                                
                                <div className="grid grid-cols-2 gap-2">
                                    <button onClick={() => { const slides = [...data.slides]; const els = slides[currentSlideIndex].elements; const idx = els.findIndex(e => e.id === selectedElementId); if(idx < els.length-1) { els.push(els.splice(idx, 1)[0]); updateDataWithHistory({...data, slides}); } }} className="btn-secondary text-xs py-1 flex justify-center"><Layers size={12} className="mr-1"/> Bring Front</button>
                                    <button onClick={() => { const slides = [...data.slides]; const els = slides[currentSlideIndex].elements; const idx = els.findIndex(e => e.id === selectedElementId); if(idx > 0) { els.unshift(els.splice(idx, 1)[0]); updateDataWithHistory({...data, slides}); } }} className="btn-secondary text-xs py-1 flex justify-center"><Layers size={12} className="mr-1"/> Send Back</button>
                                </div>

                                {(selectedElement.type === 'image' || selectedElement.type === 'text' || selectedElement.type === 'icon') && (
                                    <button onClick={applyElementToAll} className="btn-secondary text-xs w-full py-2 mb-2 flex items-center justify-center"><Copy size={12} className="mr-2"/> Apply to All Slides</button>
                                )}

                                {selectedElement.type === 'text' && (
                                    <>
                                        <div className="space-y-2">
                                            <label className="text-xs text-gray-500">Font Family</label>
                                            <select value={(selectedElement as TextElement).fontFamily} onChange={e => { updateElement(selectedElementId!, { fontFamily: e.target.value } as any); commitElementUpdate(); }} className="w-full bg-white/5 border border-white/10 rounded p-2 text-xs text-white outline-none">
                                                {GOOGLE_FONTS.map(f => <option key={f} value={f} style={{fontFamily: f}}>{f}</option>)}
                                            </select>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2">
                                            <div><label className="text-xs text-gray-500">Size</label><input type="number" value={(selectedElement as TextElement).fontSize} onChange={e => { updateElement(selectedElementId!, { fontSize: Number(e.target.value) } as any); commitElementUpdate(); }} className="w-full bg-white/5 border border-white/10 rounded p-2 text-xs text-white"/></div>
                                            <div><label className="text-xs text-gray-500">Color</label><div className="flex items-center bg-white/5 border border-white/10 rounded p-1"><input type="color" value={(selectedElement as TextElement).color} onChange={e => { updateElement(selectedElementId!, { color: e.target.value } as any); commitElementUpdate(); }} className="w-6 h-6 bg-transparent border-none cursor-pointer"/><input type="text" value={(selectedElement as TextElement).color} readOnly className="bg-transparent text-xs text-white w-full ml-2 outline-none"/></div></div>
                                        </div>
                                        <div className="flex flex-wrap gap-2">
                                            {colorPalette.map(c => <button key={c} onClick={() => { updateElement(selectedElementId!, { color: c } as any); commitElementUpdate(); }} className="w-6 h-6 rounded-full border border-white/10" style={{backgroundColor: c}}/>)}
                                        </div>
                                    </>
                                )}
                                
                                {selectedElement.type === 'icon' && (
                                    <div className="space-y-2">
                                        <label className="text-xs text-gray-500">Icon Color</label>
                                        <div className="flex items-center bg-white/5 border border-white/10 rounded p-1">
                                            <input type="color" value={(selectedElement as IconElement).color} onChange={e => { updateElement(selectedElementId!, { color: e.target.value } as any); commitElementUpdate(); }} className="w-6 h-6 bg-transparent border-none cursor-pointer"/>
                                            <input type="text" value={(selectedElement as IconElement).color} readOnly className="bg-transparent text-xs text-white w-full ml-2 outline-none"/>
                                        </div>
                                        <div className="flex flex-wrap gap-2 mt-2">
                                            {colorPalette.map(c => <button key={c} onClick={() => { updateElement(selectedElementId!, { color: c } as any); commitElementUpdate(); }} className="w-6 h-6 rounded-full border border-white/10" style={{backgroundColor: c}}/>)}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        {activeTab === 'slide' && (
                            <div className="animate-fade-in space-y-6">
                                <div>
                                    <h3 className="text-xs font-bold text-gray-400 uppercase mb-3">Background Type</h3>
                                    <div className="grid grid-cols-4 gap-1 bg-black/20 p-1 rounded-lg">
                                        {['solid', 'gradient', 'image', 'ai'].map(t => (
                                            <button key={t} onClick={() => updateSlideBackground({ type: t === 'ai' ? 'image' : t as any })} className={`text-[10px] py-1.5 rounded font-medium uppercase ${bgConfig.type === t || (t === 'ai' && bgConfig.type === 'image' && isGeneratingBg) ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}>{t}</button>
                                        ))}
                                    </div>
                                </div>

                                {bgConfig.type === 'solid' && (
                                    <div className="space-y-3">
                                        <div className="flex items-center gap-2 bg-white/5 p-2 rounded border border-white/10">
                                            <input type="color" value={bgConfig.value} onChange={e => updateSlideBackground({ value: e.target.value })} className="w-8 h-8 bg-transparent border-none cursor-pointer"/>
                                            <span className="text-xs text-white font-mono">{bgConfig.value}</span>
                                        </div>
                                        <div className="grid grid-cols-5 gap-2">
                                            {colorPalette.map(c => <button key={c} onClick={() => updateSlideBackground({ value: c })} className="aspect-square rounded border border-white/10 hover:scale-110 transition-transform" style={{backgroundColor: c}}/>)}
                                        </div>
                                    </div>
                                )}

                                {bgConfig.type === 'gradient' && (
                                    <div className="space-y-2">
                                        {colorPalette.slice(0, -1).map((c, i) => {
                                            const grad = `linear-gradient(135deg, ${c}, ${colorPalette[i+1] || '#000'})`;
                                            return <button key={i} onClick={() => updateSlideBackground({ value: grad })} className="w-full h-10 rounded border border-white/10 hover:border-white" style={{background: grad}}/>
                                        })}
                                    </div>
                                )}

                                {(bgConfig.type === 'image') && (
                                    <div className="space-y-4">
                                        <div className="space-y-2">
                                            <label className="text-xs text-gray-500">Upload Image</label>
                                            <label className="flex items-center justify-center w-full h-20 border-2 border-dashed border-white/20 rounded hover:bg-white/5 cursor-pointer transition-colors">
                                                <span className="text-xs text-gray-400 flex items-center gap-2"><Upload size={14}/> Choose File</span>
                                                <input type="file" hidden accept="image/*" onChange={async (e) => { if(e.target.files?.[0]) { const r = await fileToBase64(e.target.files[0]); updateSlideBackground({ value: `data:${r.type};base64,${r.data}` }); } }}/>
                                            </label>
                                        </div>
                                        
                                        {generatedAssets.length > 0 && (
                                            <div className="space-y-2 pt-4 border-t border-white/10">
                                                <label className="text-xs text-gray-500">From Project Assets</label>
                                                <div className="grid grid-cols-3 gap-2 max-h-32 overflow-y-auto custom-scrollbar">
                                                    {generatedAssets.filter(a => !a.isLoading && typeof a.content === 'string' && a.content.startsWith('data:image')).map(asset => (
                                                        <button key={asset.id} onClick={() => updateSlideBackground({ value: asset.content as string })} className="aspect-square rounded border border-white/10 overflow-hidden hover:border-fuchsia-500 transition-colors group relative">
                                                            <img src={asset.content as string} className="w-full h-full object-cover" />
                                                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                                <span className="text-[9px] font-bold text-white uppercase tracking-wider">Use</span>
                                                            </div>
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                        
                                        <div className="space-y-2 pt-4 border-t border-white/10">
                                            <label className="text-xs text-gray-500">AI Texture Generator</label>
                                            <textarea value={bgPrompt} onChange={e => setBgPrompt(e.target.value)} placeholder="e.g. 'Subtle geometric pattern in navy blue'" className="w-full bg-white/5 border border-white/10 rounded p-2 text-xs text-white outline-none" rows={2}/>
                                            <button onClick={handleGenerateBackground} disabled={isGeneratingBg || !bgPrompt} className="btn-primary w-full text-xs py-2">{isGeneratingBg ? <Spinner className="w-3 h-3 mr-1"/> : <Sparkles size={12} className="mr-1"/>} Generate Texture</button>
                                        </div>

                                        <div className="space-y-3 pt-4 border-t border-white/10">
                                            <div>
                                                <div className="flex justify-between text-xs text-gray-400 mb-1"><span>Overlay Opacity</span><span>{Math.round((bgConfig.overlayOpacity || 0) * 100)}%</span></div>
                                                <input type="range" min="0" max="1" step="0.1" value={bgConfig.overlayOpacity || 0} onChange={e => updateSlideBackground({ overlayOpacity: Number(e.target.value) })} className="w-full accent-fuchsia-500"/>
                                            </div>
                                            <div>
                                                <label className="text-xs text-gray-500 block mb-1">Image Fit</label>
                                                <div className="flex bg-black/20 rounded p-1 gap-1">
                                                    {['cover', 'contain', 'fill'].map(f => (
                                                        <button key={f} onClick={() => updateSlideBackground({ imageFit: f as any })} className={`flex-1 py-1 text-[10px] uppercase rounded ${bgConfig.imageFit === f ? 'bg-white text-black' : 'text-gray-400'}`}>{f}</button>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                <button onClick={applyBackgroundToAll} className="w-full py-2 border border-white/20 rounded text-xs text-gray-300 hover:bg-white/10 transition-colors mt-4">Apply to All Slides</button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Icon Picker Modal */}
            {isIconModalOpen && (
                <div className="fixed inset-0 bg-black/80 z-[110] flex items-center justify-center p-4" onClick={() => setIsIconModalOpen(false)}>
                    <div className="bg-gray-900 border border-white/10 rounded-lg w-full max-w-lg max-h-[80vh] flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
                        <header className="p-4 border-b border-white/10 flex items-center justify-between">
                            <h3 className="text-white font-bold">Add Icon</h3>
                            <button onClick={() => setIsIconModalOpen(false)}><X size={18} className="text-gray-400 hover:text-white"/></button>
                        </header>
                        <div className="p-4">
                            <div className="flex gap-2 mb-4">
                                <div className="relative flex-grow">
                                    <Search size={14} className="absolute left-3 top-3 text-gray-500"/>
                                    <input type="text" value={iconSearch} onChange={e => setIconSearch(e.target.value)} placeholder="Search icons..." className="w-full bg-black/20 border border-white/10 rounded-lg py-2 pl-9 pr-4 text-white text-sm outline-none focus:border-fuchsia-500"/>
                                </div>
                            </div>
                            <div className="h-64 overflow-y-auto grid grid-cols-5 gap-2 custom-scrollbar mb-4">
                                {PRESET_ICONS.filter(i => i.toLowerCase().includes(iconSearch.toLowerCase())).map(icon => {
                                    const IconComp = (LucideIcons as any)[icon];
                                    if (!IconComp) return null;
                                    return (
                                        <button key={icon} onClick={() => handleAddLibraryIcon(icon)} className="aspect-square bg-white/5 hover:bg-white/10 rounded flex items-center justify-center text-gray-300 hover:text-white transition-colors flex-col gap-1">
                                            <IconComp size={20}/>
                                            <span className="text-[9px] truncate w-full px-1">{icon}</span>
                                        </button>
                                    );
                                })}
                            </div>
                            
                            <div className="border-t border-white/10 pt-4">
                                <h4 className="text-xs font-bold text-gray-400 uppercase mb-2">AI Magic Icon</h4>
                                <div className="flex gap-2">
                                    <input type="text" value={iconPrompt} onChange={e => setIconPrompt(e.target.value)} placeholder="e.g. 'Neon rocket ship'" className="flex-grow bg-white/5 border border-white/10 rounded p-2 text-sm text-white outline-none"/>
                                    <button onClick={handleGenerateIcon} disabled={!iconPrompt || isGeneratingIcon} className="btn-primary text-xs px-4">
                                        {isGeneratingIcon ? <Spinner className="w-4 h-4"/> : 'Generate'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PresentationEditorModal;
