// Fix: Removed file marker comments that were causing syntax errors.
import React, { useState, useEffect } from 'react';
import Spinner from './Spinner';

interface StyleApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApprove: (description: string) => void;
  styleImagePreviewUrl: string;
  initialDescription: string;
}

const StyleApprovalModal: React.FC<StyleApprovalModalProps> = ({
  isOpen,
  onClose,
  onApprove,
  styleImagePreviewUrl,
  initialDescription,
}) => {
  const [description, setDescription] = useState(initialDescription);

  useEffect(() => {
    setDescription(initialDescription);
  }, [initialDescription]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  const handleApproveClick = () => {
    onApprove(description);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col animate-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-white/10">
          <h2 className="text-xl font-bold text-white">Approve AI-Generated Style</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </header>

        <div className="flex-grow p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex flex-col items-center justify-start space-y-3">
                <p className="text-sm font-medium text-gray-300 self-start">Your Style Reference Image:</p>
                <div className="w-full h-64 bg-black/20 rounded-lg flex items-center justify-center p-2">
                    <img
                        src={styleImagePreviewUrl}
                        alt="Style reference preview"
                        className="max-w-full max-h-full object-contain"
                    />
                </div>
            </div>
            <div className="flex flex-col space-y-3">
                <label htmlFor="style-description" className="text-sm font-medium text-gray-300">
                    AI Style Description:
                </label>
                <p className="text-xs text-gray-400">
                    Our AI has described your image's style below. You can edit this text to refine the creative direction before generating your assets.
                </p>
                <textarea
                    id="style-description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={8}
                    className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all resize-none backdrop-blur-md"
                />
            </div>
        </div>

        <footer className="p-4 border-t border-white/10 flex justify-end space-x-4">
          <button
            onClick={onClose}
            className="px-6 py-2 font-semibold text-gray-300 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleApproveClick}
            className="px-6 py-2 font-semibold text-white bg-fuchsia-600 rounded-lg shadow-[0_0_20px_rgba(217,70,239,0.4)] hover:bg-fuchsia-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all flex items-center justify-center"
          >
            Approve & Generate Kit
          </button>
        </footer>
      </div>
    </div>
  );
};

export default StyleApprovalModal;