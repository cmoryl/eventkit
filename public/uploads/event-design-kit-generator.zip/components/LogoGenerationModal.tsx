
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { getLogoSuggestions, generateLogoVariations, refineLogo, generateMonochromeLogo } from '../services/geminiService';
import { AssetType } from '../types';
import type { EventDetails, LogoGenerationOptions, GeneratedLogoVariation } from '../types';
import Spinner from './Spinner';
import LogoVariationCard from './LogoVariationCard';
import LogoRefineModal from './LogoRefineModal';
import Accordion from './Accordion';


interface LogoGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogoKitCreated: (kit: {
    primary: { content: string; name: string };
    monochrome: { content: string; name: string };
    reversed: { content: string; name: string };
  }) => void;
  eventDetails: EventDetails;
}

const initialOptions: LogoGenerationOptions = {
    eventTitle: '',
    eventTagline: '',
    location: '',
    text: '', visualElements: '', textHandling: 'as typed', fontStyle: 'Sans',
    logoType: 'Combination mark', script: 'Latin', culturalConsiderations: '',
    forbiddenElements: '', styleBundles: [], tone: [], moods: [], cues: [],
    renderingStyle: ['Flat 2D'],
    colors: [
        { hex: '#139dd8', name: 'Bright Blue' }, { hex: '#FFFFFF', name: 'Pure White' },
        { hex: '#27303a', name: 'Dark Navy' }, { hex: '#93a3c8', name: 'Muted Blue-Gray' }
    ]
};

const optionsData = {
    styleBundles: ['Tech Clean', 'Finance Trust', 'Eco Natural', 'Luxury Fashion', 'Kids Playful', 'Minimal Modern', 'Film Movie', 'Street Style', 'Academic Enduring', 'Modern Metropolis', 'Olympic Heritage', 'Coastal Maritime', 'Minimalist Philosophy'],
    tone: ['Corporate', 'Playful', 'Premium', 'Friendly', 'Minimal', 'Bold', 'Calm', 'Energetic', 'Sophisticated', 'Whimsical', 'Rugged'],
    moods: ['Sleek', 'Futuristic', 'Vintage', 'Gritty', 'Handcrafted', 'Elegant', 'Maximalist', 'Minimalist', 'Cinematic', 'Techy', 'Sporty', 'Eco', 'Luxury', 'Psychedelic', 'Vaporwave', 'Art deco', 'Grunge', 'Celestial', 'Aquatic', 'Botanical', 'Cyberpunk', 'Steampunk', 'Bauhaus', 'Urban'],
    cues: ['Negative space', 'Grid', 'Pixel hint', 'Geometric', 'Curvature', 'Monoline', 'Modular', 'Motion-friendly', 'Symmetry', 'Asymmetry', 'Golden ratio', 'Optical illusion', 'Calligraphic', 'Fractal', 'Tessellation', 'Origami'],
    renderingStyle: ['Flat 2D', 'Gradient 2D', 'Isometric 3D', 'Toon', 'Regular 3D', 'Hand Drawn', 'Stencil', 'Graffiti']
};

const MultiSelectChip: React.FC<{
    label: string;
    options: string[];
    selected: string[];
    onSelect: (value: string) => void;
}> = ({ label, options, selected, onSelect }) => (
    <div>
        <h4 className="text-sm font-medium text-gray-300 mb-2">{label}</h4>
        <div className="flex flex-wrap gap-2">
            {options.map(option => (
                <button key={option} onClick={() => onSelect(option)} className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all ${selected.includes(option) ? 'bg-fuchsia-600 text-white border-fuchsia-500' : 'bg-white/5 text-gray-300 border-white/20 hover:bg-white/20'}`}>
                    {option}
                </button>
            ))}
        </div>
    </div>
);

const KitItemCard: React.FC<{item: GeneratedLogoVariation}> = ({ item }) => (
     <div className="bg-black/30 rounded-lg p-2 flex flex-col items-center justify-center text-center h-full">
        <p className="text-xs text-gray-400 mb-2 flex-shrink-0 h-4">{item.title || ''}</p>
        <div className="flex-grow flex items-center justify-center w-full h-full min-h-0">
             {item.isLoading ? (
                <Spinner />
            ) : item.content ? (
                <img src={item.content} alt={item.title} className="max-w-full max-h-full object-contain" />
            ) : (
                <span className="text-red-400 text-xs">Failed</span>
            )}
        </div>
    </div>
);


const LogoGenerationModal: React.FC<LogoGenerationModalProps> = ({ isOpen, onClose, onLogoKitCreated, eventDetails }) => {
    const [view, setView] = useState<'form' | 'results' | 'finalize'>('form');
    const [options, setOptions] = useState<LogoGenerationOptions>({ ...initialOptions });
    const [variations, setVariations] = useState<GeneratedLogoVariation[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);
    const [isSuggesting, setIsSuggesting] = useState(false);
    
    // Finalize view state
    const [finalizingLogo, setFinalizingLogo] = useState<GeneratedLogoVariation | null>(null);
    const [logoKit, setLogoKit] = useState<{
        primary: GeneratedLogoVariation | null;
        monochrome: GeneratedLogoVariation | null;
        reversed: GeneratedLogoVariation | null;
        mockups: GeneratedLogoVariation[];
    }>({ primary: null, monochrome: null, reversed: null, mockups: [] });

    // Sub-modal states
    const [refiningLogo, setRefiningLogo] = useState<GeneratedLogoVariation | null>(null);

    useEffect(() => {
        if (isOpen) {
            setOptions({
                ...initialOptions,
                eventTitle: eventDetails.name,
                eventTagline: '', // Reset tagline
                text: eventDetails.name,
                location: eventDetails.location,
            });
            setView('form');
            setVariations([]);
        }
    }, [isOpen, eventDetails.name, eventDetails.location]);

     useEffect(() => {
        if (view === 'finalize' && finalizingLogo) {
            const generateKit = async () => {
                setLogoKit({
                    primary: finalizingLogo,
                    monochrome: { id: uuidv4(), content: '', isLoading: true, feedback: null, title: 'Monochrome' },
                    reversed: { id: uuidv4(), content: '', isLoading: true, feedback: null, title: 'Reversed (White)' },
                    mockups: [] // Mockups are no longer generated at this step
                });
    
                // Generate monochrome and reversed
                generateMonochromeLogo(finalizingLogo.content, 'black').then(content => {
                    setLogoKit(prev => ({ ...prev, monochrome: { ...prev.monochrome!, content, isLoading: false } }));
                }).catch(e => {
                     console.error("Monochrome logo failed", e);
                     setLogoKit(prev => ({ ...prev, monochrome: { ...prev.monochrome!, isLoading: false } }));
                });
    
                generateMonochromeLogo(finalizingLogo.content, 'white').then(content => {
                    setLogoKit(prev => ({ ...prev, reversed: { ...prev.reversed!, content, isLoading: false } }));
                }).catch(e => {
                     console.error("Reversed logo failed", e);
                     setLogoKit(prev => ({ ...prev, reversed: { ...prev.reversed!, isLoading: false } }));
                });
            };
            generateKit();
        }
    }, [view, finalizingLogo]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setOptions(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleMultiSelect = (field: keyof LogoGenerationOptions, value: string) => {
        setOptions(prev => {
            const current = prev[field] as string[];
            const newSelection = current.includes(value) ? current.filter(item => item !== value) : [...current, value];
            return { ...prev, [field]: newSelection };
        });
    };

    const handleGetSuggestions = async () => {
        if (!options.location) {
            alert("Please provide an event location to get suggestions.");
            return;
        }
        setIsSuggesting(true);
        try {
            const suggestions = await getLogoSuggestions(options.location);
            setOptions(prev => ({ ...prev, culturalConsiderations: prev.culturalConsiderations ? `${prev.culturalConsiderations}, ${suggestions}` : suggestions }));
        } catch (e) {
            console.error(e);
            alert("Could not fetch suggestions.");
        } finally {
            setIsSuggesting(false);
        }
    };
    
    const handleGenerate = async () => {
        setIsGenerating(true);
        setView('results');
        setVariations(Array.from({ length: 4 }, (_, i) => ({
            id: uuidv4(),
            content: '',
            isLoading: true,
            feedback: null
        })));
        try {
            const results = await generateLogoVariations(options);
            setVariations(prev => prev.map((v, i) => ({
                ...v,
                content: results[i] || '',
                isLoading: false,
            })));
        } catch (e) {
            console.error(e);
            alert("Logo generation failed. Please try again.");
            setVariations(prev => prev.map(v => ({ ...v, isLoading: false })));
        } finally {
            setIsGenerating(false);
        }
    };

    const handleRefreshVariation = async (id: string) => {
        setVariations(vars => vars.map(v => v.id === id ? { ...v, isLoading: true } : v));
        try {
            const results = await generateLogoVariations(options, 1);
            const newLogo = results[0];
            if (newLogo) {
                setVariations(vars => vars.map(v => v.id === id ? { ...v, content: newLogo, isLoading: false } : v));
            } else {
                throw new Error("Generation returned no image.");
            }
        } catch (e) {
            console.error(e);
            alert("Could not refresh logo variation.");
            setVariations(vars => vars.map(v => v.id === id ? { ...v, isLoading: false } : v));
        }
    };

    const handleSelectVariation = (variation: GeneratedLogoVariation) => {
        setView('finalize');
        setFinalizingLogo(variation);
    };
    
    const handleRefineSave = async (id: string, newContent: string) => {
        setVariations(vars => vars.map(v => v.id === id ? {...v, content: newContent} : v));
        if (finalizingLogo?.id === id) {
            setFinalizingLogo(prev => prev ? {...prev, content: newContent} : null);
        }
        setRefiningLogo(null);
    };
    
    const isKitReady = useMemo(() => {
        if (!logoKit.primary || !logoKit.monochrome || !logoKit.reversed) return false;
        return !logoKit.primary.isLoading &&
               !logoKit.monochrome.isLoading && !!logoKit.monochrome.content &&
               !logoKit.reversed.isLoading && !!logoKit.reversed.content;
    }, [logoKit]);

    const handleConfirmKit = () => {
        if (!isKitReady) return;
    
        const kit = {
            primary: { content: logoKit.primary!.content, name: 'Primary Logo' },
            monochrome: { content: logoKit.monochrome!.content, name: 'Monochrome Logo' },
            reversed: { content: logoKit.reversed!.content, name: 'Reversed Logo' },
        };
    
        onLogoKitCreated(kit);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-gray-900/70 border border-white/10 rounded-lg shadow-2xl w-full max-w-6xl h-[90vh] flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
                    <h2 className="text-xl font-bold text-white">Create Event Logo</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </header>

                <div className="flex-grow flex overflow-hidden">
                    {/* Form Section */}
                    <div className="w-1/3 p-4 border-r border-white/10 overflow-y-auto space-y-4">
                        <Accordion title="Event & Text">
                            <div className="space-y-3 p-2">
                                <input type="text" name="eventTitle" value={options.eventTitle} onChange={handleInputChange} placeholder="Event Title" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                                <input type="text" name="eventTagline" value={options.eventTagline} onChange={handleInputChange} placeholder="Event Tagline (Optional)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                                <input type="text" name="location" value={options.location} onChange={handleInputChange} placeholder="Event Location" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                                <hr className="border-white/10"/>
                                <input type="text" name="text" value={options.text} onChange={handleInputChange} placeholder="Text in Logo (e.g., 'AURA')" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                            </div>
                        </Accordion>
                         <Accordion title="Core Design Elements">
                            <div className="space-y-3 p-2">
                                <input type="text" name="visualElements" value={options.visualElements} onChange={handleInputChange} placeholder="Core Visual Element(s) (e.g., gentle wave, sun)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                                <select name="logoType" value={options.logoType} onChange={handleInputChange} className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none"><option>Combination mark</option><option>Wordmark</option><option>Lettermark</option><option>Emblem</option><option>Abstract mark</option></select>
                                <select name="fontStyle" value={options.fontStyle} onChange={handleInputChange} className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none"><option>Sans</option><option>Serif</option><option>Slab</option><option>Script</option><option>Display</option></select>
                            </div>
                        </Accordion>
                        <Accordion title="Cultural & Constraints">
                            <div className="space-y-3 p-2">
                                <div>
                                    <button onClick={handleGetSuggestions} disabled={isSuggesting || !options.location} className="w-full text-sm py-2 font-semibold text-fuchsia-400 hover:text-fuchsia-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center bg-white/5 hover:bg-white/10 rounded-lg transition-colors">
                                        {isSuggesting ? <Spinner className="w-4 h-4 mr-2" /> : 'Get AI Cultural Suggestions'}
                                    </button>
                                    <hr className="border-white/10 my-3"/>
                                    <label htmlFor="cultural-considerations" className="text-sm text-gray-300">Cultural Considerations (edit or add your own):</label>
                                    <textarea id="cultural-considerations" name="culturalConsiderations" value={options.culturalConsiderations} onChange={handleInputChange} placeholder="AI suggestions will appear here..." rows={3} className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none resize-none mt-1" />
                                 </div>
                                 <input type="text" name="forbiddenElements" value={options.forbiddenElements} onChange={handleInputChange} placeholder="Forbidden Elements (e.g., circles, sharp edges)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                            </div>
                        </Accordion>
                        <Accordion title="Aesthetics & Style">
                            <div className="space-y-4 p-2">
                                <MultiSelectChip label="Style Bundles" options={optionsData.styleBundles} selected={options.styleBundles} onSelect={(v) => handleMultiSelect('styleBundles', v)} />
                                <MultiSelectChip label="Tone" options={optionsData.tone} selected={options.tone} onSelect={(v) => handleMultiSelect('tone', v)} />
                                <MultiSelectChip label="Moods" options={optionsData.moods} selected={options.moods} onSelect={(v) => handleMultiSelect('moods', v)} />
                            </div>
                        </Accordion>
                        <Accordion title="Visual Cues & Rendering">
                             <div className="space-y-4 p-2">
                                <MultiSelectChip label="Cues" options={optionsData.cues} selected={options.cues} onSelect={(v) => handleMultiSelect('cues', v)} />
                                <MultiSelectChip label="Rendering Style" options={optionsData.renderingStyle} selected={options.renderingStyle} onSelect={(v) => handleMultiSelect('renderingStyle', v)} />
                            </div>
                        </Accordion>
                    </div>

                    {/* Results Section */}
                    <div className="w-2/3 flex flex-col items-center justify-center bg-black/20">
                        {view === 'form' && (
                            <div className="text-center p-6">
                                <h3 className="text-2xl font-bold text-white">Ready to create your logo?</h3>
                                <p className="text-gray-400 mt-2">Fill in the details on the left and click generate.</p>
                            </div>
                        )}
                        {view === 'results' && (
                            <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-4 p-6">
                                {variations.map((variation) => (
                                    <LogoVariationCard
                                        key={variation.id}
                                        variation={variation}
                                        onRefresh={() => handleRefreshVariation(variation.id)}
                                        onRefine={() => setRefiningLogo(variation)}
                                        onSelect={() => handleSelectVariation(variation)}
                                    />
                                ))}
                            </div>
                        )}
                        {view === 'finalize' && (
                             <div className="w-full h-full p-6 flex flex-col">
                                <div className="flex items-center justify-between mb-4">
                                    <h3 className="text-xl font-bold text-white">Finalize Your Logo Kit</h3>
                                    <button onClick={() => setView('results')} className="btn-tertiary">← Back to Variations</button>
                                </div>
                                <div className="flex-grow flex gap-6 min-h-0">
                                    <div className="w-2/3 bg-black/30 rounded-lg p-4 flex items-center justify-center">
                                        {finalizingLogo && <img src={finalizingLogo.content} className="max-w-full max-h-full object-contain"/>}
                                    </div>
                                    <div className="w-1/3 flex flex-col gap-6">
                                        {logoKit.monochrome && <KitItemCard item={logoKit.monochrome} />}
                                        {logoKit.reversed && <KitItemCard item={logoKit.reversed} />}
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex-shrink-0 flex justify-end">
                    {view === 'finalize' ? (
                        <button onClick={handleConfirmKit} disabled={!isKitReady} className="btn-primary px-8 py-3 text-base">
                            Add Logo Kit to Project
                        </button>
                    ) : (
                        <button onClick={handleGenerate} disabled={isGenerating || !options.text} className="btn-primary px-8 py-3 text-base">
                            {isGenerating ? <><Spinner className="mr-2" />Generating...</> : 'Generate Logo'}
                        </button>
                    )}
                </footer>
            </div>
            {refiningLogo && (
                <LogoRefineModal
                    isOpen={!!refiningLogo}
                    onClose={() => setRefiningLogo(null)}
                    logo={refiningLogo}
                    onSave={handleRefineSave}
                />
            )}
        </div>
    );
};

export default LogoGenerationModal;
