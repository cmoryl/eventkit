
// Fix: Created the missing ImageEditorModal component.
import React, { useState, useEffect, useRef } from 'react';
import type { GeneratedAsset, EventDetails } from '../types';
import { AssetType } from '../types';
import { editImageContent } from '../services/geminiService';
import Spinner from './Spinner';
import SkeletonLoader from './SkeletonLoader';
import { fileToBase64 } from '../utils';

interface ImageEditorModalProps {
  asset: GeneratedAsset;
  onClose: () => void;
  onOverwrite: (assetId: string, newContent: string, newParams?: any) => void;
  onSaveAsNew: (assetId: string, newContent: string) => void;
  eventDetails: EventDetails;
  colorPalette: string[];
}

const ImageEditorModal: React.FC<ImageEditorModalProps> = ({ asset, onClose, onOverwrite, onSaveAsNew, eventDetails, colorPalette }) => {
    const [regenerationPrompt, setRegenerationPrompt] = useState('');
    const [customContent, setCustomContent] = useState<Record<string, string>>({});
    const [newImagePreview, setNewImagePreview] = useState<string | null>(null);
    const [isRegenerating, setIsRegenerating] = useState(false);
    const [isViewingLarge, setIsViewingLarge] = useState(false);
    const [showSaveOptions, setShowSaveOptions] = useState(false);
    
    // State for dual-sided editing (NameTag)
    const [activeSide, setActiveSide] = useState<'front' | 'back'>('front');
    const [backImagePreview, setBackImagePreview] = useState<string | null>(null);

    // State for specific Name Tag features
    const [noText, setNoText] = useState(false);
    const [overlayImage, setOverlayImage] = useState<string | null>(null); // base64

    // State for Hat Customization
    const [hatStyle, setHatStyle] = useState('Baseball Cap');
    const [decoMethod, setDecoMethod] = useState('3D Puff Embroidery');

    // MASKING STATE
    const [isMaskingMode, setIsMaskingMode] = useState(false);
    const [brushSize, setBrushSize] = useState(20);
    const [maskImage, setMaskImage] = useState<string | null>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);

    // Determine display image based on active side and generation state
    let currentImage = asset.content as string;
    if (activeSide === 'back') {
        currentImage = backImagePreview || (asset.backContent as string);
    } else {
        currentImage = newImagePreview || (asset.content as string);
    }

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [onClose]);

    // Canvas Logic
    useEffect(() => {
        if (isMaskingMode && canvasRef.current && containerRef.current) {
            const canvas = canvasRef.current;
            const container = containerRef.current;
            const img = container.querySelector('img');
            
            if (img) {
                // Match canvas size to displayed image size
                canvas.width = img.width;
                canvas.height = img.height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.lineCap = 'round';
                    ctx.lineJoin = 'round';
                    ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)'; // Visual feedback
                    ctx.lineWidth = brushSize;
                }
            }
        }
    }, [isMaskingMode, currentImage]);

    const startDrawing = (e: React.MouseEvent) => {
        if (!isMaskingMode || !canvasRef.current) return;
        setIsDrawing(true);
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return;
        
        const rect = canvasRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        ctx.beginPath();
        ctx.moveTo(x, y);
    };

    const draw = (e: React.MouseEvent) => {
        if (!isDrawing || !isMaskingMode || !canvasRef.current) return;
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return;
        
        const rect = canvasRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        ctx.lineWidth = brushSize;
        ctx.lineTo(x, y);
        ctx.stroke();
    };

    const stopDrawing = () => {
        if (isDrawing && canvasRef.current) {
            // Generate Mask Data URL
            // We need a black and white mask. The visual canvas is semi-transparent white.
            // Create a temp canvas to generate the actual binary mask.
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvasRef.current.width;
            tempCanvas.height = canvasRef.current.height;
            const tCtx = tempCanvas.getContext('2d');
            
            if (tCtx) {
                tCtx.fillStyle = 'black';
                tCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
                tCtx.drawImage(canvasRef.current, 0, 0);
                
                // The drawing on visual canvas was rgba(255,255,255,0.5).
                // We want that area to be white (the mask).
                // However, simple drawImage keeps alpha. 
                // Better approach: Re-render strokes? No, too complex.
                // Filter approach:
                const imageData = tCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
                const data = imageData.data;
                for (let i = 0; i < data.length; i += 4) {
                    // If pixel is not black (modified), make it white
                    if (data[i] > 0 || data[i+1] > 0 || data[i+2] > 0) {
                        data[i] = 255;
                        data[i+1] = 255;
                        data[i+2] = 255;
                        data[i+3] = 255; // Full opacity
                    }
                }
                tCtx.putImageData(imageData, 0, 0);
                setMaskImage(tempCanvas.toDataURL('image/png'));
            }
        }
        setIsDrawing(false);
    };

    const clearMask = () => {
        if (canvasRef.current) {
            const ctx = canvasRef.current.getContext('2d');
            ctx?.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
            setMaskImage(null);
        }
    };


    const handleCustomContentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setCustomContent(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleOverlayUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            try {
                const result = await fileToBase64(e.target.files[0]);
                setOverlayImage(`data:${result.type};base64,${result.data}`);
            } catch (err) {
                console.error("Failed to convert image", err);
                alert("Could not process image.");
            }
        }
    };

    const handleRegenerate = async () => {
        if (!regenerationPrompt.trim() && !Object.values(customContent).some((v: string) => v.trim() !== '') && !noText && !overlayImage && asset.type !== AssetType.Hat && !maskImage) {
            alert("Please provide custom content, an overlay image, or a description of the changes you'd like to make.");
            return;
        }
        setIsRegenerating(true);
        setNewImagePreview(null);
        setShowSaveOptions(false);
        
        try {
            // Determine which image source to use based on active side
            let sourceImage = asset.content as string;
            let targetType = asset.type;

            if (asset.type === AssetType.NameTag && activeSide === 'back') {
                sourceImage = asset.backContent as string;
                targetType = AssetType.NameTagBack; // Use logic for back
            }

            // Pass 'noText' into customContent as a flag string
            const contentParams = { ...customContent };
            if (noText) {
                contentParams['noText'] = 'true';
            }

            // Construct specific prompt for Hats
            let finalPrompt = regenerationPrompt;
            if (asset.type === AssetType.Hat) {
                finalPrompt = `${regenerationPrompt} Change the product to a ${hatStyle}. Apply the design using ${decoMethod} technique. Ensure high-quality fabric texture.`;
            }

            const result = await editImageContent(
                targetType,
                sourceImage,
                colorPalette,
                finalPrompt,
                contentParams,
                overlayImage || undefined, // Pass overlay image if it exists
                maskImage || undefined // Pass mask if exists
            );
            
            if (activeSide === 'back') {
                setBackImagePreview(result);
            } else {
                setNewImagePreview(result);
            }
            setIsMaskingMode(false); // Exit masking mode after generation
        } catch (e) {
            console.error("Image regeneration failed:", e);
            alert("Sorry, the image could not be regenerated. Please try a different prompt or check the console for errors.");
        } finally {
            setIsRegenerating(false);
        }
    };
    
    const handleOverwrite = () => {
        const newContent = newImagePreview || (asset.content as string);
        const newBackContent = backImagePreview || (asset.backContent as string);
        
        // If it's a dual sided asset, pass the back content in params or specialized update object
        if (asset.type === AssetType.NameTag) {
             onOverwrite(asset.id, newContent, { backContent: newBackContent });
        } else {
             onOverwrite(asset.id, newContent);
        }
    };

    const handleSaveAsNew = () => {
        const contentToSave = activeSide === 'back' ? (backImagePreview || asset.backContent) : (newImagePreview || asset.content);
        if (contentToSave) {
            onSaveAsNew(asset.id, contentToSave as string);
        }
    };

    const renderCustomFields = () => {
        const inputClass = "w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md disabled:opacity-50 disabled:cursor-not-allowed";
        const textareaClass = `${inputClass} resize-none`;

        if (asset.type === AssetType.Hat) {
            return (
                <div className="space-y-4 pt-4 border-t border-white/10">
                    <h4 className="text-sm font-medium text-gray-300">Merchandise Settings:</h4>
                    <div>
                        <label className="text-xs text-gray-400 mb-1 block">Hat Style</label>
                        <select value={hatStyle} onChange={(e) => setHatStyle(e.target.value)} className={inputClass}>
                            <option>Baseball Cap (Structured)</option>
                            <option>Dad Hat (Unstructured)</option>
                            <option>Trucker Hat (Mesh Back)</option>
                            <option>Beanie (Cuffed)</option>
                            <option>Bucket Hat</option>
                            <option>Visor</option>
                            <option>5-Panel Camp Cap</option>
                        </select>
                    </div>
                    <div>
                        <label className="text-xs text-gray-400 mb-1 block">Decoration Technique</label>
                        <select value={decoMethod} onChange={(e) => setDecoMethod(e.target.value)} className={inputClass}>
                            <option>3D Puff Embroidery</option>
                            <option>Flat Embroidery</option>
                            <option>Woven Patch</option>
                            <option>Leather Patch</option>
                            <option>Screen Print</option>
                            <option>Sublimation (All-over)</option>
                        </select>
                    </div>
                </div>
            );
        }

        if (asset.type === AssetType.Menu) {
            return (
                <div className="space-y-4 pt-4 border-t border-white/10">
                    <h4 className="text-sm font-medium text-gray-300">Menu Content:</h4>
                    <input type="text" name="appetizer" value={customContent.appetizer || ''} onChange={handleCustomContentChange} placeholder="Appetizer" className={inputClass} />
                    <textarea name="mainCourses" value={customContent.mainCourses || ''} onChange={handleCustomContentChange} placeholder="Main Courses (one per line)" rows={3} className={textareaClass} />
                    <input type="text" name="dessert" value={customContent.dessert || ''} onChange={handleCustomContentChange} placeholder="Dessert" className={inputClass} />
                </div>
            );
        }
        if (asset.type === AssetType.ThankYouNote) {
            return (
                <div className="space-y-4 pt-4 border-t border-white/10">
                     <h4 className="text-sm font-medium text-gray-300">Note Content:</h4>
                     <textarea name="content" value={customContent.content || ''} onChange={handleCustomContentChange} placeholder="Thank you message..." rows={4} className={`${textareaClass} bg-gray-800`} />
                     <input type="text" name="signature" value={customContent.signature || ''} onChange={handleCustomContentChange} placeholder="Signature (e.g., The Team)" className={inputClass} />
                </div>
            );
        }
        if (asset.type === AssetType.NameTag) {
            return (
                <div className="space-y-4 pt-4 border-t border-white/10">
                    <h4 className="text-sm font-medium text-gray-300">Badge Customization ({activeSide === 'front' ? 'Front' : 'Back'}):</h4>
                    
                    {/* No Text Option */}
                    <label className="flex items-center space-x-3 p-2 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition-colors">
                        <input 
                            type="checkbox" 
                            checked={noText} 
                            onChange={(e) => setNoText(e.target.checked)} 
                            className="h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400" 
                        />
                        <span className="text-gray-300 text-sm">Remove Text (Graphic Only)</span>
                    </label>

                    {/* Image Overlay Upload */}
                    <div className="relative">
                        <label className="block text-xs text-gray-400 mb-1">Upload Image / Logo Overlay (Optional)</label>
                        <div className="flex items-center gap-3">
                            <label className="flex-1 btn-secondary text-center cursor-pointer text-xs py-2">
                                {overlayImage ? 'Change Image' : 'Upload Image'}
                                <input type="file" className="hidden" accept="image/*" onChange={handleOverlayUpload} />
                            </label>
                            {overlayImage && (
                                <button 
                                    onClick={() => setOverlayImage(null)} 
                                    className="p-2 bg-red-500/20 hover:bg-red-500/40 rounded-lg text-red-300 transition-colors"
                                    title="Remove Image"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                    </svg>
                                </button>
                            )}
                        </div>
                        {overlayImage && (
                            <div className="mt-2 relative h-16 w-16 rounded border border-white/20 bg-black/20 overflow-hidden">
                                <img src={overlayImage} alt="Overlay Preview" className="w-full h-full object-contain" />
                            </div>
                        )}
                    </div>

                    {/* Text Inputs (Disabled if No Text is checked) */}
                    <div className={`space-y-4 transition-opacity duration-300 ${noText ? 'opacity-40 pointer-events-none' : 'opacity-100'}`}>
                        <div>
                            <label className="text-xs text-gray-400 mb-1 block">Attendee Name (Front)</label>
                            <input type="text" name="name" value={customContent.name || ''} onChange={handleCustomContentChange} placeholder="e.g. Jane Doe" className={inputClass} disabled={noText} />
                        </div>
                        <div>
                            <label className="text-xs text-gray-400 mb-1 block">Job Title (Front)</label>
                            <input type="text" name="title" value={customContent.title || ''} onChange={handleCustomContentChange} placeholder="e.g. Keynote Speaker" className={inputClass} disabled={noText} />
                        </div>
                        <div>
                            <label className="text-xs text-gray-400 mb-1 block">Company (Front)</label>
                            <input type="text" name="company" value={customContent.company || ''} onChange={handleCustomContentChange} placeholder="e.g. Acme Corp" className={inputClass} disabled={noText} />
                        </div>
                        <div>
                            <label className="text-xs text-gray-400 mb-1 block">Back Content (Agenda/Info)</label>
                            <textarea 
                                name="backContent" 
                                value={customContent.backContent || ''} 
                                onChange={handleCustomContentChange} 
                                placeholder="e.g., 9:00 AM - Welcome Keynote&#10;12:00 PM - Lunch" 
                                rows={4} 
                                className={textareaClass} 
                                disabled={noText}
                            />
                        </div>
                    </div>
                </div>
            );
        }
        return null;
    };

    const hasBackSide = !!asset.backContent;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col animate-scale-in relative"
                onClick={(e) => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">Edit: {asset.title}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </header>

                <div className="flex-grow p-4 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex flex-col">
                        {hasBackSide && (
                            <div className="flex mb-4 bg-black/30 p-1 rounded-lg self-center">
                                <button 
                                    onClick={() => setActiveSide('front')}
                                    className={`px-4 py-1 rounded-md text-sm font-medium transition-colors ${activeSide === 'front' ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}
                                >
                                    Front Side
                                </button>
                                <button 
                                    onClick={() => setActiveSide('back')}
                                    className={`px-4 py-1 rounded-md text-sm font-medium transition-colors ${activeSide === 'back' ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}
                                >
                                    Back Side
                                </button>
                            </div>
                        )}
                        
                        <div 
                            ref={containerRef}
                            className={`bg-black/20 rounded-lg flex items-center justify-center p-2 relative group flex-grow overflow-hidden ${isMaskingMode ? 'cursor-crosshair' : ''}`}
                        >
                             {isRegenerating ? (
                                <div className="w-full h-full flex items-center justify-center" style={{aspectRatio: '1 / 1'}}>
                                    <SkeletonLoader className="w-full h-full"/>
                                </div>
                            ) : (
                                <>
                                    <img 
                                        src={currentImage} 
                                        alt="Asset Preview" 
                                        className="max-w-full max-h-[60vh] object-contain relative z-0"
                                    />
                                    {isMaskingMode && (
                                        <canvas
                                            ref={canvasRef}
                                            className="absolute top-2 left-2 z-10 touch-none pointer-events-auto"
                                            onMouseDown={startDrawing}
                                            onMouseMove={draw}
                                            onMouseUp={stopDrawing}
                                            onMouseLeave={stopDrawing}
                                        />
                                    )}
                                    {!isMaskingMode && (
                                        <button
                                            onClick={() => setIsViewingLarge(true)}
                                            className="absolute top-2 right-2 p-2 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-sm transition-all duration-300 opacity-0 group-hover:opacity-100 z-20"
                                            title="View larger"
                                        >
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                                            </svg>
                                        </button>
                                    )}
                                </>
                            )}
                        </div>
                        
                        {isMaskingMode && (
                            <div className="mt-2 flex items-center gap-2 bg-black/40 p-2 rounded-lg backdrop-blur">
                                <span className="text-xs text-gray-300">Brush Size:</span>
                                <input 
                                    type="range" 
                                    min="5" 
                                    max="50" 
                                    value={brushSize} 
                                    onChange={(e) => setBrushSize(Number(e.target.value))}
                                    className="flex-grow accent-fuchsia-500 h-2 rounded-lg appearance-none bg-white/20"
                                />
                                <button onClick={clearMask} className="text-xs text-red-400 hover:text-red-300 px-2">Clear</button>
                            </div>
                        )}
                    </div>
                    <div className="flex flex-col space-y-4">
                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <label htmlFor="regen-prompt" className="text-sm font-medium text-gray-300">
                                    {activeSide === 'front' ? 'Front Design' : 'Back Design'} Style Changes:
                                </label>
                                <button 
                                    onClick={() => setIsMaskingMode(!isMaskingMode)}
                                    className={`text-xs px-2 py-1 rounded transition-colors border ${isMaskingMode ? 'bg-fuchsia-600 border-fuchsia-500 text-white' : 'bg-white/5 border-white/20 text-gray-400 hover:text-white'}`}
                                >
                                    {isMaskingMode ? 'Finish Masking' : 'Paint Mask (In-paint)'}
                                </button>
                            </div>
                            <textarea
                                id="regen-prompt"
                                value={regenerationPrompt}
                                onChange={(e) => setRegenerationPrompt(e.target.value)}
                                placeholder={isMaskingMode ? "Describe what to put in the masked area (e.g. 'Add a gold star here')..." : "e.g., 'Make the background darker', 'Use a more playful font'"}
                                rows={3}
                                className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all resize-none backdrop-blur-md"
                            />
                        </div>
                        
                        {renderCustomFields()}

                        <div className="flex-grow"></div>

                        <button
                            onClick={handleRegenerate}
                            disabled={isRegenerating}
                            className="w-full px-6 py-3 font-semibold text-white bg-fuchsia-600 rounded-lg shadow-[0_0_20px_rgba(217,70,239,0.4)] hover:bg-fuchsia-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all flex items-center justify-center"
                        >
                            {isRegenerating ? <><Spinner className="w-5 h-5 mr-3" /> Regenerating...</> : `Regenerate ${activeSide === 'front' ? 'Front' : 'Back'}`}
                        </button>
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end items-center gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    {showSaveOptions ? (
                        <>
                            <button onClick={() => setShowSaveOptions(false)} className="btn-secondary">Back</button>
                            <button onClick={handleOverwrite} className="btn-secondary bg-sky-600/50 border-sky-500/50 hover:bg-sky-600/80">Overwrite Original</button>
                            <button onClick={handleSaveAsNew} className="btn-primary">Save {activeSide} as Copy</button>
                        </>
                    ) : (
                        <button
                            onClick={() => setShowSaveOptions(true)}
                            disabled={(activeSide === 'front' && !newImagePreview) || (activeSide === 'back' && !backImagePreview) || isRegenerating}
                            className="btn-primary"
                        >
                            Save Changes
                        </button>
                    )}
                </footer>
                
                {isViewingLarge && !isMaskingMode && (
                    <div 
                        className="absolute inset-0 bg-black/80 flex items-center justify-center z-20 animate-fade-in"
                        onClick={() => setIsViewingLarge(false)}
                    >
                        <img 
                            src={currentImage}
                            alt="Large asset preview"
                            className="max-w-[90vw] max-h-[90vh] object-contain shadow-2xl rounded-lg"
                            onClick={(e) => e.stopPropagation()}
                        />
                         <button 
                            onClick={() => setIsViewingLarge(false)}
                            className="absolute top-4 right-4 text-white/70 hover:text-white transition-opacity"
                            title="Close"
                         >
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                 <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                             </svg>
                         </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ImageEditorModal;
