import React, { useRef } from 'react';
import Spinner from './Spinner';

interface AppHeaderProps {
    onNewProject: () => void;
    onLoadProject: (file: File) => void;
    onSaveProject: () => void;
    isSaveDisabled: boolean;
    isExporting: boolean;
    showDashboardControls: boolean;
    onUndo: () => void;
    onRedo: () => void;
    canUndo: boolean;
    canRedo: boolean;
}

const AppHeader: React.FC<AppHeaderProps> = ({
    onNewProject,
    onLoadProject,
    onSaveProject,
    isSaveDisabled,
    isExporting,
    showDashboardControls,
    onUndo,
    onRedo,
    canUndo,
    canRedo
}) => {
    const loadProjectInputRef = useRef<HTMLInputElement>(null);

    const handleLoadClick = () => {
        loadProjectInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            onLoadProject(e.target.files[0]);
        }
        // Reset file input to allow loading the same file again
        e.target.value = '';
    };

    return (
        <header className="fixed top-0 left-0 right-0 bg-black/30 backdrop-blur-lg border-b border-white/10 z-50 p-3 flex items-center justify-between">
            <div className="flex items-center gap-4">
                 <div className="w-10 h-10 bg-gradient-to-br from-fuchsia-600 to-purple-600 rounded-lg flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                 </div>
                <h1 className="text-xl font-bold text-white hidden sm:block">Event Design Kit Generator</h1>
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
                 {showDashboardControls && (
                    <>
                        <button onClick={onUndo} disabled={!canUndo} className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors" title="Undo (Ctrl+Z)">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 15l-3-3m0 0l3-3m-3 3h8A5 5 0 009 5H7" /></svg>
                        </button>
                        <button onClick={onRedo} disabled={!canRedo} className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors" title="Redo (Ctrl+Y)">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 15l3-3m0 0l-3-3m3 3H5A5 5 0 0013 5h2" /></svg>
                        </button>
                        <div className="w-px h-6 bg-white/10 mx-1"></div>
                    </>
                )}
                <button onClick={onNewProject} className="btn-tertiary">New Project</button>
                <input type="file" ref={loadProjectInputRef} className="hidden" accept=".zip" onChange={handleFileChange} />
                <button onClick={handleLoadClick} className="btn-secondary">Load Project</button>
                <button onClick={onSaveProject} disabled={isSaveDisabled || isExporting} className="btn-primary px-4 py-2 text-sm">
                    {isExporting ? <Spinner className="w-5 h-5"/> : 'Save Project'}
                </button>
            </div>
        </header>
    );
};

export default AppHeader;