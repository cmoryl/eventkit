
import React, { useState } from 'react';
import { AssetType } from '../types';
import type { GeneratedAsset, ColorInfo, PresentationData } from '../types';
import SkeletonLoader from './SkeletonLoader';
import LocationIntelCard from './LocationIntelCard';
import { getAspectRatioStyle } from '../utils';
import Spinner from './Spinner';

interface AssetCardProps {
  asset: GeneratedAsset;
  onView: (asset: GeneratedAsset) => void;
  onEdit: (asset: GeneratedAsset) => void;
  onDelete: (assetId: string) => void;
  onGeneratePhotorealisticShot: (asset: GeneratedAsset) => void;
  onGenerateVariation?: (asset: GeneratedAsset) => void;
  onToggleFavorite?: (asset: GeneratedAsset) => void;
  onMoveToFolder?: (asset: GeneratedAsset) => void;
}

const AssetCard: React.FC<AssetCardProps> = ({ 
    asset, 
    onView, 
    onEdit, 
    onDelete, 
    onGeneratePhotorealisticShot, 
    onGenerateVariation,
    onToggleFavorite,
    onMoveToFolder
}) => {
    const [isFlipped, setIsFlipped] = useState(false);
    const [isDownloading, setIsDownloading] = useState(false);
    
    const contentToShow = isFlipped && asset.backContent ? asset.backContent : asset.content;

    const handleDownload = async (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsDownloading(true);
        try {
            if (typeof asset.content === 'string' && (asset.content.startsWith('data:image') || asset.content.startsWith('blob:'))) {
                const link = document.createElement('a');
                link.href = asset.content;
                link.download = `${asset.title.replace(/\s+/g, '_')}.png`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else if (asset.type === AssetType.VideoTeaser && typeof asset.content === 'string') {
                 const link = document.createElement('a');
                 link.href = asset.content;
                 link.download = `${asset.title.replace(/\s+/g, '_')}.mp4`;
                 document.body.appendChild(link);
                 link.click();
                 document.body.removeChild(link);
            } else {
                // Text/JSON assets
                const contentString = typeof asset.content === 'string' ? asset.content : JSON.stringify(asset.content, null, 2);
                const blob = new Blob([contentString], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `${asset.title.replace(/\s+/g, '_')}.txt`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
            }
        } catch (error) {
            console.error("Download failed", error);
        } finally {
            setIsDownloading(false);
        }
    };

    const renderContent = () => {
        if (asset.isLoading) {
            return (
                <div className="relative w-full h-full flex items-center justify-center overflow-hidden rounded-lg" style={getAspectRatioStyle(asset.type)}>
                    <SkeletonLoader className="absolute inset-0 w-full h-full opacity-50" />
                    <div className="absolute inset-0 flex flex-col items-center justify-center z-10 bg-black/10 backdrop-blur-[2px]">
                        <Spinner className="w-6 h-6 text-fuchsia-400 mb-2" />
                        <span className="text-xs text-fuchsia-100 font-medium animate-pulse shadow-black drop-shadow-md">Generating...</span>
                    </div>
                </div>
            );
        }

        if (asset.type === AssetType.Palette) {
            const colors = asset.content as ColorInfo[];
            return (
                <div className="grid grid-cols-3 grid-rows-2 h-full gap-1 w-full">
                    {colors.slice(0, 6).map((color, index) => (
                        <div key={index} style={{ backgroundColor: color.hex }} className={index === 0 ? 'col-span-3' : ''}></div>
                    ))}
                </div>
            );
        }
        
        if (asset.type === AssetType.Slogans || asset.type === AssetType.MarketingCopy || asset.type === AssetType.RunOfShow || asset.type === AssetType.Soundtrack) {
             const textContent = Array.isArray(asset.content) ? asset.content : (typeof asset.content === 'string' ? asset.content.split('\n') : []);
             if (asset.type === AssetType.Slogans) {
                 return (
                    <div className="p-3 text-left space-y-1 overflow-y-auto w-full h-full">
                        {textContent.map((slogan, index) => (
                            <p key={index} className="text-xs text-gray-300">
                            - {slogan}
                            </p>
                        ))}
                    </div>
                );
             }
             return <LocationIntelCard content={asset.content as string} />;
        }

        if (asset.type === AssetType.LocationIntel || asset.type === AssetType.StyleGuide) {
            return <LocationIntelCard content={asset.content as string} />;
        }

        if (asset.type === AssetType.VideoTeaser) {
            return (
                 <video
                    src={asset.content as string}
                    className="w-full h-full object-cover"
                    muted
                    loop
                    autoPlay
                    playsInline
                    style={getAspectRatioStyle(asset.type)}
                />
            );
        }

        if (asset.type === AssetType.Presentation) {
            const presData = asset.content as PresentationData;
            if (!presData || typeof presData !== 'object' || !Array.isArray(presData.slides)) {
                return (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-gray-800 p-4 text-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                        </svg>
                        <span className="text-xs text-gray-400">Presentation data unavailable</span>
                    </div>
                );
            }
            return (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gray-800 text-center p-4 relative overflow-hidden">
                    {presData.slides[0]?.background && (
                        <div className="absolute inset-0 opacity-30" style={{ 
                            background: presData.slides[0].background.startsWith('#') ? presData.slides[0].background : `url(${presData.slides[0].background}) center/cover`
                        }} />
                    )}
                    <div className="z-10">
                        <h3 className="text-white font-bold text-sm mb-1">{presData.title}</h3>
                        <p className="text-xs text-gray-400">{presData.slides.length} Slides</p>
                    </div>
                </div>
            );
        }

        if (typeof contentToShow === 'string' && (contentToShow.startsWith('data:image') || contentToShow.startsWith('blob:'))) {
            return (
                 <img
                    src={contentToShow as string}
                    alt={asset.title}
                    className="w-full h-full object-contain transition-opacity duration-300"
                    style={getAspectRatioStyle(asset.type)}
                />
            );
        }

        return <div className="text-gray-400 text-sm p-4 text-center">No preview available</div>;
    };
    
    const canBeEdited = asset.type !== AssetType.LocationIntel && asset.type !== AssetType.VideoTeaser && !asset.isLoading && asset.type !== AssetType.Logo;
    const canGeneratePhotoShot = !asset.isLoading && asset.type !== AssetType.PhotorealisticShot && asset.type !== AssetType.Logo && typeof asset.content === 'string' && (asset.content.startsWith('data:image') || asset.content.startsWith('blob:'));
    const canHaveVariation = !asset.isLoading && asset.type !== AssetType.Palette && asset.type !== AssetType.LocationIntel && asset.type !== AssetType.PhotorealisticShot && asset.type !== AssetType.VideoTeaser && asset.type !== AssetType.NameTag && asset.type !== AssetType.Presentation && asset.type !== AssetType.Logo; 
    const hasBackSide = !!asset.backContent;

    return (
        <div className="relative group bg-black/20 rounded-lg overflow-hidden border border-white/10 flex flex-col animate-fade-in-fast h-full hover:border-white/20 transition-colors">
            {/* Favorite Button */}
            {onToggleFavorite && !asset.isLoading && (
                <button 
                    onClick={(e) => { e.stopPropagation(); onToggleFavorite(asset); }}
                    className={`absolute top-2 right-2 z-30 p-1.5 rounded-full transition-all duration-200 ${asset.isFavorite ? 'bg-pink-600 text-white opacity-100' : 'bg-black/40 text-gray-400 opacity-0 group-hover:opacity-100 hover:bg-black/60 hover:text-white'}`}
                    title={asset.isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                    </svg>
                </button>
            )}
            
            {/* Flip Button for Dual Sided Assets */}
            {hasBackSide && !asset.isLoading && (
                <button
                    onClick={(e) => { e.stopPropagation(); setIsFlipped(!isFlipped); }}
                    className="absolute top-2 left-2 z-30 p-1.5 rounded-full bg-black/40 text-gray-300 hover:bg-fuchsia-600 hover:text-white transition-all opacity-0 group-hover:opacity-100 border border-white/10"
                    title={isFlipped ? "Show Front" : "Show Back"}
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                    </svg>
                </button>
            )}

            <div 
                className="flex-grow flex items-center justify-center cursor-pointer w-full relative"
                onClick={() => !asset.isLoading && onView(asset)}
                style={{minHeight: '150px'}}
            >
                {renderContent()}
                {hasBackSide && isFlipped && (
                    <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 bg-black/60 px-2 py-0.5 rounded text-[10px] text-white uppercase tracking-wider pointer-events-none">
                        Back Side
                    </div>
                )}
            </div>
            <div className="flex-shrink-0 p-3 bg-white/5 border-t border-white/10 flex justify-between items-center">
                <div className="overflow-hidden mr-2">
                    <h3 className="text-sm font-semibold text-white truncate" title={asset.title}>{asset.title}</h3>
                    <p className="text-xs text-gray-400">{asset.type.replace(/_/g, ' ')}</p>
                </div>
            </div>
            
            {!asset.isLoading && (
                 <div className="absolute inset-0 bg-black/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4 text-center z-20 backdrop-blur-sm">
                    <div className="space-y-2 w-full">
                        <div className="flex gap-2">
                             <button onClick={(e) => { e.stopPropagation(); onView(asset); }} className="btn-secondary flex-1 text-xs py-2">View</button>
                             {canBeEdited && <button onClick={(e) => { e.stopPropagation(); onEdit(asset); }} className="btn-secondary flex-1 text-xs py-2">Edit</button>}
                        </div>
                        
                        {canHaveVariation && onGenerateVariation && (
                            <button onClick={(e) => { e.stopPropagation(); onGenerateVariation(asset); }} className="btn-secondary w-full flex items-center justify-center text-xs py-2">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                Variation
                            </button>
                        )}

                        {onMoveToFolder && (
                             <button onClick={(e) => { e.stopPropagation(); onMoveToFolder(asset); }} className="btn-secondary w-full flex items-center justify-center text-xs py-2 bg-white/5 hover:bg-white/10">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 19a2 2 0 01-2-2V7a2 2 0 012-2h4l2 2h4a2 2 0 012 2v1M5 19h14a2 2 0 002-2v-5a2 2 0 00-2-2H9a2 2 0 00-2 2v5a2 2 0 01-2 2z" /></svg>
                                Move to Folder
                            </button>
                        )}

                        <button onClick={handleDownload} className="btn-secondary w-full text-xs py-2 flex items-center justify-center" disabled={isDownloading}>
                            {isDownloading ? <Spinner className="w-3 h-3"/> : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                                    Download
                                </>
                            )}
                        </button>

                        {canGeneratePhotoShot && <button onClick={(e) => { e.stopPropagation(); onGeneratePhotorealisticShot(asset); }} className="btn-secondary w-full text-xs py-2">Photo Shot</button>}
                        
                        <button onClick={(e) => { e.stopPropagation(); onDelete(asset.id); }} className="text-xs text-red-400 hover:text-red-300 hover:underline mt-1">Delete Asset</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AssetCard;
