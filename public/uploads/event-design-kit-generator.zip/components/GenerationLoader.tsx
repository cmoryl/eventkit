
import React from 'react';
import type { GeneratedAsset } from '../types';

interface GenerationLoaderProps {
  current: number;
  total: number;
  assets?: GeneratedAsset[];
}

const GenerationLoader: React.FC<GenerationLoaderProps> = ({ current, total, assets }) => {
    const percentage = total > 0 ? Math.round((current / total) * 100) : 0;
    const circumference = 2 * Math.PI * 90; // 90 is the radius
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div className="fixed inset-0 bg-gray-900/95 backdrop-blur-xl flex flex-col items-center justify-center z-[100] animate-fade-in p-8">
            <div className="flex flex-col items-center flex-shrink-0 mb-8">
                <div className="relative w-48 h-48 flex items-center justify-center mb-6">
                    <svg className="absolute w-full h-full transform -rotate-90" viewBox="0 0 256 256">
                        <circle
                            className="text-white/5"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="transparent"
                            r="90"
                            cx="128"
                            cy="128"
                        />
                        <circle
                            className="text-fuchsia-500 transition-all duration-500 ease-out"
                            stroke="currentColor"
                            strokeWidth="8"
                            strokeLinecap="round"
                            fill="transparent"
                            r="90"
                            cx="128"
                            cy="128"
                            style={{
                                strokeDasharray: circumference,
                                strokeDashoffset: offset,
                            }}
                        />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-36 h-36 rounded-full bg-fuchsia-500/10 shadow-[0_0_30px_rgba(217,70,239,0.2)] animate-pulse-inner flex items-center justify-center">
                             <span className="text-4xl font-bold text-white tracking-tighter">
                                {percentage}%
                            </span>
                        </div>
                    </div>
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-2">Generating your design kit...</h2>
                <p className="text-gray-400">
                    {current} of {total} assets completed
                </p>
            </div>

            {assets && assets.length > 0 && (
                <div className="w-full max-w-5xl overflow-y-auto custom-scrollbar p-2">
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                        {assets.map((asset) => {
                            const isDone = !asset.isLoading && asset.content;
                            const isFailed = !asset.isLoading && !asset.content;
                            const isPending = asset.isLoading;

                            return (
                                <div 
                                    key={asset.id} 
                                    className={`
                                        flex items-center p-3 rounded-lg border transition-all duration-500
                                        ${isDone 
                                            ? 'bg-green-500/10 border-green-500/20' 
                                            : isFailed 
                                                ? 'bg-red-500/10 border-red-500/20'
                                                : 'bg-white/5 border-white/10'
                                        }
                                    `}
                                >
                                    <div className="mr-3 flex-shrink-0">
                                        {isPending ? (
                                            <svg className="animate-spin h-4 w-4 text-fuchsia-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                        ) : isDone ? (
                                            <div className="h-4 w-4 rounded-full bg-green-500 flex items-center justify-center">
                                                <svg className="h-3 w-3 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                                </svg>
                                            </div>
                                        ) : (
                                             <div className="h-4 w-4 rounded-full bg-red-500 flex items-center justify-center">
                                                <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                                                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                                </svg>
                                            </div>
                                        )}
                                    </div>
                                    <span className={`text-xs font-medium truncate ${isDone ? 'text-green-200' : 'text-gray-300'}`}>
                                        {asset.title}
                                    </span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            )}
        </div>
    );
};

export default GenerationLoader;
