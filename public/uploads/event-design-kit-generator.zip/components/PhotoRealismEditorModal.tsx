// Fix: Removed file marker comments that were causing syntax errors.
import React, { useState, useEffect, useCallback } from 'react';
import type { GeneratedAsset } from '../types';
import { regeneratePhotorealisticShot } from '../services/geminiService';
import Spinner from './Spinner';
import SkeletonLoader from './SkeletonLoader';

interface PhotoRealismEditorModalProps {
  asset: GeneratedAsset;
  sourceAsset: GeneratedAsset;
  onClose: () => void;
  onOverwrite: (assetId: string, newContent: string) => void;
  onSavePhotoShotAsNew: (assetId: string, newContent: string) => void;
}

const EnvironmentUploader: React.FC<{
    file: File | null;
    preview: string | null;
    onFileChange: (file: File) => void;
}> = ({ file, preview, onFileChange }) => {
    const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            onFileChange(e.target.files[0]);
        }
    }, [onFileChange]);

    const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => e.preventDefault(), []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        if (e.dataTransfer.files && e.dataTransfer.files[0] && e.dataTransfer.files[0].type.startsWith('image/')) {
            onFileChange(e.dataTransfer.files[0]);
        }
    }, [onFileChange]);

    return (
        <div className="w-full">
            <label 
                htmlFor="env-upload"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className="relative flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-white/20 rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 backdrop-blur-md transition-colors"
            >
                {preview ? (
                    <img src={preview} alt="Environment Preview" className="max-h-full max-w-full p-2 object-contain rounded-lg" />
                ) : (
                    <div className="flex flex-col items-center justify-center pt-5 pb-6 text-gray-400 text-center">
                         <svg className="w-8 h-8 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                        <p className="text-xs"><span className="font-semibold">Upload Environment</span> or drag & drop</p>
                    </div>
                )}
                <input id="env-upload" type="file" className="hidden" onChange={handleFileChange} accept="image/*" />
            </label>
        </div>
    );
};


const PhotoRealismEditorModal: React.FC<PhotoRealismEditorModalProps> = ({ asset, sourceAsset, onClose, onOverwrite, onSavePhotoShotAsNew }) => {
    const [regenerationPrompt, setRegenerationPrompt] = useState('');
    const [newImagePreview, setNewImagePreview] = useState<string | null>(null);
    const [isRegenerating, setIsRegenerating] = useState(false);
    const [environmentFile, setEnvironmentFile] = useState<File | null>(null);
    const [environmentPreview, setEnvironmentPreview] = useState<string | null>(null);
    const [isViewingLarge, setIsViewingLarge] = useState(false);
    const [showSaveOptions, setShowSaveOptions] = useState(false);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                onClose();
            }
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [onClose]);

    const handleEnvironmentChange = useCallback((file: File) => {
        setEnvironmentFile(file);
        setEnvironmentPreview(URL.createObjectURL(file));
    }, []);

    const handleRegenerate = async () => {
        if (!regenerationPrompt.trim() && !environmentFile) {
            alert("Please provide a description or an environment image to regenerate.");
            return;
        }
        setIsRegenerating(true);
        setNewImagePreview(null);
        setShowSaveOptions(false);
        try {
            const result = await regeneratePhotorealisticShot(sourceAsset, regenerationPrompt, environmentFile);
            setNewImagePreview(result);
        } catch (e) {
            console.error("Photo regeneration failed:", e);
            alert("Sorry, the photo could not be regenerated. Please try a different prompt or check the console for errors.");
        } finally {
            setIsRegenerating(false);
        }
    };
    
    const handleOverwrite = () => {
        if (newImagePreview) {
            onOverwrite(asset.id, newImagePreview);
        }
    }

    const handleSaveAsNew = () => {
        if (newImagePreview) {
            onSavePhotoShotAsNew(asset.id, newImagePreview);
        }
    }
    
    const currentImage = newImagePreview || (asset.content as string);

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col animate-scale-in relative"
                onClick={(e) => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">Edit Photorealistic Shot</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </header>

                <div className="flex-grow p-4 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-black/20 rounded-lg flex items-center justify-center p-2 relative group">
                         {isRegenerating ? (
                            <SkeletonLoader
                                style={{aspectRatio: '1 / 1'}}
                                className="w-full max-w-full max-h-[60vh]"
                            />
                        ) : (
                            <>
                                <img 
                                    src={currentImage} 
                                    alt="Asset Preview" 
                                    className="max-w-full max-h-[60vh] object-contain"
                                />
                                <button
                                    onClick={() => setIsViewingLarge(true)}
                                    className="absolute top-2 right-2 p-2 rounded-full bg-black/50 hover:bg-black/75 backdrop-blur-sm transition-all duration-300 opacity-0 group-hover:opacity-100"
                                    title="View larger"
                                >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0zM10 7v3m0 0v3m0-3h3m-3 0H7" />
                                    </svg>
                                </button>
                            </>
                        )}
                    </div>
                    <div className="flex flex-col space-y-4">
                        <p className="text-sm text-gray-400">
                           Regenerating photo for: <span className="font-semibold text-gray-300">{sourceAsset.title}</span>
                        </p>
                        <div>
                            <label htmlFor="regen-prompt" className="text-sm font-medium text-gray-300 mb-2 block">
                                Describe changes or a new scene (e.g., "put this on a table at an outdoor cafe"):
                            </label>
                            <textarea
                                id="regen-prompt"
                                value={regenerationPrompt}
                                onChange={(e) => setRegenerationPrompt(e.target.value)}
                                placeholder="Change the lighting, angle, or environment..."
                                rows={5}
                                className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all resize-none backdrop-blur-md"
                            />
                        </div>
                         <div>
                            <label className="text-sm font-medium text-gray-300 mb-2 block">
                                Or upload a photo of the environment:
                            </label>
                           <EnvironmentUploader
                                file={environmentFile}
                                preview={environmentPreview}
                                onFileChange={handleEnvironmentChange}
                           />
                        </div>
                        
                        <button
                            onClick={handleRegenerate}
                            disabled={isRegenerating || (!regenerationPrompt.trim() && !environmentFile)}
                            className="w-full mt-auto px-6 py-3 font-semibold text-white bg-fuchsia-600 rounded-lg shadow-[0_0_20px_rgba(217,70,239,0.4)] hover:bg-fuchsia-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all flex items-center justify-center"
                        >
                            {isRegenerating ? <><Spinner className="w-5 h-5 mr-3" /> Regenerating...</> : 'Regenerate Photo'}
                        </button>
                    </div>
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end items-center gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    {showSaveOptions ? (
                        <>
                            <button onClick={() => setShowSaveOptions(false)} className="btn-secondary">Back</button>
                            <button onClick={handleOverwrite} className="btn-secondary bg-sky-600/50 border-sky-500/50 hover:bg-sky-600/80">Overwrite Original</button>
                            <button onClick={handleSaveAsNew} className="btn-primary">Save as New Copy</button>
                        </>
                    ) : (
                        <button
                            onClick={() => setShowSaveOptions(true)}
                            disabled={!newImagePreview || isRegenerating}
                            className="btn-primary"
                        >
                            Save Changes
                        </button>
                    )}
                </footer>

                {isViewingLarge && (
                    <div 
                        className="absolute inset-0 bg-black/80 flex items-center justify-center z-20 animate-fade-in"
                        onClick={() => setIsViewingLarge(false)}
                    >
                        <img 
                            src={currentImage}
                            alt="Large asset preview"
                            className="max-w-[90vw] max-h-[90vh] object-contain shadow-2xl rounded-lg"
                            onClick={(e) => e.stopPropagation()}
                        />
                         <button 
                            onClick={() => setIsViewingLarge(false)}
                            className="absolute top-4 right-4 text-white/70 hover:text-white transition-opacity"
                            title="Close"
                         >
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                 <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                             </svg>
                         </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PhotoRealismEditorModal;