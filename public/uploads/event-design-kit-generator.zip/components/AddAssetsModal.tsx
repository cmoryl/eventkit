
import React, { useState, useEffect, useRef } from 'react';
import { AssetType } from '../types';
import Accordion from './Accordion';
import { fileToBase64, ASSET_CATEGORIES } from '../utils';

interface AddAssetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAssets: (assets: Set<AssetType>) => void;
  onUploadAsset: (file: File, type: AssetType, makeSeamless: boolean) => void;
  existingAssets: Set<AssetType>;
  assetGenerators: { type: AssetType; title: string }[];
}

const AddAssetsModal: React.FC<AddAssetsModalProps> = ({ isOpen, onClose, onAddAssets, onUploadAsset, existingAssets, assetGenerators }) => {
    const [activeTab, setActiveTab] = useState<'generate' | 'upload'>('generate');
    
    // Generate Tab State
    const [selected, setSelected] = useState<Set<AssetType>>(new Set());

    // Upload Tab State
    const [uploadFile, setUploadFile] = useState<File | null>(null);
    const [uploadPreview, setUploadPreview] = useState<string | null>(null);
    const [uploadType, setUploadType] = useState<AssetType>(AssetType.SeamlessPattern);
    const [makeSeamless, setMakeSeamless] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setSelected(new Set());
            setUploadFile(null);
            setUploadPreview(null);
            setUploadType(AssetType.SeamlessPattern);
            setMakeSeamless(false);
            setActiveTab('generate');
        }
    }, [isOpen]);

    const handleSelect = (type: AssetType) => {
        setSelected(prev => {
            const newSet = new Set(prev);
            if (newSet.has(type)) {
                newSet.delete(type);
            } else {
                newSet.add(type);
            }
            return newSet;
        });
    };
    
    const handleAddClick = () => {
        onAddAssets(selected);
        onClose();
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setUploadFile(file);
            const base64 = await fileToBase64(file);
            setUploadPreview(`data:${base64.type};base64,${base64.data}`);
        }
    };

    const handleUploadClick = () => {
        if (uploadFile) {
            onUploadAsset(uploadFile, uploadType, makeSeamless);
            onClose();
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b border-white/10">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-xl font-bold text-white">Add Assets</h2>
                        <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                    <div className="flex gap-4 border-b border-white/10">
                        <button 
                            onClick={() => setActiveTab('generate')}
                            className={`pb-2 px-2 text-sm font-semibold transition-colors relative ${activeTab === 'generate' ? 'text-fuchsia-400' : 'text-gray-400 hover:text-white'}`}
                        >
                            Generate with AI
                            {activeTab === 'generate' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-fuchsia-500 rounded-t-full" />}
                        </button>
                        <button 
                            onClick={() => setActiveTab('upload')}
                            className={`pb-2 px-2 text-sm font-semibold transition-colors relative ${activeTab === 'upload' ? 'text-fuchsia-400' : 'text-gray-400 hover:text-white'}`}
                        >
                            Upload Custom
                            {activeTab === 'upload' && <div className="absolute bottom-0 left-0 w-full h-0.5 bg-fuchsia-500 rounded-t-full" />}
                        </button>
                    </div>
                </header>

                <div className="flex-grow p-6 overflow-y-auto">
                    {activeTab === 'generate' ? (
                        <div className="space-y-4">
                            <p className="text-sm text-gray-400 mb-4">Select additional assets to generate. You can add multiple copies of the same type to create variations.</p>
                            {Object.entries(ASSET_CATEGORIES).map(([category, types]) => {
                                const generatorsInCategory = assetGenerators.filter(gen => types.includes(gen.type));
                                if (generatorsInCategory.length === 0) return null;

                                return (
                                    <Accordion key={category} title={category}>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-2">
                                            {generatorsInCategory.map(gen => {
                                                const isSelected = selected.has(gen.type);
                                                const isExisting = existingAssets.has(gen.type);
                                                return (
                                                    <label key={gen.type} className={`flex items-center space-x-3 p-3 bg-black/20 rounded-lg border transition-all cursor-pointer ${isSelected ? 'border-fuchsia-500/50 bg-fuchsia-900/10' : 'border-transparent hover:bg-black/40 hover:border-white/10'}`}>
                                                        <input type="checkbox" checked={isSelected} onChange={() => handleSelect(gen.type)} className="h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400" />
                                                        <div className="flex flex-col">
                                                            <span className="text-gray-300 font-medium">{gen.title}</span>
                                                            {isExisting && <span className="text-[10px] text-fuchsia-400 font-semibold uppercase tracking-wider">Already in project</span>}
                                                        </div>
                                                    </label>
                                                );
                                            })}
                                        </div>
                                    </Accordion>
                                );
                            })}
                        </div>
                    ) : (
                        <div className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">Asset Type</label>
                                <select 
                                    value={uploadType} 
                                    onChange={(e) => setUploadType(e.target.value as AssetType)} 
                                    className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all"
                                >
                                    {assetGenerators.map(gen => (
                                        <option key={gen.type} value={gen.type}>{gen.title}</option>
                                    ))}
                                </select>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-300 mb-2">Upload File</label>
                                <label className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-white/20 rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 transition-colors">
                                    {uploadPreview ? (
                                        <img src={uploadPreview} alt="Preview" className="h-full w-full object-contain p-2 rounded-lg" />
                                    ) : (
                                        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-gray-400">
                                            <svg className="w-10 h-10 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                                            <p className="mb-2 text-sm"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                            <p className="text-xs">PNG, JPG up to 10MB</p>
                                        </div>
                                    )}
                                    <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                                </label>
                            </div>

                            {uploadType === AssetType.SeamlessPattern && (
                                <div className="p-4 bg-fuchsia-900/20 border border-fuchsia-500/30 rounded-lg">
                                    <label className="flex items-start space-x-3 cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            checked={makeSeamless} 
                                            onChange={(e) => setMakeSeamless(e.target.value === 'on')} 
                                            className="mt-1 h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400" 
                                        />
                                        <div>
                                            <span className="block text-white font-medium">Generate seamless pattern from this image</span>
                                            <span className="block text-xs text-gray-300 mt-1">
                                                If checked, AI will process your upload to create a perfectly tileable, seamless texture based on it. 
                                                If unchecked, the image will be added to your kit exactly as is.
                                            </span>
                                        </div>
                                    </label>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <footer className="p-4 border-t border-white/10 flex justify-end items-center gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    {activeTab === 'generate' ? (
                         <button onClick={handleAddClick} disabled={selected.size === 0} className="btn-primary">
                            Generate {selected.size > 0 ? `${selected.size} New Asset(s)` : ''}
                        </button>
                    ) : (
                        <button onClick={handleUploadClick} disabled={!uploadFile} className="btn-primary">
                            {makeSeamless ? 'Generate Pattern' : 'Upload Asset'}
                        </button>
                    )}
                </footer>
            </div>
        </div>
    );
};

export default AddAssetsModal;
