
import React, { useRef, useState } from 'react';
import type { ColorInfo, EventDetails } from '../types';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import Spinner from './Spinner';

interface BrandStyleGuideProps {
    content: string;
    colorPalette?: ColorInfo[];
    logos?: { url: string; name: string }[];
    eventDetails: EventDetails;
}

const BrandStyleGuide: React.FC<BrandStyleGuideProps> = ({ content, colorPalette = [], logos = [], eventDetails }) => {
    const primaryLogo = logos[0];
    const secondaryLogos = logos.slice(1);
    const guideRef = useRef<HTMLDivElement>(null);
    const [isExporting, setIsExporting] = useState(false);

    // Simple parser for the AI Markdown content to render it nicely in the guide
    const renderMarkdownContent = (text: string) => {
        return text.split('\n').map((line, i) => {
            const cleanLine = line.trim();
            if (!cleanLine) return <div key={i} className="h-2" />;
            
            if (cleanLine.startsWith('**') || cleanLine.startsWith('##') || cleanLine.endsWith(':')) {
                return <h3 key={i} className="text-fuchsia-400 font-bold uppercase text-sm mt-4 mb-2 tracking-wider">{cleanLine.replace(/[#*:]/g, '')}</h3>;
            }
            if (cleanLine.startsWith('- ')) {
                return (
                    <div key={i} className="flex items-start mb-1 text-gray-300">
                        <span className="mr-2 text-fuchsia-500">•</span>
                        <span>{cleanLine.substring(2)}</span>
                    </div>
                );
            }
            return <p key={i} className="text-gray-400 text-sm mb-1 leading-relaxed">{cleanLine}</p>;
        });
    };

    const handleExportPdf = async () => {
        if (!guideRef.current) return;
        setIsExporting(true);
        try {
            const canvas = await html2canvas(guideRef.current, {
                scale: 2,
                backgroundColor: '#111827', // Match dark theme
                logging: false,
                useCORS: true
            });
            
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'portrait',
                unit: 'px',
                format: [canvas.width, canvas.height]
            });
            
            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
            pdf.save(`${eventDetails.name.replace(/\s+/g, '_')}_Brand_Guidelines.pdf`);
        } catch (error) {
            console.error("PDF Export failed:", error);
            alert("Failed to export PDF. Please check console for details.");
        } finally {
            setIsExporting(false);
        }
    };

    return (
        <div className="w-full">
            <div className="flex justify-end mb-4 px-4 sm:px-0">
                <button 
                    onClick={handleExportPdf} 
                    disabled={isExporting}
                    className="btn-primary text-xs py-2 px-4 flex items-center gap-2"
                >
                    {isExporting ? <Spinner className="w-3 h-3"/> : (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                        </svg>
                    )}
                    Download Guide PDF
                </button>
            </div>

            <div ref={guideRef} className="bg-gray-900 border border-white/10 p-8 rounded-lg shadow-2xl w-full max-w-5xl mx-auto overflow-hidden text-left">
                {/* Header */}
                <header className="border-b border-white/10 pb-6 mb-8 flex justify-between items-end">
                    <div>
                        <h1 className="text-3xl md:text-4xl font-bold text-white uppercase tracking-tighter mb-2">{eventDetails.name || 'Event Name'}</h1>
                        <p className="text-xs md:text-sm font-mono text-fuchsia-500 uppercase tracking-widest">Brand Guidelines & Visual Identity System</p>
                    </div>
                    <div className="text-right text-[10px] font-mono text-gray-500 hidden sm:block">
                        <p>Generated {new Date().toLocaleDateString()}</p>
                        <p>v1.0</p>
                    </div>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Left Column: Visual Assets */}
                    <div className="lg:col-span-2 space-y-10">
                        
                        {/* 1. Logomark */}
                        <section>
                            <h2 className="text-xs font-bold text-gray-500 uppercase border-b border-white/10 pb-2 mb-4">01. Logomark</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div className="p-6 bg-white/5 rounded-lg flex flex-col items-center justify-center aspect-video border border-white/5">
                                    {primaryLogo ? (
                                        <img src={primaryLogo.url} alt="Primary Logo" className="max-h-full max-w-full object-contain shadow-lg" />
                                    ) : (
                                        <span className="text-gray-600 italic text-xs">No Primary Logo</span>
                                    )}
                                    <span className="mt-4 text-[10px] text-gray-500 uppercase tracking-widest">Primary</span>
                                </div>
                                <div className="grid grid-rows-2 gap-4">
                                    <div className="p-4 bg-white rounded-lg flex items-center justify-center relative overflow-hidden">
                                        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:8px_8px]"></div>
                                        {primaryLogo && <img src={primaryLogo.url} alt="Logo on Light" className="max-h-full max-w-full object-contain relative z-10" />}
                                    </div>
                                    <div className="p-4 bg-black rounded-lg flex items-center justify-center border border-white/10">
                                        {primaryLogo && <img src={primaryLogo.url} alt="Logo on Dark" className="max-h-full max-w-full object-contain" />}
                                    </div>
                                </div>
                            </div>
                            {secondaryLogos.length > 0 && (
                                <div className="mt-4 flex gap-4 overflow-x-auto pb-2 custom-scrollbar">
                                    {secondaryLogos.map((logo, i) => (
                                        <div key={i} className="flex-shrink-0 w-24 h-24 bg-white/5 rounded p-2 flex items-center justify-center border border-white/5">
                                            <img src={logo.url} alt={logo.name} className="max-h-full max-w-full object-contain opacity-80 hover:opacity-100 transition-opacity" />
                                        </div>
                                    ))}
                                </div>
                            )}
                        </section>

                        {/* 2. Color Palette */}
                        <section>
                            <h2 className="text-xs font-bold text-gray-500 uppercase border-b border-white/10 pb-2 mb-4">02. Color Palette</h2>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                {colorPalette.map((color, idx) => (
                                    <div key={idx} className="group">
                                        <div 
                                            className="h-24 w-full rounded-lg shadow-lg mb-3 border border-white/10 transform group-hover:scale-105 transition-transform" 
                                            style={{ backgroundColor: color.hex }}
                                        />
                                        <div className="font-mono text-[10px] space-y-0.5">
                                            <p className="font-bold text-white text-xs mb-1 truncate">{color.name}</p>
                                            <p className="text-gray-400">{color.hex.toUpperCase()}</p>
                                            <p className="text-gray-600 truncate">{color.cmyk}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </section>

                        {/* 3. Typography Mockup */}
                        <section>
                            <h2 className="text-xs font-bold text-gray-500 uppercase border-b border-white/10 pb-2 mb-4">03. Typography</h2>
                            <div className="bg-white/5 p-6 rounded-lg border border-white/5">
                                <div className="mb-6">
                                    <p className="text-[10px] font-mono text-fuchsia-500 mb-2 uppercase">Primary Headline (Inter Bold)</p>
                                    <div className="text-3xl sm:text-4xl font-bold text-white tracking-tight leading-tight">
                                        The Quick Brown Fox Jumps Over The Lazy Dog.
                                    </div>
                                </div>
                                <div>
                                    <p className="text-[10px] font-mono text-gray-500 mb-2 uppercase">Body Copy (Inter Regular)</p>
                                    <p className="text-sm leading-relaxed text-gray-300 max-w-prose">
                                        Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. Dramatically maintain clicks-and-mortar solutions without functional solutions.
                                    </p>
                                </div>
                            </div>
                        </section>
                    </div>

                    {/* Right Column: Strategic Guidelines (AI Text) */}
                    <div className="lg:col-span-1 border-l border-white/10 lg:pl-8">
                        <section>
                            <h2 className="text-xs font-bold text-gray-500 uppercase border-b border-white/10 pb-2 mb-4">04. Strategy</h2>
                            <div className="prose prose-invert prose-sm max-w-none">
                                {renderMarkdownContent(content)}
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BrandStyleGuide;
