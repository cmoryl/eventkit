
import React, { useState, useEffect, useRef } from 'react';
import QRCodeStyling, { Options as QRCodeStylingOptions, DotType, CornerSquareType, CornerDotType, ErrorCorrectionLevel } from 'qr-code-styling';
import type { GeneratedAsset, QRCodeGenerationParams } from '../types';
import Spinner from './Spinner';
import Accordion from './Accordion';
import { fileToBase64 } from '../utils';

interface QRCodeGeneratorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (data: { content: string; params: QRCodeGenerationParams }) => void;
    initialAsset: GeneratedAsset | null;
    primaryLogoUrl?: string;
}

const defaultParams: QRCodeGenerationParams = {
    url: '',
    foregroundColor: '#000000',
    backgroundColor: '#FFFFFF',
    margin: 10,
    errorCorrectionLevel: 'Q',
    dotsType: 'squares',
    cornersSquareType: 'square',
    cornersDotType: 'square',
    logoImage: undefined,
    logoWidth: 0,
    logoHeight: 0,
    logoMargin: 0,
};

const Label: React.FC<{ htmlFor?: string; children: React.ReactNode; className?: string }> = ({ htmlFor, children, className }) => (
    <label htmlFor={htmlFor} className={`block text-sm font-medium text-gray-300 mb-2 ${className}`}>
        {children}
    </label>
);

const RadioButton: React.FC<{ name: string; value: string; checked: boolean; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; children: React.ReactNode }> = ({ name, value, checked, onChange, children }) => (
    <label className="flex items-center space-x-2 p-2 bg-white/5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer">
        <input type="radio" name={name} value={value} checked={checked} onChange={onChange} className="h-4 w-4 bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400" />
        <span className="text-sm text-gray-200">{children}</span>
    </label>
);

const QRCodeGeneratorModal: React.FC<QRCodeGeneratorModalProps> = ({ isOpen, onClose, onSave, initialAsset, primaryLogoUrl }) => {
    const [params, setParams] = useState<QRCodeGenerationParams>(defaultParams);
    const [isSaving, setIsSaving] = useState(false);
    
    const qrRef = useRef<HTMLDivElement>(null);
    const qrCodeInstanceRef = useRef<QRCodeStyling | null>(null);

    useEffect(() => {
        if (isOpen) {
            const initial = initialAsset?.generationParams ? (initialAsset.generationParams as QRCodeGenerationParams) : { ...defaultParams, url: initialAsset?.content as string || '' };
            setParams(initial);
        }
    }, [isOpen, initialAsset]);

    useEffect(() => {
        if (!isOpen || !qrRef.current) return;

        if (!qrCodeInstanceRef.current) {
            qrCodeInstanceRef.current = new QRCodeStyling({
                width: 300,
                height: 300,
                data: params.url,
                margin: params.margin,
                qrOptions: { errorCorrectionLevel: params.errorCorrectionLevel },
                dotsOptions: { color: params.foregroundColor, type: params.dotsType as DotType },
                backgroundOptions: { color: params.backgroundColor },
                cornersSquareOptions: { color: params.foregroundColor, type: params.cornersSquareType as CornerSquareType },
                cornersDotOptions: { color: params.foregroundColor, type: params.cornersDotType as CornerDotType },
                image: params.logoImage,
                imageOptions: {
                    imageSize: 0.4,
                    margin: params.logoMargin,
                },
            });
            qrCodeInstanceRef.current.append(qrRef.current);
        } else {
            qrCodeInstanceRef.current.update({
                data: params.url,
                margin: params.margin,
                qrOptions: { errorCorrectionLevel: params.errorCorrectionLevel },
                dotsOptions: { color: params.foregroundColor, type: params.dotsType as DotType },
                backgroundOptions: { color: params.backgroundColor },
                cornersSquareOptions: { color: params.foregroundColor, type: params.cornersSquareType as CornerSquareType },
                cornersDotOptions: { color: params.foregroundColor, type: params.cornersDotType as CornerDotType },
                image: params.logoImage,
                imageOptions: {
                    imageSize: 0.4,
                    margin: params.logoMargin,
                },
            });
        }
    }, [isOpen, params]);
    
    const handleParamChange = (field: keyof QRCodeGenerationParams, value: any) => {
        setParams(prev => ({ ...prev, [field]: value }));
    };
    
    const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const base64 = await fileToBase64(file);
            handleParamChange('logoImage', `data:${base64.type};base64,${base64.data}`);
        }
    };
    
    const handleUsePrimaryLogo = () => {
        if (primaryLogoUrl) {
            handleParamChange('logoImage', primaryLogoUrl);
        }
    };

    const handleSave = async () => {
        if (!params.url) {
            alert("URL cannot be empty.");
            return;
        }
        setIsSaving(true);
        try {
            const blob = await qrCodeInstanceRef.current?.getRawData('png');
            if (blob) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    onSave({
                        content: reader.result as string,
                        params: params,
                    });
                    setIsSaving(false);
                };
                reader.readAsDataURL(blob as Blob);
            } else {
                 throw new Error("Could not get QR code data.");
            }
        } catch (e) {
            console.error("Failed to save QR code", e);
            alert("An error occurred while saving the QR code.");
            setIsSaving(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">QR Code Engine</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </header>
                <div className="flex-grow flex overflow-hidden">
                    <div className="w-1/2 md:w-2/5 p-6 flex flex-col items-center justify-center bg-black/20">
                        <div ref={qrRef} className="rounded-lg overflow-hidden shadow-lg border border-white/10" />
                    </div>
                    <div className="w-1/2 md:w-3/5 p-6 overflow-y-auto space-y-4">
                        <Accordion title="Content & Colors">
                            <div className="p-2 space-y-4">
                                <div>
                                    <Label htmlFor="qr-url">URL</Label>
                                    <input id="qr-url" type="url" value={params.url} onChange={(e) => handleParamChange('url', e.target.value)} placeholder="https://your-event.com" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none" />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <Label>Foreground</Label>
                                        <input type="color" value={params.foregroundColor} onChange={(e) => handleParamChange('foregroundColor', e.target.value)} className="w-full h-10 p-1 bg-white/5 border border-white/20 rounded-lg cursor-pointer" />
                                    </div>
                                    <div>
                                        <Label>Background</Label>
                                        <input type="color" value={params.backgroundColor} onChange={(e) => handleParamChange('backgroundColor', e.target.value)} className="w-full h-10 p-1 bg-white/5 border border-white/20 rounded-lg cursor-pointer" />
                                    </div>
                                </div>
                            </div>
                        </Accordion>
                        <Accordion title="Shapes">
                            <div className="p-2 space-y-4">
                                <div>
                                    <Label>Dot Style</Label>
                                    <div className="grid grid-cols-3 gap-2">
                                        <RadioButton name="dotsType" value="squares" checked={params.dotsType === 'squares'} onChange={e => handleParamChange('dotsType', e.target.value)}>Squares</RadioButton>
                                        <RadioButton name="dotsType" value="dots" checked={params.dotsType === 'dots'} onChange={e => handleParamChange('dotsType', e.target.value)}>Dots</RadioButton>
                                        <RadioButton name="dotsType" value="rounded" checked={params.dotsType === 'rounded'} onChange={e => handleParamChange('dotsType', e.target.value)}>Rounded</RadioButton>
                                    </div>
                                </div>
                                <div>
                                    <Label>Corner Square Style</Label>
                                    <div className="grid grid-cols-3 gap-2">
                                        <RadioButton name="cornersSquareType" value="square" checked={params.cornersSquareType === 'square'} onChange={e => handleParamChange('cornersSquareType', e.target.value)}>Square</RadioButton>
                                        <RadioButton name="cornersSquareType" value="extra-rounded" checked={params.cornersSquareType === 'extra-rounded'} onChange={e => handleParamChange('cornersSquareType', e.target.value)}>Rounded</RadioButton>
                                        <RadioButton name="cornersSquareType" value="dot" checked={params.cornersSquareType === 'dot'} onChange={e => handleParamChange('cornersSquareType', e.target.value)}>Dot</RadioButton>
                                    </div>
                                </div>
                            </div>
                        </Accordion>
                        <Accordion title="Logo">
                           <div className="p-2 space-y-4">
                               <div className="flex gap-2">
                                   <label className="flex-1 btn-secondary text-center cursor-pointer">
                                        Upload Logo
                                        <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                                   </label>
                                   <button onClick={handleUsePrimaryLogo} disabled={!primaryLogoUrl} className="flex-1 btn-secondary disabled:opacity-50">Use Primary</button>
                                   <button onClick={() => handleParamChange('logoImage', undefined)} disabled={!params.logoImage} className="btn-secondary !bg-red-500/20 !border-red-500/30 disabled:opacity-50">Clear</button>
                               </div>
                               <div>
                                   <Label htmlFor="logoMargin">Logo Margin</Label>
                                   <input id="logoMargin" type="range" min="0" max="20" step="1" value={params.logoMargin} onChange={e => handleParamChange('logoMargin', Number(e.target.value))} className="w-full" />
                               </div>
                           </div>
                        </Accordion>
                         <Accordion title="Advanced">
                           <div className="p-2 space-y-4">
                               <div>
                                   <Label htmlFor="margin">Quiet Zone (Margin)</Label>
                                   <input id="margin" type="range" min="0" max="40" step="1" value={params.margin} onChange={e => handleParamChange('margin', Number(e.target.value))} className="w-full" />
                               </div>
                               <div>
                                   <Label>Error Correction</Label>
                                    <select value={params.errorCorrectionLevel} onChange={e => handleParamChange('errorCorrectionLevel', e.target.value)} className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-2 focus:ring-1 focus:ring-fuchsia-500 outline-none">
                                        <option value="L">Low (fastest)</option>
                                        <option value="M">Medium</option>
                                        <option value="Q">Quartile</option>
                                        <option value="H">High (most reliable)</option>
                                    </select>
                               </div>
                           </div>
                        </Accordion>
                    </div>
                </div>
                <footer className="p-4 border-t border-white/10 flex justify-end gap-4">
                    <button onClick={onClose} className="btn-secondary">Cancel</button>
                    <button onClick={handleSave} disabled={isSaving} className="btn-primary">
                        {isSaving ? <Spinner/> : (initialAsset ? 'Save Changes' : 'Create QR Code')}
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default QRCodeGeneratorModal;
