import React, { useState } from 'react';
import type { GeneratedLogoVariation } from '../types';
import Spinner from './Spinner';

interface LogoVariationCardProps {
  variation: GeneratedLogoVariation;
  onRefresh: () => void;
  onRefine: () => void;
  onSelect: () => void;
}

const ActionButton: React.FC<{
    onClick: (e: React.MouseEvent) => void;
    title: string;
    children: React.ReactNode;
    disabled?: boolean;
}> = ({ onClick, title, children, disabled = false }) => (
    <button
        onClick={onClick}
        title={title}
        disabled={disabled}
        className="flex-1 flex flex-col items-center justify-center p-2 text-xs font-semibold text-gray-300 hover:bg-white/10 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
    >
        {children}
        <span className="mt-1">{title}</span>
    </button>
);

const LogoVariationCard: React.FC<LogoVariationCardProps> = ({ variation, onRefresh, onRefine, onSelect }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const handleSave = (e: React.MouseEvent) => {
        e.stopPropagation();
        const link = document.createElement('a');
        link.href = variation.content;
        link.download = `logo-variation-${variation.id.substring(0, 6)}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="relative w-full h-full bg-black/20 rounded-lg group overflow-hidden animate-fade-in-fast">
            {variation.isLoading ? (
                <div className="flex items-center justify-center h-full">
                    <Spinner className="w-10 h-10 text-white/70" />
                </div>
            ) : variation.content ? (
                <>
                    <img src={variation.content} alt={`Logo Variation ${variation.id}`} className="w-full h-full object-contain p-4" />
                    
                    {/* Hover Overlay */}
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col">
                        {/* Top Controls */}
                        <div className="absolute top-2 right-2 flex gap-2">
                             <button onClick={(e) => { e.stopPropagation(); onRefresh(); }} title="Regenerate" className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h5M20 20v-5h-5" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 9a9 9 0 0114.65-5.32L20 5M20 15a9 9 0 01-14.65 5.32L4 19" /></svg>
                            </button>
                            <button onClick={(e) => { e.stopPropagation(); setIsExpanded(true); }} title="Expand" className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 0h-4m4 0l-5-5" /></svg>
                            </button>
                        </div>
                        
                        {/* Center Feedback */}
                        <div className="flex-grow flex items-center justify-center gap-4">
                             <button title="Dislike" className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14H5.236a2 2 0 01-1.789-2.894l3.5-7A2 2 0 018.736 3h4.018a2 2 0 01.464 3.973l-2.164 4.329a.25.25 0 00.22 3.698h4.28a2 2 0 011.884 2.842l-3.5 7A2 2 0 0113.736 21H10" /></svg>
                            </button>
                             <button title="Like" className="p-3 rounded-full bg-white/10 hover:bg-white/20 transition-colors">
                                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.018a2 2 0 01-1.464-3.973l2.164-4.329a.25.25 0 00-.22-3.698h-4.28a2 2 0 01-1.884-2.842l3.5-7A2 2 0 018.736 3H14" /></svg>
                            </button>
                        </div>

                        {/* Bottom Toolbar */}
                        <div className="flex-shrink-0 bg-black/30 backdrop-blur-sm p-1 m-1 rounded-lg flex items-stretch gap-1">
                           <ActionButton onClick={(e) => { e.stopPropagation(); onSelect(); }} title="Select">
                               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                           </ActionButton>
                           <ActionButton onClick={(e) => e.stopPropagation()} title="Animate" disabled={true}>
                               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M10 3.5a1.5 1.5 0 013 0V4a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-.5a1.5 1.5 0 000 3h.5a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-.5a1.5 1.5 0 00-3 0v.5a1 1 0 01-1 1H6a1 1 0 01-1-1v-3a1 1 0 00-1-1h-.5a1.5 1.5 0 010-3H4a1 1 0 001-1V6a1 1 0 011-1h3a1 1 0 011 1v.5a1.5 1.5 0 003 0V3.5z" /></svg>
                           </ActionButton>
                           <ActionButton onClick={(e) => e.stopPropagation()} title="Mockups" disabled={true}>
                               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" /></svg>
                           </ActionButton>
                           <ActionButton onClick={(e) => { e.stopPropagation(); onRefine(); }} title="Refine">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path d="M17.414 2.586a2 2 0 00-2.828 0L7 10.172V13h2.828l7.586-7.586a2 2 0 000-2.828z" /><path fillRule="evenodd" d="M2 6a2 2 0 012-2h4a1 1 0 010 2H4v10h10v-4a1 1 0 112 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2V6z" clipRule="evenodd" /></svg>
                           </ActionButton>
                           <ActionButton onClick={handleSave} title="Save">
                               <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                           </ActionButton>
                        </div>
                    </div>
                </>
            ) : (
                <div className="flex flex-col items-center justify-center h-full text-center text-red-400 p-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mb-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    <p className="font-semibold text-sm">Generation Failed</p>
                    <button onClick={(e) => { e.stopPropagation(); onRefresh(); }} className="mt-2 px-3 py-1 text-xs font-semibold bg-white/10 rounded-full hover:bg-white/20 transition-colors text-white">
                        Try Again
                    </button>
                </div>
            )}

            {isExpanded && variation.content && (
                <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4 animate-fade-in" onClick={(e) => { e.stopPropagation(); setIsExpanded(false); }}>
                    <img src={variation.content} alt="Expanded logo" className="max-w-[90vw] max-h-[90vh] object-contain shadow-2xl rounded-lg" />
                </div>
            )}
        </div>
    );
};

export default LogoVariationCard;