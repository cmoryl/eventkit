
import React, { useState, useCallback, useMemo, useRef } from 'react';
import { AssetType } from '../types';
import type { EventDetails, VenueSearchResult } from '../types';
import Spinner from './Spinner';
import Accordion from './Accordion';
import QRCodeSetupModal from './QRCodeSetupModal';
import VenueSearchModal from './VenueSearchModal';
import { findVenueDetails } from '../services/geminiService';
import { convertSvgToPng, ASSET_CATEGORIES, compressImage } from '../utils';
import { v4 as uuidv4 } from 'uuid';

interface LogoUploaderProps {
    eventDetails: EventDetails;
    setEventDetails: (details: EventDetails | ((prev: EventDetails) => EventDetails)) => void;
    logos: { id: string, file: File, url: string, name: string }[];
    setLogos: (logos: { id: string, file: File, url: string, name: string }[] | ((prev: { id: string, file: File, url: string, name: string }[]) => { id: string, file: File, url: string, name: string }[])) => void;
    styleImage: { file: File, url: string } | null;
    setStyleImage: (image: { file: File, url: string } | null) => void;
    selectedAssets: Set<AssetType>;
    setSelectedAssets: (assets: Set<AssetType> | ((prev: Set<AssetType>) => Set<AssetType>)) => void;
    onGenerate: () => void;
    isLoading: boolean;
    assetGenerators: { type: AssetType; title: string; }[];
    step: number;
    setStep: (step: number) => void;
    onOpenLogoGenerator: () => void;
    onOpenQRCodeGenerator: () => void;
    onGenerateVariations: (id: string) => void;
    setMasterPatternImage: (file: File | null) => void;
}


const eventSizePresets = {
  small: new Set([AssetType.Slogans, AssetType.SocialPost, AssetType.NameTag, AssetType.WifiSign, AssetType.EmailHeader]),
  medium: new Set([AssetType.Slogans, AssetType.SocialPost, AssetType.NameTag, AssetType.WifiSign, AssetType.EmailHeader, AssetType.Banner, AssetType.Tshirt, AssetType.SwagBag, AssetType.AgendaHighlights, AssetType.Lanyard]),
  large: new Set([AssetType.Slogans, AssetType.SocialPost, AssetType.NameTag, AssetType.WifiSign, AssetType.EmailHeader, AssetType.Banner, AssetType.Tshirt, AssetType.SwagBag, AssetType.AgendaHighlights, AssetType.Lanyard, AssetType.HangingSignage, AssetType.OutdoorSignage, AssetType.BackWall, AssetType.Stairs, AssetType.PresentationSlide, AssetType.RoomSignage, AssetType.RegistrationCounter, AssetType.RegistrationBackWall, AssetType.TechnologyCounter, AssetType.Kiosk, AssetType.AppIcon, AssetType.Favicon, AssetType.SocialProfile, AssetType.LogoMonochrome, AssetType.VideoTeaser, AssetType.Presentation, AssetType.MainStageBackdrop, AssetType.GlassDoor, AssetType.GlassDoubleDoor, AssetType.GlassRotatingDoor, AssetType.StyleGuide, AssetType.RunOfShow]),
};

const FileInput: React.FC<{
    id: string;
    onFileChange: (file: File) => void;
    title: string;
    subtitle: string;
    className?: string;
}> = ({ id, onFileChange, title, subtitle, className = 'h-64' }) => {
    const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            onFileChange(e.target.files[0]);
        }
    }, [onFileChange]);

    const handleDragOver = useCallback((e: React.DragEvent<HTMLLabelElement>) => e.preventDefault(), []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLLabelElement>) => {
        e.preventDefault();
        if (e.dataTransfer.files && e.dataTransfer.files[0] && e.dataTransfer.files[0].type.startsWith('image/')) {
            onFileChange(e.dataTransfer.files[0]);
        }
    }, [onFileChange]);

    return (
        <label 
            htmlFor={id} 
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            className={`relative flex flex-col items-center justify-center w-full border-2 border-dashed border-white/20 rounded-lg cursor-pointer bg-white/5 hover:bg-white/10 backdrop-blur-md transition-colors ${className}`}
        >
            <div className="flex flex-col items-center justify-center pt-5 pb-6 text-gray-400">
                <svg className="w-10 h-10 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                <p className="mb-2 text-sm"><span className="font-semibold">{title}</span> or drag and drop</p>
                <p className="text-xs">{subtitle}</p>
            </div>
            <input id={id} type="file" className="hidden" onChange={handleFileChange} accept="image/*" />
        </label>
    );
};

const LogoUploader: React.FC<LogoUploaderProps> = ({ 
    eventDetails, setEventDetails,
    logos, setLogos,
    styleImage, setStyleImage,
    selectedAssets, setSelectedAssets,
    onGenerate,
    isLoading,
    assetGenerators,
    step, setStep,
    onOpenLogoGenerator,
    onOpenQRCodeGenerator,
    onGenerateVariations,
    setMasterPatternImage
}) => {
  // Using passed props for navigation
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [isQRCodeModalOpen, setIsQRCodeModalOpen] = useState(false);
  
  // Venue Search State
  const [isVenueModalOpen, setIsVenueModalOpen] = useState(false);
  const [venueSearchResults, setVenueSearchResults] = useState<VenueSearchResult[]>([]);
  const [isVenueSearching, setIsVenueSearching] = useState(false);
  const [venueSearchError, setVenueSearchError] = useState<string | null>(null);
  const [masterPatternPreview, setMasterPatternPreview] = useState<string | null>(null);

  const handleAddLogos = async (files: FileList) => {
      const newFiles = Array.from(files);
      const processedNewLogos = await Promise.all(
          newFiles.map(async (file, index) => {
              let finalFile = file.type === 'image/svg+xml' ? await convertSvgToPng(file) : file;
              if (finalFile.size > 1024 * 1024) {
                  try {
                      const compressedBlob = await compressImage(finalFile);
                      finalFile = new File([compressedBlob], finalFile.name, { type: 'image/png' });
                  } catch (e) {
                      console.warn("Compression failed, using original", e);
                  }
              }
              const logoCount = logos.length + index;
              return {
                  id: uuidv4(),
                  file: finalFile,
                  url: URL.createObjectURL(finalFile),
                  name: logoCount === 0 ? 'Primary Logo' : `Logo Variation ${logoCount}`
              };
          })
      );
      setLogos(prev => [...prev, ...processedNewLogos]);
  };

  const handleLogoFilesChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files) {
          handleAddLogos(e.target.files);
      }
  }, [logos]);

  const handleRemoveLogo = (idToRemove: string) => {
      setLogos(prev => prev.filter(logo => logo.id !== idToRemove));
  };

  const handleStyleImageChange = useCallback(async (file: File) => {
      let finalFile = file;
      if (file.size > 1024 * 1024) {
          try {
              const compressedBlob = await compressImage(file);
              finalFile = new File([compressedBlob], file.name, { type: file.type });
          } catch (e) { console.warn("Style ref compression failed"); }
      }
      setStyleImage({ file: finalFile, url: URL.createObjectURL(finalFile) });
  }, [setStyleImage]);
  
  const handleRemoveStyleImage = useCallback(() => {
    setStyleImage(null);
  }, [setStyleImage]);

  const handleMasterPatternChange = async (file: File) => {
      let finalFile = file;
      if (file.size > 2 * 1024 * 1024) {
          try {
              const compressedBlob = await compressImage(file);
              finalFile = new File([compressedBlob], file.name, { type: file.type });
          } catch (e) { console.warn("Pattern compression failed"); }
      }
      setMasterPatternImage(finalFile);
      setMasterPatternPreview(URL.createObjectURL(finalFile));
  };

  const handleDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setEventDetails(prev => ({...prev, [name]: checked }));
    } else {
        setEventDetails(prev => ({ ...prev, [name]: value }));
        if (name === 'location' && !value) {
            setEventDetails(prev => ({ ...prev, incorporateLocationStyle: false }));
        }
    }
  };

  const handleAssetSelection = (type: AssetType) => {
    setActivePreset(null);
    setSelectedAssets(prevSet => {
        const newSet = new Set(prevSet);
        if (newSet.has(type)) {
            newSet.delete(type);
        } else {
            if (type === AssetType.QRCode) {
                setIsQRCodeModalOpen(true);
                // The asset will be added to the set upon saving the modal
                return newSet; 
            }
            newSet.add(type);
        }
        return newSet;
    });
  };

  const handleSaveQRCodeDetails = (details: { url: string; color: string; bgColor: string; }) => {
    setEventDetails(prev => ({
        ...prev,
        qrCodeUrl: details.url,
        qrCodeColor: details.color,
        qrCodeBgColor: details.bgColor
    }));
    setSelectedAssets(prev => {
        const newSet = new Set(prev);
        newSet.add(AssetType.QRCode);
        return newSet;
    });
    setIsQRCodeModalOpen(false);
  };


  const handleToggleCategory = (categoryAssets: AssetType[]) => {
      setActivePreset(null);
      const isFloorPlanDisabled = !eventDetails.venuePlaceId;
      // Filter out disabled assets before toggling
      const toggleableAssets = categoryAssets.filter(type => {
          if (type === AssetType.FloorPlan) return !isFloorPlanDisabled;
          return true;
      });

      const selectedInCategory = toggleableAssets.filter(type => selectedAssets.has(type));
      const allSelected = selectedInCategory.length === toggleableAssets.length && toggleableAssets.length > 0;

      setSelectedAssets(prev => {
          const newSet = new Set(prev);
          if (allSelected) {
              toggleableAssets.forEach(type => newSet.delete(type));
          } else {
              toggleableAssets.forEach(type => newSet.add(type));
          }
          return newSet;
      });
  };

  const handlePresetSelection = (size: 'small' | 'medium' | 'large') => {
      setSelectedAssets(eventSizePresets[size]);
      setActivePreset(size);
  };
  
  const handleFindVenue = async () => {
    if (!eventDetails.venueQuery?.trim()) return;
    if (!eventDetails.location?.trim()) {
        alert("Please enter a general Event Location (e.g., city, state) to help narrow down the venue search.");
        return;
    }

    setIsVenueSearching(true);
    setVenueSearchError(null);
    setVenueSearchResults([]);
    setIsVenueModalOpen(true);

    try {
        const results = await findVenueDetails(eventDetails.venueQuery, eventDetails.location);
        if (results.length === 0) {
            setVenueSearchError("No venues found matching your query. Please try being more specific.");
        } else {
            setVenueSearchResults(results);
        }
    } catch (error) {
        console.error("Venue search failed:", error);
        let message = "Could not search for venue. An unexpected error occurred.";
        if (error instanceof Error) {
            message = `Venue search failed: ${error.message}`;
        }
        setVenueSearchError(message);
    } finally {
        setIsVenueSearching(false);
    }
  };
  
  const handleSelectVenue = (venue: VenueSearchResult) => {
      setEventDetails(prev => ({
          ...prev,
          venueName: venue.name,
          venueAddress: venue.address,
          venuePlaceId: venue.placeId,
      }));
      setIsVenueModalOpen(false);
  };

  const isStep1Valid = useMemo(() => logos.length > 0 && eventDetails.name.trim() !== '' && eventDetails.description.trim() !== '', [logos, eventDetails.name, eventDetails.description]);
  const isStep3Valid = useMemo(() => selectedAssets.size > 0, [selectedAssets]);

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
            <div className="space-y-4 card-style p-4 min-h-[400px] flex flex-col">
              <h3 className="text-lg font-semibold text-white mb-3 text-left">Event Logos (First is primary)</h3>
              <div className="grid grid-cols-3 gap-3">
                {logos.map((logo, i) => (
                  <div key={logo.id} className="relative group aspect-square bg-black/20 rounded-md p-1">
                    <img src={logo.url} alt={logo.name} className="w-full h-full object-contain" />
                    {i === 0 && <span className="absolute top-1 left-1 bg-fuchsia-600 text-[9px] text-white px-1 rounded">PRIMARY</span>}
                    <button onClick={() => handleRemoveLogo(logo.id)} className="absolute top-1 right-1 bg-red-600/80 hover:bg-red-500 rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remove logo">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                    {/* Add Generate Variation button */}
                    <button onClick={() => onGenerateVariations(logo.id)} className="absolute bottom-1 right-1 bg-fuchsia-600/80 hover:bg-fuchsia-500 rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" title="Generate AI Variation">
                       <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </button>
                  </div>
                ))}
                <label htmlFor="logo-upload" className="flex items-center justify-center w-full aspect-square border-2 border-dashed border-white/20 rounded-md cursor-pointer hover:bg-white/10 transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                </label>
                <input id="logo-upload" type="file" multiple accept="image/*" className="hidden" onChange={handleLogoFilesChange} />
              </div>
              <div className="mt-auto pt-4">
                  <button onClick={onOpenLogoGenerator} className="text-sm text-fuchsia-400 hover:text-fuchsia-300 w-full text-left flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                      Create Logo with AI
                  </button>
              </div>
            </div>
            <div className="space-y-4 text-left card-style p-4 min-h-[400px] flex flex-col">
              <input type="text" name="name" value={eventDetails.name} onChange={handleDetailsChange} placeholder="Event Name" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
              <textarea name="description" value={eventDetails.description} onChange={handleDetailsChange} placeholder="Briefly describe your event..." rows={6} className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all resize-none backdrop-blur-md flex-grow" />
            </div>
          </div>
        );
      case 2:
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
            <div className="space-y-4 text-left card-style p-4 min-h-[400px]">
              <input type="text" name="date" value={eventDetails.date} onChange={handleDetailsChange} placeholder="Event Date (e.g., September 14-16, 2024)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
              <input type="url" name="website" value={eventDetails.website} onChange={handleDetailsChange} placeholder="Event Website (e.g., https://my-event.com)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
              <input type="email" name="email" value={eventDetails.email} onChange={handleDetailsChange} placeholder="Contact Email (e.g., info@my-event.com)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
              <div>
                <input type="text" name="location" value={eventDetails.location} onChange={handleDetailsChange} placeholder="Event Location (e.g., Kyoto, Japan)" className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
                <label className="flex items-center space-x-3 mt-3 p-3 bg-white/5 rounded-lg cursor-pointer hover:bg-white/10 transition-colors has-[:disabled]:opacity-50 has-[:disabled]:cursor-not-allowed has-[:disabled]:hover:bg-white/5">
                  <input type="checkbox" name="incorporateLocationStyle" checked={eventDetails.incorporateLocationStyle} onChange={handleDetailsChange} disabled={!eventDetails.location?.trim()} className="h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400 disabled:cursor-not-allowed" />
                  <span className="text-gray-300 font-medium text-sm">Incorporate local culture & landmarks into designs</span>
                </label>
              </div>
               <div className="pt-4 border-t border-white/10">
                    <label htmlFor="venue-query" className="text-sm font-medium text-gray-300 mb-2 block">Venue Search (for Floor Plans)</label>
                    {eventDetails.venueName ? (
                        <div className="bg-green-900/50 border border-green-500/30 text-white p-3 rounded-lg">
                            <p className="font-bold text-sm text-green-300">✓ Venue Selected</p>
                            <p className="font-semibold">{eventDetails.venueName}</p>
                            <p className="text-xs text-gray-300">{eventDetails.venueAddress}</p>
                            <button onClick={() => setEventDetails(prev => ({...prev, venueName: '', venueAddress: '', venuePlaceId: ''}))} className="text-xs text-red-400 hover:underline mt-2">Clear</button>
                        </div>
                    ) : (
                        <div className="flex gap-2">
                            <input type="text" name="venueQuery" value={eventDetails.venueQuery} onChange={handleDetailsChange} placeholder="Hotel or Conference Center Name" className="flex-grow bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-2 focus:ring-fuchsia-500/50 focus:border-fuchsia-500 outline-none transition-all backdrop-blur-md" />
                            <button onClick={handleFindVenue} disabled={!eventDetails.venueQuery?.trim()} className="btn-secondary px-4 py-2 flex-shrink-0">
                                Find
                            </button>
                        </div>
                    )}
                </div>
            </div>
            <div className="card-style p-4 space-y-4 min-h-[400px] flex flex-col">
                {styleImage ? (
                  <div className="relative group w-full border-2 border-dashed border-white/20 rounded-lg bg-white/5 p-2 flex-1 min-h-[150px]">
                    <img src={styleImage.url} alt="Style reference preview" className="w-full h-full object-contain" />
                    <button onClick={handleRemoveStyleImage} className="absolute top-2 right-2 bg-red-600/80 hover:bg-red-500 rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Remove style reference image">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                  </div>
                ) : (
                  <FileInput id="style-upload" onFileChange={handleStyleImageChange} title="Upload Style Reference" subtitle="Image for visual style (Optional)" className="h-48" />
                )}
                
                {masterPatternPreview ? (
                    <div className="relative group w-full border-2 border-dashed border-white/20 rounded-lg bg-white/5 p-2 flex-1 min-h-[150px]">
                        <img src={masterPatternPreview} alt="Pattern Source" className="w-full h-full object-contain" />
                        <button onClick={() => { setMasterPatternImage(null); setMasterPatternPreview(null); }} className="absolute top-2 right-2 bg-red-600/80 hover:bg-red-500 rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                ) : (
                    <FileInput id="pattern-upload" onFileChange={handleMasterPatternChange} title="Upload Pattern Source" subtitle="For seamless pattern generation (Optional)" className="h-32" />
                )}
            </div>
          </div>
        );
      case 3:
        return (
          <>
            <div className="text-left py-4 border-t border-b border-white/10 card-style p-4">
              <h2 className="text-xl font-semibold text-white mb-4">Select Assets to Generate</h2>
              <div className="mb-6 flex flex-wrap items-center gap-3">
                <p className="text-gray-400 font-medium mr-2">Start with a preset:</p>
                <button onClick={() => handlePresetSelection('small')} className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all border ${activePreset === 'small' ? 'bg-fuchsia-600 text-white border-fuchsia-500' : 'bg-white/10 text-gray-300 border-white/20 hover:bg-white/20'}`}>Small Event</button>
                <button onClick={() => handlePresetSelection('medium')} className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all border ${activePreset === 'medium' ? 'bg-fuchsia-600 text-white border-fuchsia-500' : 'bg-white/10 text-gray-300 border-white/20 hover:bg-white/20'}`}>Medium Event</button>
                <button onClick={() => handlePresetSelection('large')} className={`px-4 py-2 text-sm font-semibold rounded-lg transition-all border ${activePreset === 'large' ? 'bg-fuchsia-600 text-white border-fuchsia-500' : 'bg-white/10 text-gray-300 border-white/20 hover:bg-white/20'}`}>Large Event</button>
              </div>
              <div className="space-y-4">
                  {Object.entries(ASSET_CATEGORIES).map(([category, types]) => {
                      const generatorsInCategory = assetGenerators.filter(gen => types.includes(gen.type));
                      if (generatorsInCategory.length === 0) return null;
                      
                      const isFloorPlanDisabled = !eventDetails.venuePlaceId;
                      const selectableCount = generatorsInCategory.filter(g => g.type === AssetType.FloorPlan ? !isFloorPlanDisabled : true).length;
                      const selectedCount = generatorsInCategory.filter(gen => selectedAssets.has(gen.type)).length;
                      const allSelected = selectableCount > 0 && selectedCount === selectableCount;

                      return (
                          <Accordion key={category} title={`${category} (${selectedCount}/${generatorsInCategory.length})`}>
                              <div className="flex justify-end mb-3">
                                  <button onClick={() => handleToggleCategory(generatorsInCategory.map(g => g.type))} className="text-xs font-semibold text-fuchsia-400 hover:text-fuchsia-300 transition-colors">{allSelected ? 'Deselect All' : 'Select All'}</button>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  {generatorsInCategory.map(gen => {
                                      const isDisabled = gen.type === AssetType.FloorPlan && isFloorPlanDisabled;
                                      return (
                                          <div key={gen.type} className="flex items-center">
                                              <label className={`flex-grow flex items-center space-x-3 p-3 bg-black/20 rounded-lg border border-transparent transition-all backdrop-blur-md ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:bg-black/40 hover:border-fuchsia-500/50'}`} title={isDisabled ? 'Select a venue in Step 2 to enable Floor Plan generation.' : ''}>
                                                  <input type="checkbox" checked={selectedAssets.has(gen.type)} onChange={() => handleAssetSelection(gen.type)} disabled={isDisabled} className="h-5 w-5 rounded bg-white/10 border-white/20 text-fuchsia-500 focus:ring-fuchsia-400 disabled:cursor-not-allowed" />
                                                  <span className="text-gray-300 font-medium">{gen.title}</span>
                                              </label>
                                              {gen.type === AssetType.QRCode && selectedAssets.has(AssetType.QRCode) && (
                                                  <button
                                                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); setIsQRCodeModalOpen(true); }}
                                                      className="text-xs font-semibold text-fuchsia-400 hover:text-fuchsia-300 transition-colors ml-4 pr-2 flex-shrink-0"
                                                  >
                                                      Edit Details
                                                  </button>
                                              )}
                                          </div>
                                      );
                                  })}
                              </div>
                          </Accordion>
                      );
                  })}
              </div>
            </div>
             <QRCodeSetupModal
                isOpen={isQRCodeModalOpen}
                onClose={() => setIsQRCodeModalOpen(false)}
                onSave={handleSaveQRCodeDetails}
                initialUrl={eventDetails.qrCodeUrl}
                initialColor={eventDetails.qrCodeColor}
                initialBgColor={eventDetails.qrCodeBgColor}
            />
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto text-center p-4 sm:p-8 animate-fade-in">
        <div className="mb-8">
            <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Create Your Event Kit</h2>
            <p className="text-lg text-gray-400 mt-2">Upload your logo, describe your event, and let AI build your brand assets.</p>
        </div>

        <div className="space-y-8">
          <div className="flex justify-center items-center space-x-4 mb-12">
            {[1, 2, 3].map(num => (
              <React.Fragment key={num}>
                <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${step >= num ? 'bg-fuchsia-600 border-fuchsia-500' : 'bg-gray-700 border-gray-600'}`}>
                  <span className="text-xl font-bold text-white">{num}</span>
                </div>
                {num < 3 && <div className={`w-24 h-1 transition-all duration-300 ${step > num ? 'bg-fuchsia-600' : 'bg-gray-700'}`}></div>}
              </React.Fragment>
            ))}
          </div>
          
          <div className="min-h-[400px]">
            {renderStepContent()}
          </div>
          
          <div className="flex justify-between items-center mt-8">
            <div className="flex items-center gap-4">
              {step > 1 && (
                <button onClick={() => setStep(step - 1)} className="btn-secondary">Back</button>
              )}
            </div>
            <div className="flex items-center gap-4">
              {step < 3 && (
                <button onClick={() => setStep(step + 1)} disabled={step === 1 && !isStep1Valid} className="btn-primary">Next</button>
              )}
              {step === 3 && (
                <button onClick={onGenerate} disabled={!isStep3Valid || isLoading} className="btn-primary w-64">
                  {isLoading ? <><Spinner className="w-5 h-5 mr-3" /> Generating...</> : 'Generate Design Kit'}
                </button>
              )}
            </div>
          </div>
        </div>
        
        <VenueSearchModal
            isOpen={isVenueModalOpen}
            onClose={() => setIsVenueModalOpen(false)}
            onSelectVenue={handleSelectVenue}
            searchResults={venueSearchResults}
            isLoading={isVenueSearching}
            error={venueSearchError}
        />
    </div>
  );
};

export default LogoUploader;
