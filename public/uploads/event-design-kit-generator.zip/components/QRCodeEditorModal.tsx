
// Fix: Created the missing QRCodeEditorModal component.
import React from 'react';
import QRCodeGeneratorModal from './QRCodeGeneratorModal';
import type { GeneratedAsset } from '../types';

interface QRCodeEditorModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (assetId: string, data: { content: string; params: any }) => void;
    asset: GeneratedAsset;
    primaryLogoUrl?: string;
}

const QRCodeEditorModal: React.FC<QRCodeEditorModalProps> = ({
    isOpen,
    onClose,
    onSave,
    asset,
    primaryLogoUrl,
}) => {
    if (!isOpen) {
        return null;
    }

    const handleSave = (data: { content: string; params: any }) => {
        onSave(asset.id, data);
        onClose();
    };

    return (
        <QRCodeGeneratorModal
            isOpen={isOpen}
            onClose={onClose}
            onSave={handleSave}
            initialAsset={asset}
            primaryLogoUrl={primaryLogoUrl}
        />
    );
};

export default QRCodeEditorModal;
