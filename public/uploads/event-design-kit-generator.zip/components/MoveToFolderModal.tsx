
import React, { useState, useEffect } from 'react';
import type { AssetFolder } from '../types';

interface MoveToFolderModalProps {
    isOpen: boolean;
    onClose: () => void;
    folders: AssetFolder[];
    onMove: (folderId?: string) => void; // undefined means remove from folders (or 'General')
    onCreateFolder: (name: string) => void;
}

const MoveToFolderModal: React.FC<MoveToFolderModalProps> = ({ isOpen, onClose, folders, onMove, onCreateFolder }) => {
    const [newFolderName, setNewFolderName] = useState('');
    const [isCreating, setIsCreating] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setNewFolderName('');
            setIsCreating(false);
        }
    }, [isOpen]);

    const handleCreate = () => {
        if (newFolderName.trim()) {
            onCreateFolder(newFolderName.trim());
            setNewFolderName('');
            setIsCreating(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-[70] p-4 animate-fade-in" onClick={onClose}>
            <div className="bg-black/50 backdrop-blur-xl border border-white/10 rounded-lg shadow-2xl w-full max-w-md flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
                <header className="flex items-center justify-between p-4 border-b border-white/10">
                    <h2 className="text-lg font-bold text-white">Move to Folder</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                </header>
                
                <div className="p-4 overflow-y-auto max-h-[60vh] space-y-2">
                    <button onClick={() => onMove(undefined)} className="w-full text-left p-3 rounded-lg bg-white/5 hover:bg-white/10 text-gray-200 flex items-center">
                        <span className="mr-2 text-gray-500">⊘</span> No Folder (General)
                    </button>
                    
                    {folders.map(folder => (
                        <button key={folder.id} onClick={() => onMove(folder.id)} className="w-full text-left p-3 rounded-lg bg-white/5 hover:bg-white/10 text-white flex items-center">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3 text-fuchsia-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                            </svg>
                            {folder.name}
                        </button>
                    ))}

                    {isCreating ? (
                        <div className="mt-4 p-3 bg-white/5 rounded-lg border border-white/10">
                            <input 
                                type="text" 
                                value={newFolderName}
                                onChange={(e) => setNewFolderName(e.target.value)}
                                placeholder="Folder Name" 
                                className="w-full bg-black/20 border border-white/10 rounded p-2 text-white mb-2 focus:outline-none focus:border-fuchsia-500"
                                autoFocus
                            />
                            <div className="flex justify-end gap-2">
                                <button onClick={() => setIsCreating(false)} className="text-xs text-gray-400 hover:text-white">Cancel</button>
                                <button onClick={handleCreate} disabled={!newFolderName.trim()} className="px-3 py-1 text-xs bg-fuchsia-600 text-white rounded hover:bg-fuchsia-500 disabled:opacity-50">Create</button>
                            </div>
                        </div>
                    ) : (
                        <button onClick={() => setIsCreating(true)} className="w-full text-left p-3 rounded-lg border border-dashed border-white/20 text-gray-400 hover:text-white hover:border-white/40 flex items-center justify-center mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                            </svg>
                            Create New Folder
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MoveToFolderModal;
