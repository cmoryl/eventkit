// Fix: Removed file marker comments that were causing syntax errors.
import React from 'react';

interface ProgressBarProps {
  current: number;
  total: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ current, total }) => {
  const percentage = total > 0 ? Math.round((current / total) * 100) : 0;

  return (
    <div className="w-full mb-8 animate-fade-in">
        <div className="flex justify-between items-center mb-2">
            <p className="text-sm font-medium text-gray-300">
                Generating your design kit...
            </p>
            <p className="text-sm font-semibold text-gray-200">
                {current} / {total}
            </p>
        </div>
        <div className="w-full bg-white/10 rounded-full h-2.5 border border-white/20">
            <div
                className="bg-fuchsia-600 h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${percentage}%` }}
            ></div>
        </div>
    </div>
  );
};

export default ProgressBar;