
import React from 'react';

interface LocationIntelCardProps {
  content: string;
  isModalView?: boolean;
}

const LocationIntelCard: React.FC<LocationIntelCardProps> = ({ content, isModalView = false }) => {

  const parseAndRenderContent = (text: string) => {
    const lines = text.split('\n');
    const elements: React.ReactElement[] = [];
    let currentList: React.ReactElement[] = [];

    const flushList = () => {
      if (currentList.length > 0) {
        elements.push(<ul key={`ul-${elements.length}`} className="list-none space-y-2 pl-2">{currentList}</ul>);
        currentList = [];
      }
    };

    lines.forEach((line, index) => {
      line = line.trim();
      if (!line) return;
      if (line.startsWith('```')) return; // Ignore markdown code fences

      // Header parsing
      if (line.startsWith('#')) {
          flushList();
          // Remove # characters and trim
          const title = line.replace(/^#+\s*/, '');
          // Determine size based on # count (simple heuristic)
          const level = line.match(/^#+/)?.[0].length || 1;
          const fontSize = level === 1 ? 'text-lg' : 'text-sm';
          
          elements.push(<h4 key={index} className={`${fontSize} font-bold text-white mt-3 mb-1`}>{title}</h4>);
          return;
      }

      if (line.startsWith('**') && line.endsWith('**')) {
        flushList();
        elements.push(<h4 key={index} className="text-sm font-bold text-white mt-3 mb-1">{line.replace(/\*\*/g, '')}</h4>);
        return;
      }
      
      if (line.startsWith('- ')) {
        const textPart = line.substring(2);
        
        // Check for markdown link format first: [text](url)
        const markdownLinkMatch = textPart.match(/\[(.*?)\]\((https?:\/\/[^\s)]+)\)/);
        if (markdownLinkMatch) {
            const linkText = markdownLinkMatch[1];
            const url = markdownLinkMatch[2];
            currentList.push(
                <li key={index} className="flex items-start">
                    <span className="text-fuchsia-400 mr-2 mt-1">›</span>
                    <a href={url} target="_blank" rel="noopener noreferrer" className="text-fuchsia-400 hover:text-fuchsia-300 hover:underline break-words">
                        {linkText || url}
                    </a>
                </li>
            );
            return;
        }

        // Fallback: Check for raw URL
        const rawUrlMatch = textPart.match(/(https?:\/\/[^\s]+)/);
        if (rawUrlMatch) {
            const url = rawUrlMatch[0];
            const linkText = textPart.replace(url, '').replace(/[:\s]*$/, '').trim();
            currentList.push(
                <li key={index} className="flex items-start">
                    <span className="text-fuchsia-400 mr-2 mt-1">›</span>
                    <a href={url} target="_blank" rel="noopener noreferrer" className="text-fuchsia-400 hover:text-fuchsia-300 hover:underline break-words">
                        {linkText || url}
                    </a>
                </li>
            );
        } else {
             currentList.push(
                <li key={index} className="flex items-start">
                    <span className="text-gray-400 mr-2 mt-1">›</span>
                    <span className="break-words">{textPart}</span>
                </li>
            );
        }
        return;
      }

      flushList();
      elements.push(<p key={index} className={`text-gray-300 ${isModalView ? 'text-base' : 'text-sm'} mb-2`}>{line}</p>);
    });
    
    flushList();

    return elements;
  };

  return (
    <div className={`w-full text-left p-2 ${isModalView ? '' : 'max-h-64 overflow-y-auto'}`}>
        {parseAndRenderContent(content)}
    </div>
  );
};

export default LocationIntelCard;
