import React, { useState, useEffect } from 'react';
import { refineLogo } from '../services/geminiService';
import type { GeneratedLogoVariation } from '../types';
import Spinner from './Spinner';

interface LogoRefineModalProps {
  isOpen: boolean;
  onClose: () => void;
  logo: GeneratedLogoVariation;
  onSave: (id: string, newContent: string) => void;
}

const LogoRefineModal: React.FC<LogoRefineModalProps> = ({ isOpen, onClose, logo, onSave }) => {
  const [prompt, setPrompt] = useState('');
  const [isRefining, setIsRefining] = useState(false);
  const [refinedImage, setRefinedImage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setRefinedImage(null);
      setPrompt('');
    }
  }, [isOpen]);

  const handleRefine = async () => {
    if (!prompt.trim()) return;
    setIsRefining(true);
    try {
      const result = await refineLogo(refinedImage || logo.content, prompt);
      setRefinedImage(result);
      setPrompt('');
    } catch (e) {
      console.error(e);
      alert('Failed to refine logo. Please try again.');
    } finally {
      setIsRefining(false);
    }
  };
  
  const handleSave = () => {
    if (refinedImage) {
      onSave(logo.id, refinedImage);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-[60] p-4 animate-fade-in" onClick={onClose}>
      <div className="bg-gray-900/80 border border-white/10 rounded-lg shadow-2xl w-full max-w-2xl flex flex-col animate-scale-in" onClick={e => e.stopPropagation()}>
        <header className="flex items-center justify-between p-4 border-b border-white/10 flex-shrink-0">
          <h2 className="text-xl font-bold text-white">Refine Logo</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </header>
        
        <div className="p-6 flex-grow flex flex-col md:flex-row gap-6 overflow-y-auto">
            <div className="md:w-1/2 flex items-center justify-center bg-black/20 rounded-lg p-2">
                <img src={refinedImage || logo.content} alt="Logo to refine" className="max-w-full max-h-full object-contain" />
            </div>
            <div className="md:w-1/2 flex flex-col space-y-4">
                <label htmlFor="refine-prompt" className="font-medium text-gray-300">Describe your changes:</label>
                <textarea
                    id="refine-prompt"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    rows={4}
                    placeholder="e.g., 'Make the wave element bigger', 'Change the sun to a deep orange color', 'Use a bolder font'"
                    className="w-full bg-white/5 border border-white/20 text-white rounded-lg p-3 focus:ring-1 focus:ring-fuchsia-500 outline-none resize-none"
                />
                <button onClick={handleRefine} disabled={isRefining || !prompt.trim()} className="btn-primary w-full py-2.5">
                    {isRefining ? <><Spinner className="mr-2"/> Refining...</> : 'Refine'}
                </button>
            </div>
        </div>

        <footer className="p-4 border-t border-white/10 flex-shrink-0 flex justify-end gap-4">
            <button onClick={onClose} className="btn-secondary">Cancel</button>
            <button onClick={handleSave} disabled={!refinedImage} className="btn-primary">Set as New Version</button>
        </footer>
      </div>
    </div>
  );
};

export default LogoRefineModal;
