import React, { useState, useEffect, useRef } from 'react';

type CropBox = { x: number; y: number; width: number; height: number; };
type DragState = { type: 'move' | 'nw' | 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | null; startX: number; startY: number; };

interface CropperProps {
    imageElement: HTMLImageElement;
    onCropChange: (cropBox: CropBox) => void;
}

const Cropper: React.FC<CropperProps> = ({ imageElement, onCropChange }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [crop, setCrop] = useState<CropBox>({ x: 0, y: 0, width: 0, height: 0 });
    const [dragState, setDragState] = useState<DragState>({ type: null, startX: 0, startY: 0 });

    useEffect(() => {
        if (!imageElement) return;
        const rect = imageElement.getBoundingClientRect();
        const containerRect = containerRef.current!.getBoundingClientRect();
        const initialSize = Math.min(rect.width, rect.height) * 0.8;
        const initialCrop = {
            width: initialSize,
            height: initialSize,
            x: (rect.width - initialSize) / 2,
            y: (rect.height - initialSize) / 2,
        };
        setCrop(initialCrop);
        onCropChange(initialCrop);
    }, [imageElement, onCropChange]);

    const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>, type: DragState['type']) => {
        e.preventDefault();
        e.stopPropagation();
        setDragState({
            type,
            startX: e.clientX,
            startY: e.clientY,
        });
    };

    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!dragState.type) return;

            const dx = e.clientX - dragState.startX;
            const dy = e.clientY - dragState.startY;
            const imgRect = imageElement.getBoundingClientRect();
            
            let newCrop = { ...crop };

            const actions = {
                move: () => {
                    newCrop.x += dx;
                    newCrop.y += dy;
                },
                nw: () => { newCrop.x += dx; newCrop.y += dy; newCrop.width -= dx; newCrop.height -= dy; },
                n:  () => { newCrop.y += dy; newCrop.height -= dy; },
                ne: () => { newCrop.y += dy; newCrop.width += dx; newCrop.height -= dy; },
                e:  () => { newCrop.width += dx; },
                se: () => { newCrop.width += dx; newCrop.height += dy; },
                s:  () => { newCrop.height += dy; },
                sw: () => { newCrop.x += dx; newCrop.width -= dx; newCrop.height += dy; },
                w:  () => { newCrop.x += dx; newCrop.width -= dx; },
            };

            actions[dragState.type]();

            // Clamp crop box to image boundaries
            newCrop.x = Math.max(0, newCrop.x);
            newCrop.y = Math.max(0, newCrop.y);
            newCrop.width = Math.min(imgRect.width - newCrop.x, newCrop.width);
            newCrop.height = Math.min(imgRect.height - newCrop.y, newCrop.height);
            // Prevent negative width/height
            if (newCrop.width < 10) newCrop.width = 10;
            if (newCrop.height < 10) newCrop.height = 10;


            setCrop(newCrop);
            setDragState(prev => ({ ...prev, startX: e.clientX, startY: e.clientY }));
        };

        const handleMouseUp = () => {
            if (dragState.type) {
                onCropChange(crop);
            }
            setDragState({ type: null, startX: 0, startY: 0 });
        };

        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseup', handleMouseUp);

        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [dragState, crop, imageElement, onCropChange]);

    const { x, y, width, height } = crop;

    return (
        <div ref={containerRef} className="absolute inset-0 z-10">
            {/* Overlay */}
            <div className="absolute inset-0 bg-black/70" style={{
                clipPath: `polygon(
                    0% 0%, 100% 0%, 100% 100%, 0% 100%,
                    0% ${y}px,
                    ${x}px ${y}px,
                    ${x}px ${y + height}px,
                    ${x + width}px ${y + height}px,
                    ${x + width}px ${y}px,
                    0% ${y}px
                )`,
                clipRule: 'evenodd'
            }} />
            
            {/* Crop Box */}
            <div
                className="absolute border-2 border-dashed border-white cursor-move"
                style={{ left: x, top: y, width, height }}
                onMouseDown={(e) => handleMouseDown(e, 'move')}
            >
                {/* Resize Handles */}
                <div onMouseDown={(e) => handleMouseDown(e, 'nw')} className="absolute -top-1 -left-1 w-3 h-3 bg-white cursor-nwse-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'n')} className="absolute -top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white cursor-ns-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'ne')} className="absolute -top-1 -right-1 w-3 h-3 bg-white cursor-nesw-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'e')} className="absolute top-1/2 -translate-y-1/2 -right-1 w-3 h-3 bg-white cursor-ew-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'se')} className="absolute -bottom-1 -right-1 w-3 h-3 bg-white cursor-nwse-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 's')} className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white cursor-ns-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'sw')} className="absolute -bottom-1 -left-1 w-3 h-3 bg-white cursor-nesw-resize rounded-full" />
                <div onMouseDown={(e) => handleMouseDown(e, 'w')} className="absolute top-1/2 -translate-y-1/2 -left-1 w-3 h-3 bg-white cursor-ew-resize rounded-full" />
            </div>
        </div>
    );
};

export default Cropper;
